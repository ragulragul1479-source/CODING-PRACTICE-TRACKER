# Coding Practice Tracker

A production-grade, full-stack web application designed for software engineers and competitive programmers to systematically track algorithm practice, record study sessions, maintain active daily streaks, and visualize topic mastery with comprehensive analytics.

---

## 🌟 Key Features

### 1. 📊 Interactive Dashboard
- **Key Metrics Overview**: Real-time stats for Total Solved, Completion Rate, Practice Hours, and Active Streak.
- **Difficulty Breakdown**: Color-coded progress metrics for Easy, Medium, and Hard problems.
- **GitHub-Style Activity Heatmap**: Interactive 90-day practice calendar displaying daily solve frequency and minutes logged.
- **Weekly & Monthly Goals**: Dynamic progress bars tracking target daily problems and weekly practice hours.
- **Recent Activity Feed**: Real-time event log for problem updates and practice sessions.

### 2. 💻 Coding Problems Management
- **Full CRUD Capabilities**: Create, view, update, delete coding problems.
- **Rich Metadata**: Difficulty (`EASY`, `MEDIUM`, `HARD`), Category/Topic, Platform (`LeetCode`, `Codeforces`, `HackerRank`, `NeetCode`, etc.), Problem URL, Solution Repository Link, Time Spent, and Solved Date.
- **Algorithmic Notes**: Store Markdown/syntax notes highlighting core time/space complexity and tricky edge cases.
- **Multi-Facet Filtering**: Filter by Status (All/Solved/Unsolved), Difficulty, Topic, and Platform.
- **Search & Sort**: Full-text instant search with ascending/descending sorting by Date, Title, Difficulty, and Time.
- **Table & Grid Views**: Seamlessly switch between a high-density data table and a visual card grid.
- **Celebration Confetti**: Instant particle confetti animation upon marking problems as solved.

### 3. ⏱️ Practice Sessions Log
- **Focus Time Blocks**: Record structured study sessions with date, duration (minutes/hours), problems solved count, topic focus, and retrospective notes.
- **Summary Metrics**: Logged session count, total practice hours, and average session length.

### 4. 📈 Analytics & Topic Mastery
- **Difficulty Donut Chart**: Visual distribution of solved vs. unsolved algorithmic difficulties using Recharts.
- **Practice Hours Trend**: Area chart showing monthly study volume and problem solve velocity.
- **Topic Mastery Breakdown**: Horizontal progress bars measuring completion across topics (Arrays, Trees, Graphs, DP, Intervals, etc.).
- **Day of Week Distribution**: Activity distribution across days of the week to analyze study consistency.

### 5. 👤 Profile & Practice Goals
- **Developer Profile**: Display full name, handle, bio, and join date.
- **Target Customization**: Adjust target daily problems and weekly target study hours.

### 6. ⚙️ Settings & Data Portability
- **Theme Support**: High-contrast Dark Mode (developer-first default) and crisp Light Mode.
- **Security**: Change password with BCrypt verification.
- **Data Export**: One-click export to **JSON backup** or **CSV spreadsheet**.
- **Data Reset**: Re-seed pristine sample dataset anytime.
- **Architecture Health Indicator**: Live status monitor of backend connectivity.

---

## 🏗️ Architecture & Technology Stack

### Backend
- **Language**: Java 21 (LTS)
- **Framework**: Spring Boot 3.2.4
- **Security**: Spring Security 6 + Stateless JWT (JSON Web Tokens) with BCrypt hashing
- **Data Access**: Spring Data JPA / Hibernate
- **Database**: PostgreSQL 16+
- **Validation**: Jakarta Bean Validation (`@Valid`, `@NotBlank`, `@Size`, etc.)
- **Build Tool**: Maven 3.9+
- **Testing**: JUnit 5 + Mockito + Spring Boot Test

### Frontend
- **Framework**: React 18
- **Language**: TypeScript (strict mode)
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **Charts & Data Viz**: Recharts
- **Icons**: Lucide React
- **Animations**: Motion (`motion/react`)
- **HTTP Client**: Axios with JWT request interceptors

---

## 📁 Project Structure

```
├── backend/
│   ├── src/main/java/com/tracker/codingpractice/
│   │   ├── config/              # Security, JWT filters, CORS, DataInitializer
│   │   ├── controller/          # REST Controllers (Auth, Problems, Sessions, Dashboard, etc.)
│   │   ├── dto/                 # Request/Response Data Transfer Objects
│   │   ├── entity/              # JPA Entities (User, CodingProblem, PracticeSession)
│   │   ├── exception/           # Custom exceptions & GlobalExceptionHandler
│   │   ├── repository/          # Spring Data JPA repositories with custom JPQL
│   │   ├── service/             # Business logic and services
│   │   └── CodingPracticeTrackerApplication.java
│   ├── src/main/resources/
│   │   └── application.yml      # Spring Boot configuration with env variables
│   ├── src/test/java/           # JUnit 5 & Mockito test suite
│   ├── Dockerfile               # Multi-stage container build
│   └── pom.xml                  # Maven dependencies and build plugins
├── database/
│   ├── schema.sql               # PostgreSQL DDL table definitions and indexes
│   └── seed.sql                 # Sample users, problems, and sessions
├── src/
│   ├── components/              # Modular UI components (Navbar, Sidebar, Modals, Heatmap)
│   ├── context/                 # AuthContext, ThemeContext, ToastContext
│   ├── pages/                   # Dashboard, Problems, Sessions, Analytics, Profile, Settings
│   ├── services/                # Axios API layer and synchronized local storage fallback
│   ├── types/                   # TypeScript interfaces & types
│   ├── App.tsx                  # App root and React Router tree
│   └── main.tsx
├── docker-compose.yml           # Complete containerized stack (Postgres + Backend)
├── .env.example                 # Environment configuration template
└── README.md
```

---

## 🚀 Quick Start Guide

### Option 1: Run with Docker Compose (Recommended)

Make sure you have Docker and Docker Compose installed, then run:

```bash
docker-compose up -d
```

This starts:
1. **PostgreSQL 16** on `localhost:5432` with auto-seeded initial data.
2. **Spring Boot Backend** on `http://localhost:8080`.

Then start the frontend:
```bash
npm install
npm run dev
```
Open `http://localhost:3000` (or `http://localhost:5173`) in your browser.

---

### Option 2: Local Development Setup

#### 1. PostgreSQL Database Setup
Create the database in PostgreSQL:
```sql
CREATE DATABASE coding_tracker;
```
Run the schema and seed scripts:
```bash
psql -U postgres -d coding_tracker -f database/schema.sql
psql -U postgres -d coding_tracker -f database/seed.sql
```

#### 2. Backend Setup & Run
Configure environment variables or copy `.env.example`.
```bash
cd backend
mvn clean install
mvn spring-boot:run
```
The backend starts at `http://localhost:8080`.

To run backend test suite:
```bash
mvn test
```

#### 3. Frontend Setup & Run
```bash
npm install
npm run dev
```

---

## 🔑 Default Credentials

| Username | Email | Password | Role |
| :--- | :--- | :--- | :--- |
| `demouser` | `demo@codingtracker.dev` | `Password123!` | `ROLE_USER` |
| `sarah_code` | `sarah@codingtracker.dev` | `Password123!` | `ROLE_USER` |

---

## 📡 REST API Reference

### Authentication (`/api/auth`)
- `POST /api/auth/register` - Create a new user account and obtain JWT token.
- `POST /api/auth/login` - Authenticate with username/email & password.
- `GET /api/auth/me` - Get current authenticated user profile (`Authorization: Bearer <token>`).
- `POST /api/auth/logout` - Stateless logout.

### Coding Problems (`/api/problems`)
- `GET /api/problems` - Retrieve problems with search (`keyword`), filter (`status`, `difficulty`, `topic`, `platform`), sorting, and pagination.
- `POST /api/problems` - Create a new problem record.
- `GET /api/problems/{id}` - Get problem details.
- `PUT /api/problems/{id}` - Update problem fields.
- `PATCH /api/problems/{id}/toggle` - Toggle Solved / Unsolved status.
- `DELETE /api/problems/{id}` - Delete a problem.

### Practice Sessions (`/api/sessions`)
- `GET /api/sessions` - Retrieve all practice sessions.
- `GET /api/sessions/paginated` - Retrieve paginated sessions.
- `POST /api/sessions` - Log a new practice block.
- `PUT /api/sessions/{id}` - Update practice session.
- `DELETE /api/sessions/{id}` - Delete session.

### Dashboard & Analytics (`/api/dashboard`, `/api/analytics`, `/api/streak`)
- `GET /api/dashboard` - Get comprehensive dashboard stats, goals, and recent activity.
- `GET /api/analytics` - Get aggregated topic mastery and monthly trends.
- `GET /api/streak` - Get current streak, longest streak, and 90-day heatmap intensity matrix.

---

## 🔒 Security Architecture

1. **Stateless JWT**: Standard Authorization header format `Bearer <token>`.
2. **BCrypt Hashing**: Passwords salted and hashed with BCrypt (strength 10).
3. **CORS Protected**: Configurable allowed origins via `CORS_ALLOWED_ORIGINS`.
4. **Input Sanitization**: Jakarta validation annotations on all DTOs.
5. **Exception Handling**: Standardized RFC-compliant JSON error responses via `@RestControllerAdvice`.
