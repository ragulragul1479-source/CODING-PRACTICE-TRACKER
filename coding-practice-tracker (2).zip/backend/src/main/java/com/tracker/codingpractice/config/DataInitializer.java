package com.tracker.codingpractice.config;

import com.tracker.codingpractice.entity.*;
import com.tracker.codingpractice.repository.CodingProblemRepository;
import com.tracker.codingpractice.repository.PracticeSessionRepository;
import com.tracker.codingpractice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final CodingProblemRepository codingProblemRepository;
    private final PracticeSessionRepository practiceSessionRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() == 0) {
            log.info("Seeding initial demo data into PostgreSQL...");

            // Create Demo User
            User demoUser = User.builder()
                    .username("demouser")
                    .email("demo@codingtracker.dev")
                    .password(passwordEncoder.encode("Password123!"))
                    .fullName("Alex Chen")
                    .bio("Software Engineer preparing for Senior / Staff System Design & LeetCode interviews.")
                    .targetDailyProblems(3)
                    .targetWeeklyHours(12.0)
                    .role(Role.ROLE_USER)
                    .build();

            User savedUser = userRepository.save(demoUser);

            LocalDate today = LocalDate.now();

            // Seed Problems
            List<CodingProblem> initialProblems = List.of(
                    CodingProblem.builder()
                            .title("Two Sum")
                            .description("Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.")
                            .difficulty(Difficulty.EASY)
                            .topic("Arrays & Hashing")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/two-sum/")
                            .solutionUrl("https://github.com/alexchen/leetcode/blob/main/two-sum.py")
                            .notes("Used HashMap for O(n) single-pass lookup with complement value.")
                            .status(ProblemStatus.SOLVED)
                            .solvedDate(today.minusDays(6))
                            .timeSpentMinutes(15)
                            .user(savedUser)
                            .build(),
                    CodingProblem.builder()
                            .title("Valid Anagram")
                            .description("Given two strings s and t, return true if t is an anagram of s, and false otherwise.")
                            .difficulty(Difficulty.EASY)
                            .topic("Arrays & Hashing")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/valid-anagram/")
                            .notes("Character frequency array of size 26 or dictionary counter.")
                            .status(ProblemStatus.SOLVED)
                            .solvedDate(today.minusDays(5))
                            .timeSpentMinutes(10)
                            .user(savedUser)
                            .build(),
                    CodingProblem.builder()
                            .title("Longest Substring Without Repeating Characters")
                            .description("Given a string s, find the length of the longest substring without repeating characters.")
                            .difficulty(Difficulty.MEDIUM)
                            .topic("Sliding Window")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/longest-substring-without-repeating-characters/")
                            .notes("Sliding window with left/right pointers and HashSet of current window characters.")
                            .status(ProblemStatus.SOLVED)
                            .solvedDate(today.minusDays(4))
                            .timeSpentMinutes(35)
                            .user(savedUser)
                            .build(),
                    CodingProblem.builder()
                            .title("Container With Most Water")
                            .description("You are given an integer array height of length n. Find two lines that together with the x-axis form a container, such that the container contains the most water.")
                            .difficulty(Difficulty.MEDIUM)
                            .topic("Two Pointers")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/container-with-most-water/")
                            .notes("Two pointers at both ends, shrink the pointer with smaller height.")
                            .status(ProblemStatus.SOLVED)
                            .solvedDate(today.minusDays(3))
                            .timeSpentMinutes(25)
                            .user(savedUser)
                            .build(),
                    CodingProblem.builder()
                            .title("Invert Binary Tree")
                            .description("Given the root of a binary tree, invert the tree, and return its root.")
                            .difficulty(Difficulty.EASY)
                            .topic("Trees")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/invert-binary-tree/")
                            .notes("Classic recursive DFS swap left and right subtrees.")
                            .status(ProblemStatus.SOLVED)
                            .solvedDate(today.minusDays(2))
                            .timeSpentMinutes(12)
                            .user(savedUser)
                            .build(),
                    CodingProblem.builder()
                            .title("LRU Cache")
                            .description("Design a data structure that follows the constraints of a Least Recently Used (LRU) cache.")
                            .difficulty(Difficulty.MEDIUM)
                            .topic("Design")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/lru-cache/")
                            .notes("Doubly linked list + HashMap for O(1) get and put.")
                            .status(ProblemStatus.SOLVED)
                            .solvedDate(today.minusDays(1))
                            .timeSpentMinutes(45)
                            .user(savedUser)
                            .build(),
                    CodingProblem.builder()
                            .title("Trapping Rain Water")
                            .description("Given n non-negative integers representing an elevation map where the width of each bar is 1, compute how much water it can trap after raining.")
                            .difficulty(Difficulty.HARD)
                            .topic("Two Pointers")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/trapping-rain-water/")
                            .notes("Two pointers tracking leftMax and rightMax with O(1) space.")
                            .status(ProblemStatus.SOLVED)
                            .solvedDate(today)
                            .timeSpentMinutes(50)
                            .user(savedUser)
                            .build(),
                    CodingProblem.builder()
                            .title("Coin Change")
                            .description("You are given an integer array coins representing coins of different denominations and an integer amount representing a total amount of money.")
                            .difficulty(Difficulty.MEDIUM)
                            .topic("Dynamic Programming")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/coin-change/")
                            .notes("Bottom-up DP table where dp[i] = min(dp[i], dp[i - c] + 1).")
                            .status(ProblemStatus.UNSOLVED)
                            .timeSpentMinutes(0)
                            .user(savedUser)
                            .build(),
                    CodingProblem.builder()
                            .title("Word Ladder")
                            .description("A transformation sequence from word beginWord to word endWord using a dictionary wordList.")
                            .difficulty(Difficulty.HARD)
                            .topic("Graphs")
                            .platform("LeetCode")
                            .problemUrl("https://leetcode.com/problems/word-ladder/")
                            .notes("BFS shortest path with intermediate pattern wildcard matching.")
                            .status(ProblemStatus.UNSOLVED)
                            .timeSpentMinutes(0)
                            .user(savedUser)
                            .build()
            );
            codingProblemRepository.saveAll(initialProblems);

            // Seed Practice Sessions
            List<PracticeSession> sessions = List.of(
                    PracticeSession.builder()
                            .sessionDate(today.minusDays(6))
                            .durationMinutes(60)
                            .problemsSolvedCount(2)
                            .topicFocus("Arrays & Hashing")
                            .notes("Warmup session on basic array manipulation.")
                            .user(savedUser)
                            .build(),
                    PracticeSession.builder()
                            .sessionDate(today.minusDays(5))
                            .durationMinutes(75)
                            .problemsSolvedCount(2)
                            .topicFocus("Strings & HashMaps")
                            .notes("Solved frequency matching and anagrams.")
                            .user(savedUser)
                            .build(),
                    PracticeSession.builder()
                            .sessionDate(today.minusDays(4))
                            .durationMinutes(90)
                            .problemsSolvedCount(3)
                            .topicFocus("Sliding Window")
                            .notes("Practiced dynamic window sizing.")
                            .user(savedUser)
                            .build(),
                    PracticeSession.builder()
                            .sessionDate(today.minusDays(3))
                            .durationMinutes(80)
                            .problemsSolvedCount(2)
                            .topicFocus("Two Pointers")
                            .notes("Fast & slow pointer and inward scan.")
                            .user(savedUser)
                            .build(),
                    PracticeSession.builder()
                            .sessionDate(today.minusDays(2))
                            .durationMinutes(90)
                            .problemsSolvedCount(2)
                            .topicFocus("Trees & Binary Search Trees")
                            .notes("Tree traversals, height computation, LCA.")
                            .user(savedUser)
                            .build(),
                    PracticeSession.builder()
                            .sessionDate(today.minusDays(1))
                            .durationMinutes(110)
                            .problemsSolvedCount(3)
                            .topicFocus("System Design & Data Structure Design")
                            .notes("LRU cache and LFU cache implementation.")
                            .user(savedUser)
                            .build(),
                    PracticeSession.builder()
                            .sessionDate(today)
                            .durationMinutes(95)
                            .problemsSolvedCount(2)
                            .topicFocus("Hard Two Pointers & Monotonic Stack")
                            .notes("Trapping rain water & largest rectangle in histogram.")
                            .user(savedUser)
                            .build()
            );
            practiceSessionRepository.saveAll(sessions);

            log.info("Demo user, problems, and practice sessions seeded successfully.");
        }
    }
}
