package com.tracker.codingpractice.controller;

import com.tracker.codingpractice.dto.AnalyticsResponse;
import com.tracker.codingpractice.dto.ApiResponse;
import com.tracker.codingpractice.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/analytics")
@RequiredArgsConstructor
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @GetMapping
    public ResponseEntity<ApiResponse<AnalyticsResponse>> getAnalytics() {
        AnalyticsResponse analytics = analyticsService.getAnalyticsData();
        return ResponseEntity.ok(ApiResponse.ok(analytics));
    }
}
