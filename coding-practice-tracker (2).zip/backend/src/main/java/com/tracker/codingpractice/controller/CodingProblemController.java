package com.tracker.codingpractice.controller;

import com.tracker.codingpractice.dto.*;
import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.ProblemStatus;
import com.tracker.codingpractice.service.CodingProblemService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/problems")
@RequiredArgsConstructor
public class CodingProblemController {

    private final CodingProblemService codingProblemService;

    @PostMapping
    public ResponseEntity<ApiResponse<CodingProblemDTO>> createProblem(@Valid @RequestBody CodingProblemCreateRequest request) {
        CodingProblemDTO created = codingProblemService.createProblem(request);
        return new ResponseEntity<>(ApiResponse.ok(created, "Problem created successfully"), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<ApiResponse<PageResponse<CodingProblemDTO>>> getProblems(
            @RequestParam(required = false) ProblemStatus status,
            @RequestParam(required = false) Difficulty difficulty,
            @RequestParam(required = false) String topic,
            @RequestParam(required = false) String platform,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String sortDirection
    ) {
        PageResponse<CodingProblemDTO> problems = codingProblemService.getProblems(
                status, difficulty, topic, platform, keyword, page, size, sortBy, sortDirection
        );
        return ResponseEntity.ok(ApiResponse.ok(problems));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<CodingProblemDTO>> getProblemById(@PathVariable Long id) {
        CodingProblemDTO problem = codingProblemService.getProblemById(id);
        return ResponseEntity.ok(ApiResponse.ok(problem));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<CodingProblemDTO>> updateProblem(
            @PathVariable Long id,
            @Valid @RequestBody CodingProblemUpdateRequest request
    ) {
        CodingProblemDTO updated = codingProblemService.updateProblem(id, request);
        return ResponseEntity.ok(ApiResponse.ok(updated, "Problem updated successfully"));
    }

    @PatchMapping("/{id}/toggle")
    public ResponseEntity<ApiResponse<CodingProblemDTO>> toggleStatus(@PathVariable Long id) {
        CodingProblemDTO updated = codingProblemService.toggleStatus(id);
        return ResponseEntity.ok(ApiResponse.ok(updated, "Problem status updated"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteProblem(@PathVariable Long id) {
        codingProblemService.deleteProblem(id);
        return ResponseEntity.ok(ApiResponse.ok(null, "Problem deleted successfully"));
    }
}
