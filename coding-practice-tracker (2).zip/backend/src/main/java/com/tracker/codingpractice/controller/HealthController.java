package com.tracker.codingpractice.controller;

import com.tracker.codingpractice.dto.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/health")
public class HealthController {

    @GetMapping
    public ResponseEntity<ApiResponse<Map<String, Object>>> healthCheck() {
        return ResponseEntity.ok(ApiResponse.ok(
                Map.of(
                        "status", "UP",
                        "service", "Coding Practice Tracker API",
                        "version", "1.0.0",
                        "javaVersion", System.getProperty("java.version")
                ),
                "Service is running smoothly"
        ));
    }
}
