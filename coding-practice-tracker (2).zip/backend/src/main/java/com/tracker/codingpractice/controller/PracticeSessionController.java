package com.tracker.codingpractice.controller;

import com.tracker.codingpractice.dto.ApiResponse;
import com.tracker.codingpractice.dto.PageResponse;
import com.tracker.codingpractice.dto.PracticeSessionDTO;
import com.tracker.codingpractice.dto.PracticeSessionRequest;
import com.tracker.codingpractice.service.PracticeSessionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sessions")
@RequiredArgsConstructor
public class PracticeSessionController {

    private final PracticeSessionService practiceSessionService;

    @PostMapping
    public ResponseEntity<ApiResponse<PracticeSessionDTO>> createSession(@Valid @RequestBody PracticeSessionRequest request) {
        PracticeSessionDTO created = practiceSessionService.createSession(request);
        return new ResponseEntity<>(ApiResponse.ok(created, "Practice session recorded successfully"), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<PracticeSessionDTO>>> getAllSessions() {
        List<PracticeSessionDTO> sessions = practiceSessionService.getAllSessions();
        return ResponseEntity.ok(ApiResponse.ok(sessions));
    }

    @GetMapping("/paginated")
    public ResponseEntity<ApiResponse<PageResponse<PracticeSessionDTO>>> getSessionsPaginated(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        PageResponse<PracticeSessionDTO> sessions = practiceSessionService.getSessionsPaginated(page, size);
        return ResponseEntity.ok(ApiResponse.ok(sessions));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<PracticeSessionDTO>> getSessionById(@PathVariable Long id) {
        PracticeSessionDTO session = practiceSessionService.getSessionById(id);
        return ResponseEntity.ok(ApiResponse.ok(session));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<PracticeSessionDTO>> updateSession(
            @PathVariable Long id,
            @Valid @RequestBody PracticeSessionRequest request
    ) {
        PracticeSessionDTO updated = practiceSessionService.updateSession(id, request);
        return ResponseEntity.ok(ApiResponse.ok(updated, "Practice session updated successfully"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteSession(@PathVariable Long id) {
        practiceSessionService.deleteSession(id);
        return ResponseEntity.ok(ApiResponse.ok(null, "Practice session deleted successfully"));
    }
}
