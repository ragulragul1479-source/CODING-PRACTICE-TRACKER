package com.tracker.codingpractice.controller;

import com.tracker.codingpractice.dto.ApiResponse;
import com.tracker.codingpractice.dto.StreakResponse;
import com.tracker.codingpractice.service.StreakService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/streak")
@RequiredArgsConstructor
public class StreakController {

    private final StreakService streakService;

    @GetMapping
    public ResponseEntity<ApiResponse<StreakResponse>> getStreak() {
        StreakResponse streak = streakService.calculateStreak();
        return ResponseEntity.ok(ApiResponse.ok(streak));
    }
}
