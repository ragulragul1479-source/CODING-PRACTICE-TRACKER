package com.tracker.codingpractice.controller;

import com.tracker.codingpractice.dto.ApiResponse;
import com.tracker.codingpractice.dto.ChangePasswordRequest;
import com.tracker.codingpractice.dto.UpdateProfileRequest;
import com.tracker.codingpractice.dto.UserDTO;
import com.tracker.codingpractice.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final AuthService authService;

    @GetMapping("/profile")
    public ResponseEntity<ApiResponse<UserDTO>> getProfile() {
        return ResponseEntity.ok(ApiResponse.ok(authService.getCurrentUserDTO()));
    }

    @PutMapping("/profile")
    public ResponseEntity<ApiResponse<UserDTO>> updateProfile(@Valid @RequestBody UpdateProfileRequest request) {
        UserDTO updated = authService.updateProfile(request);
        return ResponseEntity.ok(ApiResponse.ok(updated, "Profile updated successfully"));
    }

    @PutMapping("/password")
    public ResponseEntity<ApiResponse<String>> changePassword(@Valid @RequestBody ChangePasswordRequest request) {
        authService.changePassword(request);
        return ResponseEntity.ok(ApiResponse.ok("Password changed successfully", "Password updated successfully"));
    }
}
