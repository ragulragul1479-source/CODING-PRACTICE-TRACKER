package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnalyticsResponse {
    private long totalProblems;
    private long totalSolved;
    private double totalHours;
    private DifficultyStatsDTO difficultyStats;
    private List<TopicStatDTO> topicStats;
    private List<PlatformStatDTO> platformStats;
    private List<DailyActivityDTO> solvedOverTime;
    private List<MonthlyStatDTO> monthlyStats;
    private Map<String, Integer> dayOfWeekDistribution;
}
