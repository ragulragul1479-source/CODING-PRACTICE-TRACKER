package com.tracker.codingpractice.dto;

import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.ProblemStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CodingProblemCreateRequest {

    @NotBlank(message = "Problem title is required")
    @Size(max = 200, message = "Title must not exceed 200 characters")
    private String title;

    private String description;

    @NotNull(message = "Difficulty is required")
    private Difficulty difficulty;

    @NotBlank(message = "Topic is required")
    @Size(max = 80, message = "Topic must not exceed 80 characters")
    private String topic;

    @NotBlank(message = "Platform is required")
    @Size(max = 60, message = "Platform must not exceed 60 characters")
    private String platform;

    private String problemUrl;

    private String solutionUrl;

    private String notes;

    @Builder.Default
    private ProblemStatus status = ProblemStatus.UNSOLVED;

    private LocalDate solvedDate;

    @Builder.Default
    private Integer timeSpentMinutes = 0;
}
