package com.tracker.codingpractice.dto;

import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.ProblemStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CodingProblemDTO {
    private Long id;
    private String title;
    private String description;
    private Difficulty difficulty;
    private String topic;
    private String platform;
    private String problemUrl;
    private String solutionUrl;
    private String notes;
    private ProblemStatus status;
    private LocalDate solvedDate;
    private Integer timeSpentMinutes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
