package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DailyActivityDTO {
    private LocalDate date;
    private int problemsSolved;
    private int minutesPracticed;
    private int count; // total intensity level (e.g., 0 to 4+)
    private int level; // 0, 1, 2, 3, 4 for heatmap color
}
