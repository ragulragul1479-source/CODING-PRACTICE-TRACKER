package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardResponse {
    private long totalProblems;
    private long totalSolvedProblems;
    private long totalUnsolvedProblems;
    private double completionRate;
    private double totalPracticeHours;
    private int currentStreak;
    private int longestStreak;
    private boolean practicedToday;
    private DifficultyStatsDTO difficultyStats;
    private WeeklyMonthlyProgressDTO progress;
    private List<RecentActivityDTO> recentActivities;
    private List<DailyActivityDTO> activityHeatmap;
}
