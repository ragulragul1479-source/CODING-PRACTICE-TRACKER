package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DifficultyStatsDTO {
    private long easySolved;
    private long easyTotal;
    private long mediumSolved;
    private long mediumTotal;
    private long hardSolved;
    private long hardTotal;
}
