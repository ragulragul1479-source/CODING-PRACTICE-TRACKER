package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MonthlyStatDTO {
    private String month; // e.g. "2024-05", "May 2024"
    private int problemsSolved;
    private double hoursPracticed;
    private int activeDays;
}
