package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PracticeSessionDTO {
    private Long id;
    private LocalDate sessionDate;
    private Integer durationMinutes;
    private Integer problemsSolvedCount;
    private String topicFocus;
    private String notes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
