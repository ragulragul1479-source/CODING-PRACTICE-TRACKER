package com.tracker.codingpractice.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PracticeSessionRequest {

    @NotNull(message = "Session date is required")
    private LocalDate sessionDate;

    @NotNull(message = "Duration in minutes is required")
    @Min(value = 1, message = "Duration must be at least 1 minute")
    private Integer durationMinutes;

    @NotNull(message = "Problems solved count is required")
    @Min(value = 0, message = "Problems solved count cannot be negative")
    private Integer problemsSolvedCount;

    @Size(max = 100, message = "Topic focus must not exceed 100 characters")
    private String topicFocus;

    private String notes;
}
