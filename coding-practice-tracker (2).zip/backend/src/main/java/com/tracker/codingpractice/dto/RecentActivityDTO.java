package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RecentActivityDTO {
    private String id;
    private String type; // "PROBLEM_SOLVED", "PROBLEM_ADDED", "PRACTICE_SESSION"
    private String title;
    private String subtitle;
    private String difficultyOrTopic;
    private LocalDateTime timestamp;
}
