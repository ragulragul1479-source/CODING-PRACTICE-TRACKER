package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StreakResponse {
    private int currentStreak;
    private int longestStreak;
    private boolean activeToday;
    private LocalDate lastActiveDate;
    private int totalActiveDays;
    private List<LocalDate> activeDates;
    private List<DailyActivityDTO> activityHistory;
}
