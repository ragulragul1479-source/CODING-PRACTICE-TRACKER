package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopicStatDTO {
    private String topic;
    private long total;
    private long solved;
    private double percentage;
}
