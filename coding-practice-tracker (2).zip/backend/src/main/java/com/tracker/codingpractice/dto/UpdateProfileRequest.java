package com.tracker.codingpractice.dto;

import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateProfileRequest {
    @Size(max = 100)
    private String fullName;

    @Size(max = 255)
    private String bio;

    private Integer targetDailyProblems;

    private Double targetWeeklyHours;
}
