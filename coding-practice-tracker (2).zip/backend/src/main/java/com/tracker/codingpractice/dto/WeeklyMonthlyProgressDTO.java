package com.tracker.codingpractice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WeeklyMonthlyProgressDTO {
    private int problemsSolvedThisWeek;
    private int problemsSolvedThisMonth;
    private double hoursSpentThisWeek;
    private double hoursSpentThisMonth;
    private int targetDailyProblems;
    private double targetWeeklyHours;
    private double weeklyGoalPercentage;
}
