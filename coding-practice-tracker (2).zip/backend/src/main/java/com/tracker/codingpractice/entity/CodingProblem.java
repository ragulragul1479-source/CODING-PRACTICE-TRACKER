package com.tracker.codingpractice.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "coding_problems", indexes = {
    @Index(name = "idx_problems_user_id", columnList = "user_id"),
    @Index(name = "idx_problems_status", columnList = "status"),
    @Index(name = "idx_problems_difficulty", columnList = "difficulty"),
    @Index(name = "idx_problems_topic", columnList = "topic"),
    @Index(name = "idx_problems_solved_date", columnList = "solved_date")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CodingProblem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Difficulty difficulty;

    @Column(nullable = false, length = 80)
    private String topic;

    @Column(nullable = false, length = 60)
    private String platform; // LeetCode, HackerRank, Codeforces, NeetCode, etc.

    @Column(name = "problem_url", length = 500)
    private String problemUrl;

    @Column(name = "solution_url", length = 500)
    private String solutionUrl;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private ProblemStatus status = ProblemStatus.UNSOLVED;

    @Column(name = "solved_date")
    private LocalDate solvedDate;

    @Column(name = "time_spent_minutes")
    @Builder.Default
    private Integer timeSpentMinutes = 0;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
