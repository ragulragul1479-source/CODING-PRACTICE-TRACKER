package com.tracker.codingpractice.entity;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD
}
