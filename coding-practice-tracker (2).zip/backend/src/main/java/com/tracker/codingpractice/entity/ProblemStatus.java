package com.tracker.codingpractice.entity;

public enum ProblemStatus {
    SOLVED,
    UNSOLVED
}
