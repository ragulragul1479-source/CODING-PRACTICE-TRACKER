package com.tracker.codingpractice.repository;

import com.tracker.codingpractice.entity.CodingProblem;
import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.ProblemStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface CodingProblemRepository extends JpaRepository<CodingProblem, Long> {

    Optional<CodingProblem> findByIdAndUserId(Long id, Long userId);

    List<CodingProblem> findAllByUserId(Long userId);

    @Query("SELECT p FROM CodingProblem p WHERE p.user.id = :userId " +
           "AND (:status IS NULL OR p.status = :status) " +
           "AND (:difficulty IS NULL OR p.difficulty = :difficulty) " +
           "AND (:topic IS NULL OR LOWER(p.topic) = LOWER(:topic)) " +
           "AND (:platform IS NULL OR LOWER(p.platform) = LOWER(:platform)) " +
           "AND (:keyword IS NULL OR LOWER(p.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "     OR LOWER(p.notes) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
           "     OR LOWER(p.topic) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<CodingProblem> searchProblems(
            @Param("userId") Long userId,
            @Param("status") ProblemStatus status,
            @Param("difficulty") Difficulty difficulty,
            @Param("topic") String topic,
            @Param("platform") String platform,
            @Param("keyword") String keyword,
            Pageable pageable
    );

    long countByUserId(Long userId);

    long countByUserIdAndStatus(Long userId, ProblemStatus status);

    long countByUserIdAndDifficulty(Long userId, Difficulty difficulty);

    long countByUserIdAndStatusAndDifficulty(Long userId, ProblemStatus status, Difficulty difficulty);

    @Query("SELECT DISTINCT p.solvedDate FROM CodingProblem p " +
           "WHERE p.user.id = :userId AND p.status = 'SOLVED' AND p.solvedDate IS NOT NULL")
    List<LocalDate> findDistinctSolvedDatesByUserId(@Param("userId") Long userId);

    @Query("SELECT p.topic, COUNT(p) FROM CodingProblem p WHERE p.user.id = :userId GROUP BY p.topic")
    List<Object[]> countProblemsByTopic(@Param("userId") Long userId);

    @Query("SELECT p.platform, COUNT(p) FROM CodingProblem p WHERE p.user.id = :userId GROUP BY p.platform")
    List<Object[]> countProblemsByPlatform(@Param("userId") Long userId);

    List<CodingProblem> findTop5ByUserIdOrderByCreatedAtDesc(Long userId);
}
