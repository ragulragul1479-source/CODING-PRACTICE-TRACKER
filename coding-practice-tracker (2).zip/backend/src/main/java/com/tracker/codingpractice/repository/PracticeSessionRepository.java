package com.tracker.codingpractice.repository;

import com.tracker.codingpractice.entity.PracticeSession;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface PracticeSessionRepository extends JpaRepository<PracticeSession, Long> {

    Optional<PracticeSession> findByIdAndUserId(Long id, Long userId);

    List<PracticeSession> findAllByUserIdOrderBySessionDateDesc(Long userId);

    Page<PracticeSession> findAllByUserId(Long userId, Pageable pageable);

    @Query("SELECT COALESCE(SUM(s.durationMinutes), 0) FROM PracticeSession s WHERE s.user.id = :userId")
    Long sumDurationMinutesByUserId(@Param("userId") Long userId);

    @Query("SELECT COALESCE(SUM(s.durationMinutes), 0) FROM PracticeSession s " +
           "WHERE s.user.id = :userId AND s.sessionDate >= :startDate")
    Long sumDurationMinutesByUserIdAndSessionDateAfter(
            @Param("userId") Long userId,
            @Param("startDate") LocalDate startDate
    );

    @Query("SELECT DISTINCT s.sessionDate FROM PracticeSession s WHERE s.user.id = :userId")
    List<LocalDate> findDistinctSessionDatesByUserId(@Param("userId") Long userId);

    @Query("SELECT s.sessionDate, SUM(s.durationMinutes), SUM(s.problemsSolvedCount) " +
           "FROM PracticeSession s WHERE s.user.id = :userId " +
           "GROUP BY s.sessionDate ORDER BY s.sessionDate ASC")
    List<Object[]> findDailySessionAggregates(@Param("userId") Long userId);

    List<PracticeSession> findTop5ByUserIdOrderBySessionDateDescCreatedAtDesc(Long userId);
}
