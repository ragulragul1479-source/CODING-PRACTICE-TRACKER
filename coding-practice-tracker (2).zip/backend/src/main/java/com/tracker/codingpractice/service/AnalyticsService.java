package com.tracker.codingpractice.service;

import com.tracker.codingpractice.dto.*;
import com.tracker.codingpractice.entity.CodingProblem;
import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.PracticeSession;
import com.tracker.codingpractice.entity.ProblemStatus;
import com.tracker.codingpractice.entity.User;
import com.tracker.codingpractice.repository.CodingProblemRepository;
import com.tracker.codingpractice.repository.PracticeSessionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@RequiredArgsConstructor
public class AnalyticsService {

    private final CodingProblemRepository codingProblemRepository;
    private final PracticeSessionRepository practiceSessionRepository;
    private final StreakService streakService;
    private final AuthService authService;

    @Transactional(readOnly = true)
    public AnalyticsResponse getAnalyticsData() {
        User currentUser = authService.getCurrentAuthenticatedUser();
        Long userId = currentUser.getId();

        long totalProblems = codingProblemRepository.countByUserId(userId);
        long totalSolved = codingProblemRepository.countByUserIdAndStatus(userId, ProblemStatus.SOLVED);
        Long totalMinutes = practiceSessionRepository.sumDurationMinutesByUserId(userId);
        double totalHours = totalMinutes != null ? Math.round((totalMinutes / 60.0) * 10.0) / 10.0 : 0.0;

        // Difficulty stats
        long easySolved = codingProblemRepository.countByUserIdAndStatusAndDifficulty(userId, ProblemStatus.SOLVED, Difficulty.EASY);
        long easyTotal = codingProblemRepository.countByUserIdAndDifficulty(userId, Difficulty.EASY);
        long mediumSolved = codingProblemRepository.countByUserIdAndStatusAndDifficulty(userId, ProblemStatus.SOLVED, Difficulty.MEDIUM);
        long mediumTotal = codingProblemRepository.countByUserIdAndDifficulty(userId, Difficulty.MEDIUM);
        long hardSolved = codingProblemRepository.countByUserIdAndStatusAndDifficulty(userId, ProblemStatus.SOLVED, Difficulty.HARD);
        long hardTotal = codingProblemRepository.countByUserIdAndDifficulty(userId, Difficulty.HARD);

        DifficultyStatsDTO difficultyStats = DifficultyStatsDTO.builder()
                .easySolved(easySolved)
                .easyTotal(easyTotal)
                .mediumSolved(mediumSolved)
                .mediumTotal(mediumTotal)
                .hardSolved(hardSolved)
                .hardTotal(hardTotal)
                .build();

        // Topic stats
        List<Object[]> topicCounts = codingProblemRepository.countProblemsByTopic(userId);
        List<TopicStatDTO> topicStats = new ArrayList<>();
        List<CodingProblem> allProblems = codingProblemRepository.findAllByUserId(userId);
        Map<String, Long> solvedByTopic = new HashMap<>();

        for (CodingProblem p : allProblems) {
            if (p.getStatus() == ProblemStatus.SOLVED) {
                solvedByTopic.put(p.getTopic(), solvedByTopic.getOrDefault(p.getTopic(), 0L) + 1);
            }
        }

        for (Object[] row : topicCounts) {
            String topic = (String) row[0];
            long total = ((Number) row[1]).longValue();
            long solved = solvedByTopic.getOrDefault(topic, 0L);
            double pct = total > 0 ? Math.round(((double) solved / total) * 1000.0) / 10.0 : 0.0;
            topicStats.add(TopicStatDTO.builder()
                    .topic(topic)
                    .total(total)
                    .solved(solved)
                    .percentage(pct)
                    .build());
        }
        topicStats.sort(Comparator.comparing(TopicStatDTO::getTotal).reversed());

        // Platform stats
        List<Object[]> platformCounts = codingProblemRepository.countProblemsByPlatform(userId);
        List<PlatformStatDTO> platformStats = new ArrayList<>();
        for (Object[] row : platformCounts) {
            String platform = (String) row[0];
            long count = ((Number) row[1]).longValue();
            double pct = totalProblems > 0 ? Math.round(((double) count / totalProblems) * 1000.0) / 10.0 : 0.0;
            platformStats.add(PlatformStatDTO.builder()
                    .platform(platform)
                    .count(count)
                    .percentage(pct)
                    .build());
        }
        platformStats.sort(Comparator.comparing(PlatformStatDTO::getCount).reversed());

        // Solved over time / Daily activity (past 90 days)
        List<DailyActivityDTO> solvedOverTime = streakService.generateDailyActivityHeatmap(userId, 90);

        // Monthly stats (past 6 months)
        List<MonthlyStatDTO> monthlyStats = calculateMonthlyStats(userId);

        // Day of week distribution
        Map<String, Integer> dayOfWeekDistribution = calculateDayOfWeekDistribution(allProblems, practiceSessionRepository.findAllByUserIdOrderBySessionDateDesc(userId));

        return AnalyticsResponse.builder()
                .totalProblems(totalProblems)
                .totalSolved(totalSolved)
                .totalHours(totalHours)
                .difficultyStats(difficultyStats)
                .topicStats(topicStats)
                .platformStats(platformStats)
                .solvedOverTime(solvedOverTime)
                .monthlyStats(monthlyStats)
                .dayOfWeekDistribution(dayOfWeekDistribution)
                .build();
    }

    private List<MonthlyStatDTO> calculateMonthlyStats(Long userId) {
        LocalDate now = LocalDate.now();
        List<MonthlyStatDTO> result = new ArrayList<>();
        DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("MMM yyyy");
        DateTimeFormatter keyFormatter = DateTimeFormatter.ofPattern("yyyy-MM");

        List<PracticeSession> sessions = practiceSessionRepository.findAllByUserIdOrderBySessionDateDesc(userId);
        List<CodingProblem> problems = codingProblemRepository.findAllByUserId(userId);

        for (int i = 5; i >= 0; i--) {
            LocalDate monthDate = now.minusMonths(i);
            String monthKey = monthDate.format(keyFormatter);
            String displayMonth = monthDate.format(monthFormatter);

            int solvedCount = 0;
            for (CodingProblem p : problems) {
                if (p.getStatus() == ProblemStatus.SOLVED && p.getSolvedDate() != null) {
                    if (p.getSolvedDate().format(keyFormatter).equals(monthKey)) {
                        solvedCount++;
                    }
                }
            }

            int minutes = 0;
            Set<LocalDate> activeDaysInMonth = new HashSet<>();
            for (PracticeSession s : sessions) {
                if (s.getSessionDate().format(keyFormatter).equals(monthKey)) {
                    minutes += s.getDurationMinutes();
                    activeDaysInMonth.add(s.getSessionDate());
                }
            }

            for (CodingProblem p : problems) {
                if (p.getStatus() == ProblemStatus.SOLVED && p.getSolvedDate() != null) {
                    if (p.getSolvedDate().format(keyFormatter).equals(monthKey)) {
                        activeDaysInMonth.add(p.getSolvedDate());
                    }
                }
            }

            result.add(MonthlyStatDTO.builder()
                    .month(displayMonth)
                    .problemsSolved(solvedCount)
                    .hoursPracticed(Math.round((minutes / 60.0) * 10.0) / 10.0)
                    .activeDays(activeDaysInMonth.size())
                    .build());
        }

        return result;
    }

    private Map<String, Integer> calculateDayOfWeekDistribution(List<CodingProblem> problems, List<PracticeSession> sessions) {
        Map<String, Integer> dist = new LinkedHashMap<>();
        dist.put("Mon", 0);
        dist.put("Tue", 0);
        dist.put("Wed", 0);
        dist.put("Thu", 0);
        dist.put("Fri", 0);
        dist.put("Sat", 0);
        dist.put("Sun", 0);

        for (PracticeSession s : sessions) {
            String day = s.getSessionDate().getDayOfWeek().toString().substring(0, 1) + s.getSessionDate().getDayOfWeek().toString().substring(1, 3).toLowerCase();
            dist.put(day, dist.getOrDefault(day, 0) + 1);
        }

        for (CodingProblem p : problems) {
            if (p.getStatus() == ProblemStatus.SOLVED && p.getSolvedDate() != null) {
                String day = p.getSolvedDate().getDayOfWeek().toString().substring(0, 1) + p.getSolvedDate().getDayOfWeek().toString().substring(1, 3).toLowerCase();
                dist.put(day, dist.getOrDefault(day, 0) + 1);
            }
        }

        return dist;
    }
}
