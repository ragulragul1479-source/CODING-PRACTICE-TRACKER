package com.tracker.codingpractice.service;

import com.tracker.codingpractice.dto.*;
import com.tracker.codingpractice.entity.CodingProblem;
import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.ProblemStatus;
import com.tracker.codingpractice.entity.User;
import com.tracker.codingpractice.exception.ResourceNotFoundException;
import com.tracker.codingpractice.repository.CodingProblemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class CodingProblemService {

    private final CodingProblemRepository codingProblemRepository;
    private final AuthService authService;

    @Transactional
    public CodingProblemDTO createProblem(CodingProblemCreateRequest request) {
        User currentUser = authService.getCurrentAuthenticatedUser();

        LocalDate solvedDate = request.getSolvedDate();
        if (request.getStatus() == ProblemStatus.SOLVED && solvedDate == null) {
            solvedDate = LocalDate.now();
        } else if (request.getStatus() == ProblemStatus.UNSOLVED) {
            solvedDate = null;
        }

        CodingProblem problem = CodingProblem.builder()
                .title(request.getTitle().trim())
                .description(request.getDescription())
                .difficulty(request.getDifficulty())
                .topic(request.getTopic().trim())
                .platform(request.getPlatform().trim())
                .problemUrl(request.getProblemUrl())
                .solutionUrl(request.getSolutionUrl())
                .notes(request.getNotes())
                .status(request.getStatus())
                .solvedDate(solvedDate)
                .timeSpentMinutes(request.getTimeSpentMinutes() != null ? request.getTimeSpentMinutes() : 0)
                .user(currentUser)
                .build();

        CodingProblem saved = codingProblemRepository.save(problem);
        return mapToDTO(saved);
    }

    @Transactional(readOnly = true)
    public PageResponse<CodingProblemDTO> getProblems(
            ProblemStatus status,
            Difficulty difficulty,
            String topic,
            String platform,
            String keyword,
            int page,
            int size,
            String sortBy,
            String sortDirection
    ) {
        User currentUser = authService.getCurrentAuthenticatedUser();

        Sort sort = Sort.by(
                "desc".equalsIgnoreCase(sortDirection) ? Sort.Direction.DESC : Sort.Direction.ASC,
                sortBy != null && !sortBy.isBlank() ? sortBy : "createdAt"
        );
        Pageable pageable = PageRequest.of(Math.max(0, page), size > 0 ? size : 10, sort);

        Page<CodingProblem> problemPage = codingProblemRepository.searchProblems(
                currentUser.getId(),
                status,
                difficulty,
                (topic != null && !topic.isBlank()) ? topic.trim() : null,
                (platform != null && !platform.isBlank()) ? platform.trim() : null,
                (keyword != null && !keyword.isBlank()) ? keyword.trim() : null,
                pageable
        );

        return PageResponse.from(problemPage.map(this::mapToDTO));
    }

    @Transactional(readOnly = true)
    public CodingProblemDTO getProblemById(Long id) {
        User currentUser = authService.getCurrentAuthenticatedUser();
        CodingProblem problem = codingProblemRepository.findByIdAndUserId(id, currentUser.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Problem not found with id: " + id));
        return mapToDTO(problem);
    }

    @Transactional
    public CodingProblemDTO updateProblem(Long id, CodingProblemUpdateRequest request) {
        User currentUser = authService.getCurrentAuthenticatedUser();
        CodingProblem problem = codingProblemRepository.findByIdAndUserId(id, currentUser.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Problem not found with id: " + id));

        LocalDate solvedDate = request.getSolvedDate();
        if (request.getStatus() == ProblemStatus.SOLVED && solvedDate == null) {
            solvedDate = problem.getSolvedDate() != null ? problem.getSolvedDate() : LocalDate.now();
        } else if (request.getStatus() == ProblemStatus.UNSOLVED) {
            solvedDate = null;
        }

        problem.setTitle(request.getTitle().trim());
        problem.setDescription(request.getDescription());
        problem.setDifficulty(request.getDifficulty());
        problem.setTopic(request.getTopic().trim());
        problem.setPlatform(request.getPlatform().trim());
        problem.setProblemUrl(request.getProblemUrl());
        problem.setSolutionUrl(request.getSolutionUrl());
        problem.setNotes(request.getNotes());
        problem.setStatus(request.getStatus());
        problem.setSolvedDate(solvedDate);
        if (request.getTimeSpentMinutes() != null) {
            problem.setTimeSpentMinutes(request.getTimeSpentMinutes());
        }

        CodingProblem updated = codingProblemRepository.save(problem);
        return mapToDTO(updated);
    }

    @Transactional
    public CodingProblemDTO toggleStatus(Long id) {
        User currentUser = authService.getCurrentAuthenticatedUser();
        CodingProblem problem = codingProblemRepository.findByIdAndUserId(id, currentUser.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Problem not found with id: " + id));

        if (problem.getStatus() == ProblemStatus.SOLVED) {
            problem.setStatus(ProblemStatus.UNSOLVED);
            problem.setSolvedDate(null);
        } else {
            problem.setStatus(ProblemStatus.SOLVED);
            problem.setSolvedDate(LocalDate.now());
        }

        CodingProblem updated = codingProblemRepository.save(problem);
        return mapToDTO(updated);
    }

    @Transactional
    public void deleteProblem(Long id) {
        User currentUser = authService.getCurrentAuthenticatedUser();
        CodingProblem problem = codingProblemRepository.findByIdAndUserId(id, currentUser.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Problem not found with id: " + id));
        codingProblemRepository.delete(problem);
    }

    public CodingProblemDTO mapToDTO(CodingProblem problem) {
        return CodingProblemDTO.builder()
                .id(problem.getId())
                .title(problem.getTitle())
                .description(problem.getDescription())
                .difficulty(problem.getDifficulty())
                .topic(problem.getTopic())
                .platform(problem.getPlatform())
                .problemUrl(problem.getProblemUrl())
                .solutionUrl(problem.getSolutionUrl())
                .notes(problem.getNotes())
                .status(problem.getStatus())
                .solvedDate(problem.getSolvedDate())
                .timeSpentMinutes(problem.getTimeSpentMinutes())
                .createdAt(problem.getCreatedAt())
                .updatedAt(problem.getUpdatedAt())
                .build();
    }
}
