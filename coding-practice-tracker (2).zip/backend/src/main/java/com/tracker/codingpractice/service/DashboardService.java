package com.tracker.codingpractice.service;

import com.tracker.codingpractice.dto.*;
import com.tracker.codingpractice.entity.CodingProblem;
import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.PracticeSession;
import com.tracker.codingpractice.entity.ProblemStatus;
import com.tracker.codingpractice.entity.User;
import com.tracker.codingpractice.repository.CodingProblemRepository;
import com.tracker.codingpractice.repository.PracticeSessionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final CodingProblemRepository codingProblemRepository;
    private final PracticeSessionRepository practiceSessionRepository;
    private final StreakService streakService;
    private final AuthService authService;

    @Transactional(readOnly = true)
    public DashboardResponse getDashboardData() {
        User currentUser = authService.getCurrentAuthenticatedUser();
        Long userId = currentUser.getId();

        long totalProblems = codingProblemRepository.countByUserId(userId);
        long solvedProblems = codingProblemRepository.countByUserIdAndStatus(userId, ProblemStatus.SOLVED);
        long unsolvedProblems = totalProblems - solvedProblems;
        double completionRate = totalProblems > 0 ? ((double) solvedProblems / totalProblems) * 100.0 : 0.0;

        Long totalMinutes = practiceSessionRepository.sumDurationMinutesByUserId(userId);
        double totalHours = totalMinutes != null ? Math.round((totalMinutes / 60.0) * 10.0) / 10.0 : 0.0;

        // Difficulty stats
        long easySolved = codingProblemRepository.countByUserIdAndStatusAndDifficulty(userId, ProblemStatus.SOLVED, Difficulty.EASY);
        long easyTotal = codingProblemRepository.countByUserIdAndDifficulty(userId, Difficulty.EASY);
        long mediumSolved = codingProblemRepository.countByUserIdAndStatusAndDifficulty(userId, ProblemStatus.SOLVED, Difficulty.MEDIUM);
        long mediumTotal = codingProblemRepository.countByUserIdAndDifficulty(userId, Difficulty.MEDIUM);
        long hardSolved = codingProblemRepository.countByUserIdAndStatusAndDifficulty(userId, ProblemStatus.SOLVED, Difficulty.HARD);
        long hardTotal = codingProblemRepository.countByUserIdAndDifficulty(userId, Difficulty.HARD);

        DifficultyStatsDTO difficultyStats = DifficultyStatsDTO.builder()
                .easySolved(easySolved)
                .easyTotal(easyTotal)
                .mediumSolved(mediumSolved)
                .mediumTotal(mediumTotal)
                .hardSolved(hardSolved)
                .hardTotal(hardTotal)
                .build();

        // Streak info
        StreakResponse streakInfo = streakService.calculateStreakForUser(userId);

        // Weekly & Monthly calculations
        LocalDate now = LocalDate.now();
        LocalDate startOfWeek = now.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate startOfMonth = now.with(TemporalAdjusters.firstDayOfMonth());

        Long weekMinutes = practiceSessionRepository.sumDurationMinutesByUserIdAndSessionDateAfter(userId, startOfWeek);
        Long monthMinutes = practiceSessionRepository.sumDurationMinutesByUserIdAndSessionDateAfter(userId, startOfMonth);

        double weekHours = weekMinutes != null ? Math.round((weekMinutes / 60.0) * 10.0) / 10.0 : 0.0;
        double monthHours = monthMinutes != null ? Math.round((monthMinutes / 60.0) * 10.0) / 10.0 : 0.0;

        List<CodingProblem> userProblems = codingProblemRepository.findAllByUserId(userId);
        int problemsThisWeek = 0;
        int problemsThisMonth = 0;
        for (CodingProblem p : userProblems) {
            if (p.getStatus() == ProblemStatus.SOLVED && p.getSolvedDate() != null) {
                if (!p.getSolvedDate().isBefore(startOfWeek)) {
                    problemsThisWeek++;
                }
                if (!p.getSolvedDate().isBefore(startOfMonth)) {
                    problemsThisMonth++;
                }
            }
        }

        double targetWeeklyHours = currentUser.getTargetWeeklyHours() != null ? currentUser.getTargetWeeklyHours() : 10.0;
        double weeklyGoalPercentage = targetWeeklyHours > 0 ? Math.min(100.0, (weekHours / targetWeeklyHours) * 100.0) : 0.0;

        WeeklyMonthlyProgressDTO progress = WeeklyMonthlyProgressDTO.builder()
                .problemsSolvedThisWeek(problemsThisWeek)
                .problemsSolvedThisMonth(problemsThisMonth)
                .hoursSpentThisWeek(weekHours)
                .hoursSpentThisMonth(monthHours)
                .targetDailyProblems(currentUser.getTargetDailyProblems() != null ? currentUser.getTargetDailyProblems() : 3)
                .targetWeeklyHours(targetWeeklyHours)
                .weeklyGoalPercentage(Math.round(weeklyGoalPercentage * 10.0) / 10.0)
                .build();

        // Recent Activity
        List<RecentActivityDTO> activities = new ArrayList<>();

        List<CodingProblem> recentProblems = codingProblemRepository.findTop5ByUserIdOrderByCreatedAtDesc(userId);
        for (CodingProblem p : recentProblems) {
            activities.add(RecentActivityDTO.builder()
                    .id("p-" + p.getId())
                    .type(p.getStatus() == ProblemStatus.SOLVED ? "PROBLEM_SOLVED" : "PROBLEM_ADDED")
                    .title(p.getTitle())
                    .subtitle(p.getPlatform() + " • " + p.getTopic())
                    .difficultyOrTopic(p.getDifficulty().name())
                    .timestamp(p.getUpdatedAt() != null ? p.getUpdatedAt() : p.getCreatedAt())
                    .build());
        }

        List<PracticeSession> recentSessions = practiceSessionRepository.findTop5ByUserIdOrderBySessionDateDescCreatedAtDesc(userId);
        for (PracticeSession s : recentSessions) {
            activities.add(RecentActivityDTO.builder()
                    .id("s-" + s.getId())
                    .type("PRACTICE_SESSION")
                    .title("Practice Session: " + (s.getTopicFocus() != null ? s.getTopicFocus() : "General Practice"))
                    .subtitle(s.getDurationMinutes() + " mins • " + s.getProblemsSolvedCount() + " problems solved")
                    .difficultyOrTopic(s.getSessionDate().toString())
                    .timestamp(s.getCreatedAt())
                    .build());
        }

        activities.sort(Comparator.comparing(RecentActivityDTO::getTimestamp, Comparator.nullsLast(Comparator.reverseOrder())));
        if (activities.size() > 8) {
            activities = activities.subList(0, 8);
        }

        return DashboardResponse.builder()
                .totalProblems(totalProblems)
                .totalSolvedProblems(solvedProblems)
                .totalUnsolvedProblems(unsolvedProblems)
                .completionRate(Math.round(completionRate * 10.0) / 10.0)
                .totalPracticeHours(totalHours)
                .currentStreak(streakInfo.getCurrentStreak())
                .longestStreak(streakInfo.getLongestStreak())
                .practicedToday(streakInfo.isActiveToday())
                .difficultyStats(difficultyStats)
                .progress(progress)
                .recentActivities(activities)
                .activityHeatmap(streakInfo.getActivityHistory())
                .build();
    }
}
