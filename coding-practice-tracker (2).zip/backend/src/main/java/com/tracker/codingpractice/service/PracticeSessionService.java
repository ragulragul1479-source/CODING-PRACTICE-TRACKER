package com.tracker.codingpractice.service;

import com.tracker.codingpractice.dto.PageResponse;
import com.tracker.codingpractice.dto.PracticeSessionDTO;
import com.tracker.codingpractice.dto.PracticeSessionRequest;
import com.tracker.codingpractice.entity.PracticeSession;
import com.tracker.codingpractice.entity.User;
import com.tracker.codingpractice.exception.ResourceNotFoundException;
import com.tracker.codingpractice.repository.PracticeSessionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PracticeSessionService {

    private final PracticeSessionRepository practiceSessionRepository;
    private final AuthService authService;

    @Transactional
    public PracticeSessionDTO createSession(PracticeSessionRequest request) {
        User currentUser = authService.getCurrentAuthenticatedUser();

        PracticeSession session = PracticeSession.builder()
                .sessionDate(request.getSessionDate())
                .durationMinutes(request.getDurationMinutes())
                .problemsSolvedCount(request.getProblemsSolvedCount())
                .topicFocus(request.getTopicFocus() != null ? request.getTopicFocus().trim() : null)
                .notes(request.getNotes())
                .user(currentUser)
                .build();

        PracticeSession saved = practiceSessionRepository.save(session);
        return mapToDTO(saved);
    }

    @Transactional(readOnly = true)
    public List<PracticeSessionDTO> getAllSessions() {
        User currentUser = authService.getCurrentAuthenticatedUser();
        return practiceSessionRepository.findAllByUserIdOrderBySessionDateDesc(currentUser.getId())
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public PageResponse<PracticeSessionDTO> getSessionsPaginated(int page, int size) {
        User currentUser = authService.getCurrentAuthenticatedUser();
        Pageable pageable = PageRequest.of(Math.max(0, page), size > 0 ? size : 10,
                Sort.by(Sort.Direction.DESC, "sessionDate", "createdAt"));

        Page<PracticeSession> sessionPage = practiceSessionRepository.findAllByUserId(currentUser.getId(), pageable);
        return PageResponse.from(sessionPage.map(this::mapToDTO));
    }

    @Transactional(readOnly = true)
    public PracticeSessionDTO getSessionById(Long id) {
        User currentUser = authService.getCurrentAuthenticatedUser();
        PracticeSession session = practiceSessionRepository.findByIdAndUserId(id, currentUser.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Practice session not found with id: " + id));
        return mapToDTO(session);
    }

    @Transactional
    public PracticeSessionDTO updateSession(Long id, PracticeSessionRequest request) {
        User currentUser = authService.getCurrentAuthenticatedUser();
        PracticeSession session = practiceSessionRepository.findByIdAndUserId(id, currentUser.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Practice session not found with id: " + id));

        session.setSessionDate(request.getSessionDate());
        session.setDurationMinutes(request.getDurationMinutes());
        session.setProblemsSolvedCount(request.getProblemsSolvedCount());
        session.setTopicFocus(request.getTopicFocus() != null ? request.getTopicFocus().trim() : null);
        session.setNotes(request.getNotes());

        PracticeSession updated = practiceSessionRepository.save(session);
        return mapToDTO(updated);
    }

    @Transactional
    public void deleteSession(Long id) {
        User currentUser = authService.getCurrentAuthenticatedUser();
        PracticeSession session = practiceSessionRepository.findByIdAndUserId(id, currentUser.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Practice session not found with id: " + id));
        practiceSessionRepository.delete(session);
    }

    public PracticeSessionDTO mapToDTO(PracticeSession session) {
        return PracticeSessionDTO.builder()
                .id(session.getId())
                .sessionDate(session.getSessionDate())
                .durationMinutes(session.getDurationMinutes())
                .problemsSolvedCount(session.getProblemsSolvedCount())
                .topicFocus(session.getTopicFocus())
                .notes(session.getNotes())
                .createdAt(session.getCreatedAt())
                .updatedAt(session.getUpdatedAt())
                .build();
    }
}
