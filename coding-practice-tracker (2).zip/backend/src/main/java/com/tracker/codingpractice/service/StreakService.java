package com.tracker.codingpractice.service;

import com.tracker.codingpractice.dto.DailyActivityDTO;
import com.tracker.codingpractice.dto.StreakResponse;
import com.tracker.codingpractice.entity.User;
import com.tracker.codingpractice.repository.CodingProblemRepository;
import com.tracker.codingpractice.repository.PracticeSessionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StreakService {

    private final CodingProblemRepository codingProblemRepository;
    private final PracticeSessionRepository practiceSessionRepository;
    private final AuthService authService;

    @Transactional(readOnly = true)
    public StreakResponse calculateStreak() {
        User currentUser = authService.getCurrentAuthenticatedUser();
        return calculateStreakForUser(currentUser.getId());
    }

    @Transactional(readOnly = true)
    public StreakResponse calculateStreakForUser(Long userId) {
        List<LocalDate> problemDates = codingProblemRepository.findDistinctSolvedDatesByUserId(userId);
        List<LocalDate> sessionDates = practiceSessionRepository.findDistinctSessionDatesByUserId(userId);

        Set<LocalDate> activeDateSet = new TreeSet<>(Collections.reverseOrder());
        activeDateSet.addAll(problemDates);
        activeDateSet.addAll(sessionDates);

        LocalDate today = LocalDate.now();
        boolean activeToday = activeDateSet.contains(today);

        int currentStreak = 0;
        LocalDate checkDate = activeToday ? today : today.minusDays(1);

        while (activeDateSet.contains(checkDate)) {
            currentStreak++;
            checkDate = checkDate.minusDays(1);
        }

        // Calculate longest streak
        List<LocalDate> sortedAscending = new ArrayList<>(activeDateSet);
        Collections.sort(sortedAscending);

        int longestStreak = 0;
        int tempStreak = 0;
        LocalDate prevDate = null;

        for (LocalDate date : sortedAscending) {
            if (prevDate == null) {
                tempStreak = 1;
            } else if (date.equals(prevDate.plusDays(1))) {
                tempStreak++;
            } else if (!date.equals(prevDate)) {
                tempStreak = 1;
            }
            if (tempStreak > longestStreak) {
                longestStreak = tempStreak;
            }
            prevDate = date;
        }

        LocalDate lastActiveDate = sortedAscending.isEmpty() ? null : sortedAscending.get(sortedAscending.size() - 1);

        List<DailyActivityDTO> activityHistory = generateDailyActivityHeatmap(userId, 365);

        return StreakResponse.builder()
                .currentStreak(currentStreak)
                .longestStreak(longestStreak)
                .activeToday(activeToday)
                .lastActiveDate(lastActiveDate)
                .totalActiveDays(activeDateSet.size())
                .activeDates(new ArrayList<>(activeDateSet))
                .activityHistory(activityHistory)
                .build();
    }

    @Transactional(readOnly = true)
    public List<DailyActivityDTO> generateDailyActivityHeatmap(Long userId, int daysBack) {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(daysBack);

        List<Object[]> sessionAggregates = practiceSessionRepository.findDailySessionAggregates(userId);
        Map<LocalDate, Integer> minutesMap = new HashMap<>();
        Map<LocalDate, Integer> sessionProblemsMap = new HashMap<>();

        for (Object[] row : sessionAggregates) {
            if (row[0] != null) {
                LocalDate d = (LocalDate) row[0];
                Number minutes = (Number) row[1];
                Number count = (Number) row[2];
                minutesMap.put(d, minutes != null ? minutes.intValue() : 0);
                sessionProblemsMap.put(d, count != null ? count.intValue() : 0);
            }
        }

        // Count directly solved problems
        List<LocalDate> problemDates = codingProblemRepository.findDistinctSolvedDatesByUserId(userId);
        Map<LocalDate, Integer> directProblemsMap = new HashMap<>();
        for (LocalDate d : problemDates) {
            directProblemsMap.put(d, directProblemsMap.getOrDefault(d, 0) + 1);
        }

        List<DailyActivityDTO> results = new ArrayList<>();
        LocalDate cur = startDate;
        while (!cur.isAfter(endDate)) {
            int minutes = minutesMap.getOrDefault(cur, 0);
            int solved = sessionProblemsMap.getOrDefault(cur, 0) + directProblemsMap.getOrDefault(cur, 0);
            int totalEffort = solved + (minutes / 30);

            int level = 0;
            if (totalEffort >= 4 || minutes >= 120 || solved >= 4) {
                level = 4;
            } else if (totalEffort >= 3 || minutes >= 90 || solved >= 3) {
                level = 3;
            } else if (totalEffort >= 2 || minutes >= 45 || solved >= 2) {
                level = 2;
            } else if (totalEffort >= 1 || minutes > 0 || solved >= 1) {
                level = 1;
            }

            results.add(DailyActivityDTO.builder()
                    .date(cur)
                    .problemsSolved(solved)
                    .minutesPracticed(minutes)
                    .count(totalEffort)
                    .level(level)
                    .build());

            cur = cur.plusDays(1);
        }

        return results;
    }
}
