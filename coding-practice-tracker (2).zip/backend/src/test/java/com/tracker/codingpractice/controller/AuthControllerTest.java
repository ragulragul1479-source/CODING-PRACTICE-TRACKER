package com.tracker.codingpractice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tracker.codingpractice.config.JwtAuthEntryPoint;
import com.tracker.codingpractice.config.JwtAuthenticationFilter;
import com.tracker.codingpractice.dto.AuthResponse;
import com.tracker.codingpractice.dto.LoginRequest;
import com.tracker.codingpractice.dto.RegisterRequest;
import com.tracker.codingpractice.dto.UserDTO;
import com.tracker.codingpractice.entity.Role;
import com.tracker.codingpractice.service.AuthService;
import com.tracker.codingpractice.service.CustomUserDetailsService;
import com.tracker.codingpractice.service.JwtService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AuthController.class)
@AutoConfigureMockMvc(addFilters = false)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private AuthService authService;

    @MockBean
    private JwtService jwtService;

    @MockBean
    private CustomUserDetailsService userDetailsService;

    @MockBean
    private JwtAuthEntryPoint jwtAuthEntryPoint;

    @MockBean
    private JwtAuthenticationFilter jwtAuthenticationFilter;

    @Test
    @DisplayName("POST /api/auth/register should return 201 with JWT token")
    void testRegisterEndpoint() throws Exception {
        RegisterRequest request = RegisterRequest.builder()
                .username("janedoe")
                .email("jane@example.com")
                .password("Password123!")
                .fullName("Jane Doe")
                .build();

        AuthResponse authResponse = AuthResponse.builder()
                .token("test.jwt.token")
                .tokenType("Bearer")
                .expiresIn(86400000L)
                .user(UserDTO.builder()
                        .id(2L)
                        .username("janedoe")
                        .email("jane@example.com")
                        .role(Role.ROLE_USER)
                        .build())
                .build();

        when(authService.register(any(RegisterRequest.class))).thenReturn(authResponse);

        mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.token").value("test.jwt.token"))
                .andExpect(jsonPath("$.data.user.username").value("janedoe"));
    }

    @Test
    @DisplayName("POST /api/auth/login should return 200 with JWT token")
    void testLoginEndpoint() throws Exception {
        LoginRequest request = LoginRequest.builder()
                .usernameOrEmail("janedoe")
                .password("Password123!")
                .build();

        AuthResponse authResponse = AuthResponse.builder()
                .token("login.jwt.token")
                .tokenType("Bearer")
                .expiresIn(86400000L)
                .user(UserDTO.builder().id(2L).username("janedoe").build())
                .build();

        when(authService.login(any(LoginRequest.class))).thenReturn(authResponse);

        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.token").value("login.jwt.token"));
    }
}
