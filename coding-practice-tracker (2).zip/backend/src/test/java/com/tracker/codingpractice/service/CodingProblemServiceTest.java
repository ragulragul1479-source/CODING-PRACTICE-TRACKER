package com.tracker.codingpractice.service;

import com.tracker.codingpractice.dto.CodingProblemCreateRequest;
import com.tracker.codingpractice.dto.CodingProblemDTO;
import com.tracker.codingpractice.dto.CodingProblemUpdateRequest;
import com.tracker.codingpractice.entity.CodingProblem;
import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.ProblemStatus;
import com.tracker.codingpractice.entity.User;
import com.tracker.codingpractice.repository.CodingProblemRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CodingProblemServiceTest {

    @Mock
    private CodingProblemRepository codingProblemRepository;

    @Mock
    private AuthService authService;

    @InjectMocks
    private CodingProblemService codingProblemService;

    private User sampleUser;
    private CodingProblem sampleProblem;

    @BeforeEach
    void setUp() {
        sampleUser = User.builder().id(1L).username("testuser").build();
        sampleProblem = CodingProblem.builder()
                .id(100L)
                .title("Two Sum")
                .description("Array problem")
                .difficulty(Difficulty.EASY)
                .topic("Arrays")
                .platform("LeetCode")
                .status(ProblemStatus.UNSOLVED)
                .timeSpentMinutes(20)
                .user(sampleUser)
                .createdAt(LocalDateTime.now())
                .build();
    }

    @Test
    @DisplayName("Should create problem successfully for authenticated user")
    void testCreateProblem() {
        CodingProblemCreateRequest request = CodingProblemCreateRequest.builder()
                .title("Two Sum")
                .difficulty(Difficulty.EASY)
                .topic("Arrays")
                .platform("LeetCode")
                .status(ProblemStatus.SOLVED)
                .solvedDate(LocalDate.now())
                .timeSpentMinutes(25)
                .build();

        when(authService.getCurrentAuthenticatedUser()).thenReturn(sampleUser);
        when(codingProblemRepository.save(any(CodingProblem.class))).thenReturn(sampleProblem);

        CodingProblemDTO result = codingProblemService.createProblem(request);

        assertNotNull(result);
        assertEquals("Two Sum", result.getTitle());
        verify(codingProblemRepository, times(1)).save(any(CodingProblem.class));
    }

    @Test
    @DisplayName("Should toggle problem status from UNSOLVED to SOLVED")
    void testToggleStatus() {
        when(authService.getCurrentAuthenticatedUser()).thenReturn(sampleUser);
        when(codingProblemRepository.findByIdAndUserId(100L, 1L)).thenReturn(Optional.of(sampleProblem));
        when(codingProblemRepository.save(any(CodingProblem.class))).thenAnswer(invocation -> invocation.getArgument(0));

        CodingProblemDTO result = codingProblemService.toggleStatus(100L);

        assertNotNull(result);
        assertEquals(ProblemStatus.SOLVED, result.getStatus());
        assertNotNull(result.getSolvedDate());
    }

    @Test
    @DisplayName("Should delete problem when owned by user")
    void testDeleteProblem() {
        when(authService.getCurrentAuthenticatedUser()).thenReturn(sampleUser);
        when(codingProblemRepository.findByIdAndUserId(100L, 1L)).thenReturn(Optional.of(sampleProblem));

        codingProblemService.deleteProblem(100L);

        verify(codingProblemRepository, times(1)).delete(sampleProblem);
    }
}
