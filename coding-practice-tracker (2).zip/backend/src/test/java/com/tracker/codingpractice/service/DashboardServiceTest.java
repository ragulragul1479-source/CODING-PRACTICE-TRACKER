package com.tracker.codingpractice.service;

import com.tracker.codingpractice.dto.DashboardResponse;
import com.tracker.codingpractice.dto.StreakResponse;
import com.tracker.codingpractice.entity.Difficulty;
import com.tracker.codingpractice.entity.ProblemStatus;
import com.tracker.codingpractice.entity.User;
import com.tracker.codingpractice.repository.CodingProblemRepository;
import com.tracker.codingpractice.repository.PracticeSessionRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DashboardServiceTest {

    @Mock
    private CodingProblemRepository codingProblemRepository;

    @Mock
    private PracticeSessionRepository practiceSessionRepository;

    @Mock
    private StreakService streakService;

    @Mock
    private AuthService authService;

    @InjectMocks
    private DashboardService dashboardService;

    @Test
    @DisplayName("Should aggregate dashboard metrics correctly")
    void testGetDashboardData() {
        User user = User.builder()
                .id(1L)
                .username("testdev")
                .targetDailyProblems(3)
                .targetWeeklyHours(10.0)
                .build();

        when(authService.getCurrentAuthenticatedUser()).thenReturn(user);
        when(codingProblemRepository.countByUserId(1L)).thenReturn(20L);
        when(codingProblemRepository.countByUserIdAndStatus(1L, ProblemStatus.SOLVED)).thenReturn(15L);
        when(practiceSessionRepository.sumDurationMinutesByUserId(1L)).thenReturn(300L); // 5 hours

        when(codingProblemRepository.countByUserIdAndStatusAndDifficulty(1L, ProblemStatus.SOLVED, Difficulty.EASY)).thenReturn(8L);
        when(codingProblemRepository.countByUserIdAndDifficulty(1L, Difficulty.EASY)).thenReturn(10L);
        when(codingProblemRepository.countByUserIdAndStatusAndDifficulty(1L, ProblemStatus.SOLVED, Difficulty.MEDIUM)).thenReturn(5L);
        when(codingProblemRepository.countByUserIdAndDifficulty(1L, Difficulty.MEDIUM)).thenReturn(7L);
        when(codingProblemRepository.countByUserIdAndStatusAndDifficulty(1L, ProblemStatus.SOLVED, Difficulty.HARD)).thenReturn(2L);
        when(codingProblemRepository.countByUserIdAndDifficulty(1L, Difficulty.HARD)).thenReturn(3L);

        when(streakService.calculateStreakForUser(1L)).thenReturn(
                StreakResponse.builder()
                        .currentStreak(5)
                        .longestStreak(10)
                        .activeToday(true)
                        .activityHistory(Collections.emptyList())
                        .build()
        );

        when(codingProblemRepository.findAllByUserId(1L)).thenReturn(Collections.emptyList());
        when(codingProblemRepository.findTop5ByUserIdOrderByCreatedAtDesc(1L)).thenReturn(Collections.emptyList());
        when(practiceSessionRepository.findTop5ByUserIdOrderBySessionDateDescCreatedAtDesc(1L)).thenReturn(Collections.emptyList());

        DashboardResponse response = dashboardService.getDashboardData();

        assertNotNull(response);
        assertEquals(20, response.getTotalProblems());
        assertEquals(15, response.getTotalSolvedProblems());
        assertEquals(5, response.getTotalUnsolvedProblems());
        assertEquals(75.0, response.getCompletionRate());
        assertEquals(5.0, response.getTotalPracticeHours());
        assertEquals(5, response.getCurrentStreak());
        assertEquals(10, response.getLongestStreak());
        assertTrue(response.isPracticedToday());
        assertEquals(8, response.getDifficultyStats().getEasySolved());
    }
}
