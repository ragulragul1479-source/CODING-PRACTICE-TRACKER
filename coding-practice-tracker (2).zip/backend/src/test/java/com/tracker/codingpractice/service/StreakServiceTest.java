package com.tracker.codingpractice.service;

import com.tracker.codingpractice.dto.StreakResponse;
import com.tracker.codingpractice.repository.CodingProblemRepository;
import com.tracker.codingpractice.repository.PracticeSessionRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StreakServiceTest {

    @Mock
    private CodingProblemRepository codingProblemRepository;

    @Mock
    private PracticeSessionRepository practiceSessionRepository;

    @Mock
    private AuthService authService;

    @InjectMocks
    private StreakService streakService;

    @Test
    @DisplayName("Should correctly compute 3-day active streak including today")
    void testCurrentStreakWithTodayActive() {
        Long userId = 1L;
        LocalDate today = LocalDate.now();

        List<LocalDate> problemDates = List.of(today, today.minusDays(1));
        List<LocalDate> sessionDates = List.of(today.minusDays(2));

        when(codingProblemRepository.findDistinctSolvedDatesByUserId(userId)).thenReturn(problemDates);
        when(practiceSessionRepository.findDistinctSessionDatesByUserId(userId)).thenReturn(sessionDates);
        when(practiceSessionRepository.findDailySessionAggregates(userId)).thenReturn(Collections.emptyList());

        StreakResponse result = streakService.calculateStreakForUser(userId);

        assertEquals(3, result.getCurrentStreak());
        assertEquals(3, result.getLongestStreak());
        assertTrue(result.isActiveToday());
    }

    @Test
    @DisplayName("Should compute streak when yesterday was active but not yet today")
    void testCurrentStreakYesterdayActive() {
        Long userId = 1L;
        LocalDate today = LocalDate.now();

        List<LocalDate> problemDates = List.of(today.minusDays(1), today.minusDays(2));
        List<LocalDate> sessionDates = Collections.emptyList();

        when(codingProblemRepository.findDistinctSolvedDatesByUserId(userId)).thenReturn(problemDates);
        when(practiceSessionRepository.findDistinctSessionDatesByUserId(userId)).thenReturn(sessionDates);
        when(practiceSessionRepository.findDailySessionAggregates(userId)).thenReturn(Collections.emptyList());

        StreakResponse result = streakService.calculateStreakForUser(userId);

        assertEquals(2, result.getCurrentStreak());
        assertFalse(result.isActiveToday());
    }

    @Test
    @DisplayName("Should return zero current streak if streak was broken 2 days ago")
    void testBrokenStreak() {
        Long userId = 1L;
        LocalDate today = LocalDate.now();

        List<LocalDate> problemDates = List.of(today.minusDays(3), today.minusDays(4));
        List<LocalDate> sessionDates = Collections.emptyList();

        when(codingProblemRepository.findDistinctSolvedDatesByUserId(userId)).thenReturn(problemDates);
        when(practiceSessionRepository.findDistinctSessionDatesByUserId(userId)).thenReturn(sessionDates);
        when(practiceSessionRepository.findDailySessionAggregates(userId)).thenReturn(Collections.emptyList());

        StreakResponse result = streakService.calculateStreakForUser(userId);

        assertEquals(0, result.getCurrentStreak());
        assertEquals(2, result.getLongestStreak());
        assertFalse(result.isActiveToday());
    }
}
