-- ============================================================================
-- Coding Practice Tracker - PostgreSQL Database Schema
-- Compatible with PostgreSQL 14+ / 16+
-- ============================================================================

-- Create Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop tables if exists (in reverse dependency order)
DROP TABLE IF EXISTS practice_sessions CASCADE;
DROP TABLE IF EXISTS coding_problems CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 1. Users Table
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(60) NOT NULL UNIQUE,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    bio VARCHAR(255),
    target_daily_problems INT DEFAULT 3,
    target_weekly_hours NUMERIC(4, 1) DEFAULT 10.0,
    role VARCHAR(20) NOT NULL DEFAULT 'ROLE_USER',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username ON users(username);

-- 2. Coding Problems Table
CREATE TABLE coding_problems (
    id BIGSERIAL PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    difficulty VARCHAR(20) NOT NULL CHECK (difficulty IN ('EASY', 'MEDIUM', 'HARD')),
    topic VARCHAR(80) NOT NULL,
    platform VARCHAR(60) NOT NULL,
    problem_url VARCHAR(500),
    solution_url VARCHAR(500),
    notes TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'UNSOLVED' CHECK (status IN ('SOLVED', 'UNSOLVED')),
    solved_date DATE,
    time_spent_minutes INT DEFAULT 0,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_problems_user_id ON coding_problems(user_id);
CREATE INDEX idx_problems_status ON coding_problems(status);
CREATE INDEX idx_problems_difficulty ON coding_problems(difficulty);
CREATE INDEX idx_problems_topic ON coding_problems(topic);
CREATE INDEX idx_problems_platform ON coding_problems(platform);
CREATE INDEX idx_problems_solved_date ON coding_problems(solved_date);
CREATE INDEX idx_problems_created_at ON coding_problems(created_at);

-- 3. Practice Sessions Table
CREATE TABLE practice_sessions (
    id BIGSERIAL PRIMARY KEY,
    session_date DATE NOT NULL,
    duration_minutes INT NOT NULL CHECK (duration_minutes > 0),
    problems_solved_count INT NOT NULL DEFAULT 0 CHECK (problems_solved_count >= 0),
    topic_focus VARCHAR(100),
    notes TEXT,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_sessions_user_id ON practice_sessions(user_id);
CREATE INDEX idx_sessions_date ON practice_sessions(session_date);
CREATE INDEX idx_sessions_created_at ON practice_sessions(created_at);
