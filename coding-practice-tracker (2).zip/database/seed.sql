-- ============================================================================
-- Coding Practice Tracker - Initial Seed Data
-- User password for 'demouser' and 'alex_dev': 'Password123!' (BCrypt hash)
-- ============================================================================

-- 1. Insert Demo Users
-- Password hash for 'Password123!': $2a$10$e8eU48g55Otyq2mU84M0z.66gBf2k1r5l.a0oHl6bB68OqZ/f2u7q
INSERT INTO users (id, username, email, password, full_name, bio, target_daily_problems, target_weekly_hours, role, created_at)
VALUES 
(1, 'demouser', 'demo@codingtracker.dev', '$2a$10$GRLdNijSQMUvl/au9ofL.eDwmoohzzS7.rmNSJZ.StBQ/59GbCyNo', 'Alex Chen', 'Full-stack & algorithm enthusiast preparing for tech interviews.', 3, 12.0, 'ROLE_USER', CURRENT_TIMESTAMP - INTERVAL '30 days'),
(2, 'sarah_code', 'sarah@codingtracker.dev', '$2a$10$GRLdNijSQMUvl/au9ofL.eDwmoohzzS7.rmNSJZ.StBQ/59GbCyNo', 'Sarah Lin', 'Competitive programmer targeting Master on Codeforces.', 5, 15.0, 'ROLE_USER', CURRENT_TIMESTAMP - INTERVAL '20 days');

-- 2. Insert Coding Problems for User 1 (demouser)
INSERT INTO coding_problems (user_id, title, description, difficulty, topic, platform, problem_url, solution_url, notes, status, solved_date, time_spent_minutes, created_at)
VALUES
(1, 'Two Sum', 'Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.', 'EASY', 'Arrays & Hashing', 'LeetCode', 'https://leetcode.com/problems/two-sum/', 'https://github.com/demo/solutions/two-sum.java', 'One-pass hash table storing complement index.', 'SOLVED', CURRENT_DATE - INTERVAL '6 days', 15, CURRENT_TIMESTAMP - INTERVAL '6 days'),
(1, 'Valid Anagram', 'Given two strings s and t, return true if t is an anagram of s, and false otherwise.', 'EASY', 'Arrays & Hashing', 'LeetCode', 'https://leetcode.com/problems/valid-anagram/', NULL, 'Fixed array count of 26 letters.', 'SOLVED', CURRENT_DATE - INTERVAL '5 days', 10, CURRENT_TIMESTAMP - INTERVAL '5 days'),
(1, 'Longest Substring Without Repeating Characters', 'Find the length of the longest substring without repeating characters.', 'MEDIUM', 'Sliding Window', 'LeetCode', 'https://leetcode.com/problems/longest-substring-without-repeating-characters/', 'https://github.com/demo/solutions/longest-sub.py', 'Sliding window with left pointer increment on collision.', 'SOLVED', CURRENT_DATE - INTERVAL '4 days', 35, CURRENT_TIMESTAMP - INTERVAL '4 days'),
(1, 'Container With Most Water', 'Find two lines that together with the x-axis form a container containing the most water.', 'MEDIUM', 'Two Pointers', 'LeetCode', 'https://leetcode.com/problems/container-with-most-water/', NULL, 'Two pointers moving the smaller height inward.', 'SOLVED', CURRENT_DATE - INTERVAL '3 days', 25, CURRENT_TIMESTAMP - INTERVAL '3 days'),
(1, 'Invert Binary Tree', 'Given the root of a binary tree, invert the tree, and return its root.', 'EASY', 'Trees', 'LeetCode', 'https://leetcode.com/problems/invert-binary-tree/', NULL, 'Recursive DFS swapping left and right children.', 'SOLVED', CURRENT_DATE - INTERVAL '2 days', 12, CURRENT_TIMESTAMP - INTERVAL '2 days'),
(1, 'LRU Cache', 'Design a data structure that follows the constraints of a Least Recently Used (LRU) cache.', 'MEDIUM', 'Design', 'LeetCode', 'https://leetcode.com/problems/lru-cache/', 'https://github.com/demo/solutions/lru-cache.java', 'Double linked list combined with HashMap.', 'SOLVED', CURRENT_DATE - INTERVAL '1 days', 45, CURRENT_TIMESTAMP - INTERVAL '1 days'),
(1, 'Trapping Rain Water', 'Compute how much water it can trap after raining.', 'HARD', 'Two Pointers', 'LeetCode', 'https://leetcode.com/problems/trapping-rain-water/', 'https://github.com/demo/solutions/trapping-rain.cpp', 'Two pointers with leftMax and rightMax bounds.', 'SOLVED', CURRENT_DATE, 50, CURRENT_TIMESTAMP),
(1, 'Coin Change', 'Fewest number of coins needed to make up that amount.', 'MEDIUM', 'Dynamic Programming', 'LeetCode', 'https://leetcode.com/problems/coin-change/', NULL, 'Bottom up DP: dp[i] = min(dp[i], dp[i-coin] + 1)', 'UNSOLVED', NULL, 0, CURRENT_TIMESTAMP - INTERVAL '2 days'),
(1, 'Word Ladder', 'Find length of shortest transformation sequence from beginWord to endWord.', 'HARD', 'Graphs', 'LeetCode', 'https://leetcode.com/problems/word-ladder/', NULL, 'Bidirectional BFS with wildcard intermediate states.', 'UNSOLVED', NULL, 0, CURRENT_TIMESTAMP - INTERVAL '1 days'),
(1, 'Kth Largest Element in an Array', 'Find the kth largest element in an unsorted array.', 'MEDIUM', 'Heap / Priority Queue', 'LeetCode', 'https://leetcode.com/problems/kth-largest-element-in-an-array/', NULL, 'Min-heap of size K or QuickSelect O(n) average.', 'SOLVED', CURRENT_DATE - INTERVAL '8 days', 20, CURRENT_TIMESTAMP - INTERVAL '8 days'),
(1, 'Merge Intervals', 'Merge all overlapping intervals.', 'MEDIUM', 'Intervals', 'LeetCode', 'https://leetcode.com/problems/merge-intervals/', NULL, 'Sort by start time and merge greedily.', 'SOLVED', CURRENT_DATE - INTERVAL '10 days', 25, CURRENT_TIMESTAMP - INTERVAL '10 days'),
(1, 'Binary Search', 'Given an array of integers nums which is sorted in ascending order, search target.', 'EASY', 'Binary Search', 'LeetCode', 'https://leetcode.com/problems/binary-search/', NULL, 'Standard low + (high-low)/2 binary search.', 'SOLVED', CURRENT_DATE - INTERVAL '12 days', 8, CURRENT_TIMESTAMP - INTERVAL '12 days'),
(1, 'Number of Islands', 'Given an m x n 2D binary grid grid which represents a map of 1s and 0s, return the number of islands.', 'MEDIUM', 'Graphs', 'LeetCode', 'https://leetcode.com/problems/number-of-islands/', NULL, 'Flood fill with BFS or DFS marking visited nodes.', 'SOLVED', CURRENT_DATE - INTERVAL '15 days', 30, CURRENT_TIMESTAMP - INTERVAL '15 days'),
(1, 'Median of Two Sorted Arrays', 'Given two sorted arrays nums1 and nums2 of size m and n respectively, return the median.', 'HARD', 'Binary Search', 'LeetCode', 'https://leetcode.com/problems/median-of-two-sorted-arrays/', NULL, 'Binary search on partition point of smaller array.', 'UNSOLVED', NULL, 0, CURRENT_TIMESTAMP - INTERVAL '5 days');

-- 3. Insert Practice Sessions for User 1 (demouser)
INSERT INTO practice_sessions (user_id, session_date, duration_minutes, problems_solved_count, topic_focus, notes, created_at)
VALUES
(1, CURRENT_DATE - INTERVAL '6 days', 60, 2, 'Arrays & Hashing', 'Solved two sum and duplicate checks.', CURRENT_TIMESTAMP - INTERVAL '6 days'),
(1, CURRENT_DATE - INTERVAL '5 days', 75, 2, 'Strings & Anagrams', 'Practiced frequency arrays and string manipulation.', CURRENT_TIMESTAMP - INTERVAL '5 days'),
(1, CURRENT_DATE - INTERVAL '4 days', 90, 3, 'Sliding Window', 'Worked on variable size window problems.', CURRENT_TIMESTAMP - INTERVAL '4 days'),
(1, CURRENT_DATE - INTERVAL '3 days', 80, 2, 'Two Pointers', 'Container with most water and 3Sum practice.', CURRENT_TIMESTAMP - INTERVAL '3 days'),
(1, CURRENT_DATE - INTERVAL '2 days', 90, 2, 'Trees & DFS', 'Binary tree inversions and lowest common ancestor.', CURRENT_TIMESTAMP - INTERVAL '2 days'),
(1, CURRENT_DATE - INTERVAL '1 days', 110, 3, 'Design & Caching', 'Implemented LRU Cache and Min Stack.', CURRENT_TIMESTAMP - INTERVAL '1 days'),
(1, CURRENT_DATE, 95, 2, 'Hard Two Pointers', 'Trapping rain water and monotonic stack patterns.', CURRENT_TIMESTAMP),
(1, CURRENT_DATE - INTERVAL '8 days', 65, 2, 'Heaps', 'Min heap vs Max heap review.', CURRENT_TIMESTAMP - INTERVAL '8 days'),
(1, CURRENT_DATE - INTERVAL '10 days', 85, 2, 'Intervals & Sorting', 'Merge intervals and insert interval.', CURRENT_TIMESTAMP - INTERVAL '10 days'),
(1, CURRENT_DATE - INTERVAL '12 days', 45, 1, 'Binary Search', 'Reviewing lower bound / upper bound templates.', CURRENT_TIMESTAMP - INTERVAL '12 days'),
(1, CURRENT_DATE - INTERVAL '15 days', 70, 2, 'Graphs & BFS', 'Connected components on matrix.', CURRENT_TIMESTAMP - INTERVAL '15 days');
