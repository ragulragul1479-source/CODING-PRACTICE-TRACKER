import React from 'react';
import { Difficulty, ProblemStatus } from '../../types';

interface DifficultyBadgeProps {
  difficulty: Difficulty;
  className?: string;
  size?: 'sm' | 'md';
}

export const DifficultyBadge: React.FC<DifficultyBadgeProps> = ({
  difficulty,
  className = '',
  size = 'sm',
}) => {
  const styles: Record<Difficulty, string> = {
    EASY: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
    MEDIUM: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
    HARD: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30',
  };

  const sizeStyles = size === 'sm' ? 'px-2 py-0.5 text-xs font-medium' : 'px-3 py-1 text-sm font-medium';

  return (
    <span
      className={`inline-flex items-center rounded-full border tracking-wide uppercase ${styles[difficulty]} ${sizeStyles} ${className}`}
    >
      {difficulty}
    </span>
  );
};

interface StatusBadgeProps {
  status: ProblemStatus;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className = '' }) => {
  const isSolved = status === 'SOLVED';
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${
        isSolved
          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20'
          : 'bg-zinc-500/10 text-zinc-600 dark:text-zinc-400 border-zinc-500/20'
      } ${className}`}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full ${isSolved ? 'bg-emerald-500 animate-pulse' : 'bg-zinc-400'}`}
      />
      {isSolved ? 'Solved' : 'Unsolved'}
    </span>
  );
};

interface PlatformBadgeProps {
  platform: string;
  className?: string;
}

export const PlatformBadge: React.FC<PlatformBadgeProps> = ({ platform, className = '' }) => {
  const getColors = (plat: string) => {
    switch (plat.toLowerCase()) {
      case 'leetcode':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20';
      case 'codeforces':
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20';
      case 'hackerrank':
        return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20';
      case 'neetcode':
        return 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/20';
      default:
        return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20';
    }
  };

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border ${getColors(
        platform
      )} ${className}`}
    >
      {platform}
    </span>
  );
};
