import React, { useState } from 'react';
import { DailyActivity } from '../../types';

interface HeatmapProps {
  data: DailyActivity[];
  totalDays?: number;
}

export const Heatmap: React.FC<HeatmapProps> = ({ data }) => {
  const [hoveredDay, setHoveredDay] = useState<DailyActivity | null>(null);

  // Group days into columns of 7 days (weeks)
  const weeks: DailyActivity[][] = [];
  let currentWeek: DailyActivity[] = [];

  // Pad the beginning so the first day aligns with its day of week (0 = Sun, 1 = Mon, ..., 6 = Sat)
  if (data.length > 0) {
    const firstDate = new Date(data[0].date);
    const dayOfWeek = firstDate.getDay(); // 0 for Sun
    for (let i = 0; i < dayOfWeek; i++) {
      currentWeek.push({
        date: '',
        problemsSolved: 0,
        minutesPracticed: 0,
        count: 0,
        level: -1, // Empty slot
      });
    }
  }

  data.forEach((day) => {
    currentWeek.push(day);
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
  });

  if (currentWeek.length > 0) {
    while (currentWeek.length < 7) {
      currentWeek.push({
        date: '',
        problemsSolved: 0,
        minutesPracticed: 0,
        count: 0,
        level: -1,
      });
    }
    weeks.push(currentWeek);
  }

  const getCellColor = (level: number) => {
    switch (level) {
      case 4:
        return 'bg-emerald-400 dark:bg-emerald-400 ring-emerald-400/30';
      case 3:
        return 'bg-emerald-500 dark:bg-emerald-500/90';
      case 2:
        return 'bg-emerald-600/70 dark:bg-emerald-600/80';
      case 1:
        return 'bg-emerald-700/40 dark:bg-emerald-800/60';
      case 0:
        return 'bg-zinc-200 dark:bg-zinc-800/80 hover:bg-zinc-300 dark:hover:bg-zinc-700';
      default:
        return 'bg-transparent pointer-events-none';
    }
  };

  const monthLabels: { label: string; weekIndex: number }[] = [];
  let lastMonth = '';

  weeks.forEach((week, wIndex) => {
    const validDay = week.find((d) => d.date !== '');
    if (validDay) {
      const d = new Date(validDay.date);
      const m = d.toLocaleString('default', { month: 'short' });
      if (m !== lastMonth) {
        monthLabels.push({ label: m, weekIndex: wIndex });
        lastMonth = m;
      }
    }
  });

  const totalSolvedInHistory = data.reduce((acc, d) => acc + d.problemsSolved, 0);
  const totalMinutesInHistory = data.reduce((acc, d) => acc + d.minutesPracticed, 0);
  const activeDaysCount = data.filter((d) => d.level > 0).length;

  return (
    <div className="w-full">
      {/* Header Stats */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 text-xs text-zinc-500 dark:text-zinc-400">
        <div className="flex items-center gap-4">
          <span>
            <strong className="text-zinc-800 dark:text-zinc-200 font-semibold">{totalSolvedInHistory}</strong> problems solved
          </span>
          <span>•</span>
          <span>
            <strong className="text-zinc-800 dark:text-zinc-200 font-semibold">
              {Math.round((totalMinutesInHistory / 60) * 10) / 10}h
            </strong>{' '}
            practiced
          </span>
          <span>•</span>
          <span>
            <strong className="text-zinc-800 dark:text-zinc-200 font-semibold">{activeDaysCount}</strong> active days
          </span>
        </div>

        {/* Hover info tooltip line */}
        <div className="h-5 flex items-center">
          {hoveredDay && hoveredDay.level >= 0 ? (
            <span className="font-medium text-zinc-700 dark:text-zinc-300 animate-fadeIn">
              {new Date(hoveredDay.date).toLocaleDateString(undefined, {
                month: 'short',
                day: 'numeric',
                year: 'numeric',
              })}
              : {hoveredDay.problemsSolved} solved, {hoveredDay.minutesPracticed}m practiced
            </span>
          ) : (
            <span className="opacity-70">Hover over a square for details</span>
          )}
        </div>
      </div>

      {/* Grid Container */}
      <div className="overflow-x-auto pb-2 scrollbar-thin">
        <div className="inline-block min-w-full">
          {/* Month labels */}
          <div className="flex text-[10px] text-zinc-400 mb-1 ml-6 relative h-4">
            {monthLabels.map((m, idx) => (
              <span
                key={idx}
                className="absolute"
                style={{ left: `${m.weekIndex * 15}px` }}
              >
                {m.label}
              </span>
            ))}
          </div>

          <div className="flex gap-1.5 items-start">
            {/* Weekday labels */}
            <div className="flex flex-col gap-1 text-[9px] text-zinc-400 dark:text-zinc-500 pr-1 select-none pt-0.5">
              <span className="h-2.5 leading-none">Sun</span>
              <span className="h-2.5 leading-none">Mon</span>
              <span className="h-2.5 leading-none">Tue</span>
              <span className="h-2.5 leading-none">Wed</span>
              <span className="h-2.5 leading-none">Thu</span>
              <span className="h-2.5 leading-none">Fri</span>
              <span className="h-2.5 leading-none">Sat</span>
            </div>

            {/* Matrix of squares */}
            <div className="flex gap-1">
              {weeks.map((week, wIdx) => (
                <div key={wIdx} className="flex flex-col gap-1">
                  {week.map((day, dIdx) => (
                    <div
                      key={dIdx}
                      onMouseEnter={() => day.date && setHoveredDay(day)}
                      onMouseLeave={() => setHoveredDay(null)}
                      className={`w-3 h-3 rounded-[3px] transition-all cursor-pointer ${getCellColor(
                        day.level
                      )} ${
                        hoveredDay?.date === day.date && day.date
                          ? 'scale-125 ring-2 ring-indigo-500 z-10'
                          : ''
                      }`}
                      title={
                        day.date
                          ? `${day.date}: ${day.problemsSolved} problems solved, ${day.minutesPracticed} mins`
                          : undefined
                      }
                    />
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-between text-xs text-zinc-400 dark:text-zinc-500 mt-3 pt-3 border-t border-zinc-100 dark:border-zinc-800/80">
        <span>Activity is recorded when solving problems or logging practice sessions</span>
        <div className="flex items-center gap-1.5">
          <span>Less</span>
          <div className="w-2.5 h-2.5 rounded-[2px] bg-zinc-200 dark:bg-zinc-800" />
          <div className="w-2.5 h-2.5 rounded-[2px] bg-emerald-700/40 dark:bg-emerald-800/60" />
          <div className="w-2.5 h-2.5 rounded-[2px] bg-emerald-600/70 dark:bg-emerald-600/80" />
          <div className="w-2.5 h-2.5 rounded-[2px] bg-emerald-500" />
          <div className="w-2.5 h-2.5 rounded-[2px] bg-emerald-400" />
          <span>More</span>
        </div>
      </div>
    </div>
  );
};
