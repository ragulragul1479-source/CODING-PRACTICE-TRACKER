import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { Navbar } from './Navbar';
import { ProblemFormModal } from '../problems/ProblemFormModal';
import { SessionFormModal } from '../sessions/SessionFormModal';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { problemService } from '../../services/problemService';
import { sessionService } from '../../services/sessionService';

export const AppLayout: React.FC = () => {
  const { user } = useAuth();
  const toast = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isProblemModalOpen, setIsProblemModalOpen] = useState(false);
  const [isSessionModalOpen, setIsSessionModalOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const handleCreateProblem = async (data: any) => {
    try {
      await problemService.createProblem(data);
      toast.success('Coding problem added successfully!', 'Problem Saved');
      setIsProblemModalOpen(false);
      setRefreshKey((prev) => prev + 1);
    } catch (err: any) {
      toast.error(err.message || 'Failed to create problem', 'Error');
    }
  };

  const handleCreateSession = async (data: any) => {
    try {
      await sessionService.createSession(data);
      toast.success('Practice session logged successfully!', 'Session Recorded');
      setIsSessionModalOpen(false);
      setRefreshKey((prev) => prev + 1);
    } catch (err: any) {
      toast.error(err.message || 'Failed to log session', 'Error');
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 flex flex-col font-sans antialiased transition-colors">
      <Sidebar
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        solvedCount={12}
        currentStreak={7}
      />

      <div className="lg:pl-64 flex flex-col min-h-screen flex-1">
        <Navbar
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onQuickAddProblem={() => setIsProblemModalOpen(true)}
          onQuickAddSession={() => setIsSessionModalOpen(true)}
          currentStreak={7}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet context={{ refreshKey, triggerRefresh: () => setRefreshKey((k) => k + 1) }} />
        </main>
      </div>

      {/* Quick Add Problem Modal */}
      <ProblemFormModal
        isOpen={isProblemModalOpen}
        onClose={() => setIsProblemModalOpen(false)}
        onSubmit={handleCreateProblem}
      />

      {/* Quick Add Session Modal */}
      <SessionFormModal
        isOpen={isSessionModalOpen}
        onClose={() => setIsSessionModalOpen(false)}
        onSubmit={handleCreateSession}
      />
    </div>
  );
};
