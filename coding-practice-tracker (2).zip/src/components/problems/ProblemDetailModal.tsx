import React from 'react';
import { Modal } from '../common/Modal';
import { DifficultyBadge, StatusBadge, PlatformBadge } from '../common/Badge';
import { CodingProblem } from '../../types';
import {
  ExternalLink,
  Github,
  Clock,
  Calendar,
  CheckCircle2,
  XCircle,
  Edit2,
  Trash2,
} from 'lucide-react';

interface ProblemDetailModalProps {
  problem: CodingProblem | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (problem: CodingProblem) => void;
  onDelete: (id: number) => void;
  onToggleStatus: (id: number) => void;
}

export const ProblemDetailModal: React.FC<ProblemDetailModalProps> = ({
  problem,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  onToggleStatus,
}) => {
  if (!problem) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={problem.title}
      subtitle={`Added on ${new Date(problem.createdAt).toLocaleDateString()}`}
      maxWidth="2xl"
    >
      <div className="space-y-6">
        {/* Badges Bar */}
        <div className="flex flex-wrap items-center gap-2.5 pb-4 border-b border-zinc-100 dark:border-zinc-800">
          <DifficultyBadge difficulty={problem.difficulty} size="md" />
          <StatusBadge status={problem.status} />
          <PlatformBadge platform={problem.platform} />
          <span className="px-2.5 py-1 rounded-md bg-zinc-100 dark:bg-zinc-800 text-xs font-medium text-zinc-700 dark:text-zinc-300">
            {problem.topic}
          </span>
        </div>

        {/* Description */}
        {problem.description && (
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-1.5">
              Problem Description
            </h4>
            <p className="text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed bg-zinc-50 dark:bg-zinc-800/40 p-3.5 rounded-xl border border-zinc-100 dark:border-zinc-800">
              {problem.description}
            </p>
          </div>
        )}

        {/* Notes & Key Algorithmic Insight */}
        {problem.notes && (
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-zinc-400 mb-1.5">
              Solution Notes & Key Takeaways
            </h4>
            <div className="text-sm font-mono text-zinc-800 dark:text-zinc-200 leading-relaxed bg-zinc-900 text-zinc-100 dark:bg-zinc-950 p-4 rounded-xl border border-zinc-800 whitespace-pre-wrap">
              {problem.notes}
            </div>
          </div>
        )}

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div className="p-3 bg-zinc-50 dark:bg-zinc-800/40 rounded-xl border border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
              <Clock className="w-3.5 h-3.5" />
              <span>Time Spent</span>
            </div>
            <span className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
              {problem.timeSpentMinutes ? `${problem.timeSpentMinutes} mins` : 'Not recorded'}
            </span>
          </div>

          <div className="p-3 bg-zinc-50 dark:bg-zinc-800/40 rounded-xl border border-zinc-100 dark:border-zinc-800">
            <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
              <Calendar className="w-3.5 h-3.5" />
              <span>Solved Date</span>
            </div>
            <span className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
              {problem.solvedDate ? new Date(problem.solvedDate).toLocaleDateString() : 'Unsolved'}
            </span>
          </div>

          <div className="p-3 bg-zinc-50 dark:bg-zinc-800/40 rounded-xl border border-zinc-100 dark:border-zinc-800 col-span-2 sm:col-span-1">
            <div className="flex items-center gap-1.5 text-xs text-zinc-400 mb-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Status</span>
            </div>
            <span className="text-sm font-semibold text-zinc-800 dark:text-zinc-200">
              {problem.status === 'SOLVED' ? 'Solved' : 'In Progress'}
            </span>
          </div>
        </div>

        {/* Direct Links */}
        <div className="flex flex-wrap items-center gap-3">
          {problem.problemUrl && (
            <a
              href={problem.problemUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 transition-colors border border-zinc-200 dark:border-zinc-700"
            >
              <ExternalLink className="w-3.5 h-3.5 text-indigo-500" />
              View Problem on {problem.platform}
            </a>
          )}

          {problem.solutionUrl && (
            <a
              href={problem.solutionUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 transition-colors border border-zinc-200 dark:border-zinc-700"
            >
              <Github className="w-3.5 h-3.5 text-zinc-700 dark:text-zinc-300" />
              View Source Solution
            </a>
          )}
        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-5 border-t border-zinc-100 dark:border-zinc-800">
          <button
            onClick={() => {
              onToggleStatus(problem.id);
            }}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              problem.status === 'SOLVED'
                ? 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200'
                : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm'
            }`}
          >
            {problem.status === 'SOLVED' ? (
              <>
                <XCircle className="w-4 h-4 text-zinc-400" />
                Mark as Unsolved
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                Mark as Solved
              </>
            )}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onEdit(problem);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 transition-colors"
            >
              <Edit2 className="w-3.5 h-3.5" />
              Edit
            </button>

            <button
              onClick={() => {
                onClose();
                onDelete(problem.id);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Delete
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
