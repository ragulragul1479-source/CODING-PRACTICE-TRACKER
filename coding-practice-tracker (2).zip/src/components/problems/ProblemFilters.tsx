import React from 'react';
import { Difficulty, ProblemStatus } from '../../types';
import { Search, Filter, ArrowUpDown, LayoutGrid, List } from 'lucide-react';

interface ProblemFiltersProps {
  keyword: string;
  onKeywordChange: (val: string) => void;
  status: ProblemStatus | 'ALL';
  onStatusChange: (val: ProblemStatus | 'ALL') => void;
  difficulty: Difficulty | 'ALL';
  onDifficultyChange: (val: Difficulty | 'ALL') => void;
  topic: string;
  onTopicChange: (val: string) => void;
  platform: string;
  onPlatformChange: (val: string) => void;
  sortBy: string;
  onSortByChange: (val: string) => void;
  sortDirection: 'asc' | 'desc';
  onSortDirectionToggle: () => void;
  viewMode: 'table' | 'grid';
  onViewModeChange: (val: 'table' | 'grid') => void;
  topicsList: string[];
  platformsList: string[];
}

export const ProblemFilters: React.FC<ProblemFiltersProps> = ({
  keyword,
  onKeywordChange,
  status,
  onStatusChange,
  difficulty,
  onDifficultyChange,
  topic,
  onTopicChange,
  platform,
  onPlatformChange,
  sortBy,
  onSortByChange,
  sortDirection,
  onSortDirectionToggle,
  viewMode,
  onViewModeChange,
  topicsList,
  platformsList,
}) => {
  return (
    <div className="space-y-3.5 bg-white dark:bg-zinc-900 p-4 sm:p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
      {/* Search and Main Controls Bar */}
      <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={keyword}
            onChange={(e) => onKeywordChange(e.target.value)}
            placeholder="Search problems by title, topic, platform, or notes..."
            className="w-full pl-10 pr-4 py-2 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
          />
          {keyword && (
            <button
              onClick={() => onKeywordChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-zinc-600"
            >
              Clear
            </button>
          )}
        </div>

        {/* View Mode & Sort Controls */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Sort By Dropdown */}
          <div className="flex items-center gap-1.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl px-2.5 py-1.5 text-xs">
            <span className="text-zinc-400 hidden sm:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => onSortByChange(e.target.value)}
              className="bg-transparent text-zinc-800 dark:text-zinc-200 focus:outline-none cursor-pointer text-xs font-medium"
            >
              <option value="createdAt">Date Added</option>
              <option value="title">Problem Title</option>
              <option value="difficulty">Difficulty</option>
              <option value="timeSpentMinutes">Time Spent</option>
            </select>
            <button
              onClick={onSortDirectionToggle}
              title={`Sort ${sortDirection === 'asc' ? 'Ascending' : 'Descending'}`}
              className="p-1 hover:bg-zinc-200 dark:hover:bg-zinc-700 rounded text-zinc-600 dark:text-zinc-300"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Grid / Table Toggle */}
          <div className="flex items-center bg-zinc-100 dark:bg-zinc-800 p-1 rounded-xl border border-zinc-200/60 dark:border-zinc-700/60">
            <button
              onClick={() => onViewModeChange('table')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300'
              }`}
              title="Table View"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => onViewModeChange('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid'
                  ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Filter Pills Row */}
      <div className="flex flex-wrap items-center gap-2.5 pt-2 border-t border-zinc-100 dark:border-zinc-800 text-xs">
        <span className="text-zinc-400 flex items-center gap-1 font-medium">
          <Filter className="w-3 h-3" /> Filters:
        </span>

        {/* Status Filters */}
        <div className="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-800/80 p-0.5 rounded-lg">
          {(['ALL', 'SOLVED', 'UNSOLVED'] as (ProblemStatus | 'ALL')[]).map((s) => (
            <button
              key={s}
              onClick={() => onStatusChange(s)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${
                status === s
                  ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              {s === 'ALL' ? 'All Status' : s === 'SOLVED' ? 'Solved' : 'Unsolved'}
            </button>
          ))}
        </div>

        {/* Difficulty Filters */}
        <div className="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-800/80 p-0.5 rounded-lg">
          {(['ALL', 'EASY', 'MEDIUM', 'HARD'] as (Difficulty | 'ALL')[]).map((d) => (
            <button
              key={d}
              onClick={() => onDifficultyChange(d)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-all ${
                difficulty === d
                  ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
              }`}
            >
              {d === 'ALL' ? 'All Diff' : d}
            </button>
          ))}
        </div>

        {/* Topic Select */}
        <select
          value={topic}
          onChange={(e) => onTopicChange(e.target.value)}
          className="px-2.5 py-1 bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 rounded-lg border-0 text-[11px] font-medium focus:ring-1 focus:ring-indigo-500 cursor-pointer"
        >
          <option value="ALL">All Topics</option>
          {topicsList.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>

        {/* Platform Select */}
        <select
          value={platform}
          onChange={(e) => onPlatformChange(e.target.value)}
          className="px-2.5 py-1 bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 rounded-lg border-0 text-[11px] font-medium focus:ring-1 focus:ring-indigo-500 cursor-pointer"
        >
          <option value="ALL">All Platforms</option>
          {platformsList.map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
