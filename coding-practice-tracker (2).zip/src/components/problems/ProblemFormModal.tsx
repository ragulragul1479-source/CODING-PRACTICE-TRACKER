import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { CodingProblem, Difficulty, ProblemStatus } from '../../types';

interface ProblemFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<void>;
  initialData?: CodingProblem | null;
}

const TOPICS = [
  'Arrays & Hashing',
  'Two Pointers',
  'Sliding Window',
  'Stack',
  'Binary Search',
  'Linked List',
  'Trees',
  'Tries',
  'Heap / Priority Queue',
  'Backtracking',
  'Graphs',
  'Dynamic Programming',
  'Greedy',
  'Intervals',
  'Math & Geometry',
  'Bit Manipulation',
  'Design',
];

const PLATFORMS = [
  'LeetCode',
  'Codeforces',
  'HackerRank',
  'NeetCode',
  'CodeChef',
  'GeeksforGeeks',
  'AtCoder',
  'Other',
];

export const ProblemFormModal: React.FC<ProblemFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [difficulty, setDifficulty] = useState<Difficulty>('EASY');
  const [topic, setTopic] = useState('Arrays & Hashing');
  const [customTopic, setCustomTopic] = useState('');
  const [platform, setPlatform] = useState('LeetCode');
  const [customPlatform, setCustomPlatform] = useState('');
  const [problemUrl, setProblemUrl] = useState('');
  const [solutionUrl, setSolutionUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<ProblemStatus>('UNSOLVED');
  const [solvedDate, setSolvedDate] = useState('');
  const [timeSpentMinutes, setTimeSpentMinutes] = useState(15);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (initialData) {
      setTitle(initialData.title);
      setDescription(initialData.description || '');
      setDifficulty(initialData.difficulty);
      if (TOPICS.includes(initialData.topic)) {
        setTopic(initialData.topic);
        setCustomTopic('');
      } else {
        setTopic('Other');
        setCustomTopic(initialData.topic);
      }
      if (PLATFORMS.includes(initialData.platform)) {
        setPlatform(initialData.platform);
        setCustomPlatform('');
      } else {
        setPlatform('Other');
        setCustomPlatform(initialData.platform);
      }
      setProblemUrl(initialData.problemUrl || '');
      setSolutionUrl(initialData.solutionUrl || '');
      setNotes(initialData.notes || '');
      setStatus(initialData.status);
      setSolvedDate(initialData.solvedDate || '');
      setTimeSpentMinutes(initialData.timeSpentMinutes || 0);
    } else {
      setTitle('');
      setDescription('');
      setDifficulty('EASY');
      setTopic('Arrays & Hashing');
      setCustomTopic('');
      setPlatform('LeetCode');
      setCustomPlatform('');
      setProblemUrl('');
      setSolutionUrl('');
      setNotes('');
      setStatus('UNSOLVED');
      setSolvedDate('');
      setTimeSpentMinutes(15);
    }
  }, [initialData, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSubmitting(true);
    try {
      const selectedTopic = topic === 'Other' && customTopic.trim() ? customTopic.trim() : topic;
      const selectedPlatform =
        platform === 'Other' && customPlatform.trim() ? customPlatform.trim() : platform;

      await onSubmit({
        title: title.trim(),
        description: description.trim() || undefined,
        difficulty,
        topic: selectedTopic,
        platform: selectedPlatform,
        problemUrl: problemUrl.trim() || undefined,
        solutionUrl: solutionUrl.trim() || undefined,
        notes: notes.trim() || undefined,
        status,
        solvedDate: status === 'SOLVED' ? (solvedDate || new Date().toISOString().split('T')[0]) : null,
        timeSpentMinutes: Number(timeSpentMinutes) || 0,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={initialData ? 'Edit Coding Problem' : 'Add New Coding Problem'}
      subtitle="Track your algorithm questions, time spent, and key solutions"
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Title */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
            Problem Title *
          </label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Trapping Rain Water, Course Schedule..."
            className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 dark:focus:ring-indigo-400/50 transition-all placeholder:text-zinc-400"
          />
        </div>

        {/* Difficulty & Status Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Difficulty *
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['EASY', 'MEDIUM', 'HARD'] as Difficulty[]).map((d) => (
                <button
                  type="button"
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`py-2 text-xs font-semibold rounded-xl border transition-all ${
                    difficulty === d
                      ? d === 'EASY'
                        ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border-emerald-500'
                        : d === 'MEDIUM'
                        ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400 border-amber-500'
                        : 'bg-rose-500/20 text-rose-600 dark:text-rose-400 border-rose-500'
                      : 'bg-zinc-50 dark:bg-zinc-800/40 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Status *
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setStatus('SOLVED')}
                className={`py-2 text-xs font-semibold rounded-xl border transition-all ${
                  status === 'SOLVED'
                    ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border-emerald-500'
                    : 'bg-zinc-50 dark:bg-zinc-800/40 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-700'
                }`}
              >
                ✓ Solved
              </button>
              <button
                type="button"
                onClick={() => setStatus('UNSOLVED')}
                className={`py-2 text-xs font-semibold rounded-xl border transition-all ${
                  status === 'UNSOLVED'
                    ? 'bg-zinc-500/20 text-zinc-800 dark:text-zinc-200 border-zinc-500'
                    : 'bg-zinc-50 dark:bg-zinc-800/40 text-zinc-600 dark:text-zinc-400 border-zinc-200 dark:border-zinc-700'
                }`}
              >
                ○ Unsolved
              </button>
            </div>
          </div>
        </div>

        {/* Topic & Platform Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Topic / Category *
            </label>
            <select
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            >
              {TOPICS.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
              <option value="Other">Custom Topic...</option>
            </select>
            {topic === 'Other' && (
              <input
                type="text"
                value={customTopic}
                onChange={(e) => setCustomTopic(e.target.value)}
                placeholder="Enter custom topic name..."
                className="mt-2 w-full px-3.5 py-2 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs"
              />
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Platform *
            </label>
            <select
              value={platform}
              onChange={(e) => setPlatform(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            >
              {PLATFORMS.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
            {platform === 'Other' && (
              <input
                type="text"
                value={customPlatform}
                onChange={(e) => setCustomPlatform(e.target.value)}
                placeholder="Enter platform name..."
                className="mt-2 w-full px-3.5 py-2 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs"
              />
            )}
          </div>
        </div>

        {/* URLs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Problem URL (Optional)
            </label>
            <input
              type="url"
              value={problemUrl}
              onChange={(e) => setProblemUrl(e.target.value)}
              placeholder="https://leetcode.com/problems/..."
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Solution URL / Repo Link (Optional)
            </label>
            <input
              type="url"
              value={solutionUrl}
              onChange={(e) => setSolutionUrl(e.target.value)}
              placeholder="https://github.com/..."
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            />
          </div>
        </div>

        {/* Time spent and Solved Date */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Time Spent (Minutes)
            </label>
            <input
              type="number"
              min="0"
              value={timeSpentMinutes}
              onChange={(e) => setTimeSpentMinutes(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            />
          </div>

          {status === 'SOLVED' && (
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
                Solved Date
              </label>
              <input
                type="date"
                value={solvedDate || new Date().toISOString().split('T')[0]}
                onChange={(e) => setSolvedDate(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              />
            </div>
          )}
        </div>

        {/* Notes & Solution Key Takeaways */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
            Notes & Key Algorithmic Insight
          </label>
          <textarea
            rows={3}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. Time: O(N), Space: O(1). Note edge cases on empty arrays, monotonic stack approach..."
            className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
          />
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-zinc-100 dark:border-zinc-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-sm font-medium text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-5 py-2.5 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-sm transition-all flex items-center gap-2"
          >
            {isSubmitting && <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
            {initialData ? 'Save Changes' : 'Add Problem'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
