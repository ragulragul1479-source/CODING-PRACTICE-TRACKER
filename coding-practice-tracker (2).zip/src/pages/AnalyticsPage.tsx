import React, { useEffect, useState } from 'react';
import { analyticsService } from '../services/dashboardService';
import { AnalyticsData } from '../types';
import { useOutletContext } from 'react-router-dom';
import {
  BarChart3,
  PieChart as PieIcon,
  TrendingUp,
  Award,
  Layers,
  Calendar,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  AreaChart,
  Area,
} from 'recharts';

export const AnalyticsPage: React.FC = () => {
  const { refreshKey } = useOutletContext<{ refreshKey: number }>();
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setLoading(true);
        const res = await analyticsService.getAnalytics();
        setData(res);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, [refreshKey]);

  if (loading && !data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] gap-3">
        <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs text-zinc-400">Aggregating analytics & topic metrics...</p>
      </div>
    );
  }

  const {
    totalProblems = 0,
    totalSolved = 0,
    totalHours = 0,
    difficultyStats = { easySolved: 0, easyTotal: 0, mediumSolved: 0, mediumTotal: 0, hardSolved: 0, hardTotal: 0 },
    topicStats = [],
    platformStats = [],
    monthlyStats = [],
    dayOfWeekDistribution = {},
  } = data || {};

  // Difficulty Pie Data
  const difficultyPieData = [
    { name: 'Easy', value: difficultyStats.easySolved, color: '#10B981' },
    { name: 'Medium', value: difficultyStats.mediumSolved, color: '#F59E0B' },
    { name: 'Hard', value: difficultyStats.hardSolved, color: '#F43F5E' },
  ].filter((d) => d.value > 0);

  // Day of week bar data
  const dayOrder = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const dayOfWeekData = dayOrder.map((day) => ({
    day,
    count: dayOfWeekDistribution[day] || 0,
  }));

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100 flex items-center gap-2.5">
          <BarChart3 className="w-6 h-6 text-indigo-500" />
          Analytics & Mastery Insights
        </h1>
        <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
          Deep-dive into difficulty distribution, algorithmic topic coverage, and practice velocity
        </p>
      </div>

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Total Solved</span>
          <p className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-100 mt-2 font-mono">
            {totalSolved}
          </p>
          <span className="text-xs text-emerald-500 font-medium mt-1 block">
            {totalProblems > 0 ? Math.round((totalSolved / totalProblems) * 100) : 0}% completion rate
          </span>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Total Practice Time</span>
          <p className="text-3xl font-extrabold text-indigo-600 dark:text-indigo-400 mt-2 font-mono">
            {totalHours}h
          </p>
          <span className="text-xs text-zinc-400 mt-1 block">Across all logged sessions</span>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Topics Explored</span>
          <p className="text-3xl font-extrabold text-purple-600 dark:text-purple-400 mt-2 font-mono">
            {topicStats.length}
          </p>
          <span className="text-xs text-zinc-400 mt-1 block">Data structures & categories</span>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">Platforms Tracked</span>
          <p className="text-3xl font-extrabold text-amber-500 mt-2 font-mono">
            {platformStats.length}
          </p>
          <span className="text-xs text-zinc-400 mt-1 block">LeetCode, Codeforces, NeetCode...</span>
        </div>
      </div>

      {/* Row 1 Charts: Difficulty Donut & Monthly Progress Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Difficulty Distribution Donut */}
        <div className="bg-white dark:bg-zinc-900 p-5 sm:p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-indigo-500" />
              Difficulty Distribution
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Proportion of Easy, Medium, and Hard problems solved
            </p>
          </div>

          <div className="h-64 my-4 flex items-center justify-center">
            {difficultyPieData.length === 0 ? (
              <p className="text-xs text-zinc-400">No solved problems data yet.</p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={difficultyPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {difficultyPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: any, name: any) => [`${value} problems`, name]}
                    contentStyle={{
                      backgroundColor: '#18181b',
                      borderColor: '#27272a',
                      borderRadius: '12px',
                      color: '#f4f4f5',
                      fontSize: '12px',
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 pt-3 border-t border-zinc-100 dark:border-zinc-800 text-center text-xs">
            <div>
              <span className="text-emerald-500 font-semibold">Easy</span>
              <p className="font-mono font-bold text-zinc-800 dark:text-zinc-200 mt-0.5">
                {difficultyStats.easySolved} / {difficultyStats.easyTotal}
              </p>
            </div>
            <div>
              <span className="text-amber-500 font-semibold">Medium</span>
              <p className="font-mono font-bold text-zinc-800 dark:text-zinc-200 mt-0.5">
                {difficultyStats.mediumSolved} / {difficultyStats.mediumTotal}
              </p>
            </div>
            <div>
              <span className="text-rose-500 font-semibold">Hard</span>
              <p className="font-mono font-bold text-zinc-800 dark:text-zinc-200 mt-0.5">
                {difficultyStats.hardSolved} / {difficultyStats.hardTotal}
              </p>
            </div>
          </div>
        </div>

        {/* Monthly Practice Hours Trend */}
        <div className="bg-white dark:bg-zinc-900 p-5 sm:p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-500" />
              Practice Velocity (Monthly)
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Problems solved and practice hours logged each month
            </p>
          </div>

          <div className="h-64 my-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyStats} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366F1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366F1" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" opacity={0.3} />
                <XAxis dataKey="month" stroke="#71717a" fontSize={11} />
                <YAxis stroke="#71717a" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '12px',
                    color: '#f4f4f5',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="hoursPracticed"
                  name="Practice Hours"
                  stroke="#6366F1"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorHours)"
                />
                <Area
                  type="monotone"
                  dataKey="problemsSolved"
                  name="Problems Solved"
                  stroke="#10B981"
                  strokeWidth={2}
                  fillOpacity={0.1}
                  fill="#10B981"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-xs text-zinc-400 pt-3 border-t border-zinc-100 dark:border-zinc-800">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
              Hours Practiced
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              Problems Solved
            </span>
          </div>
        </div>
      </div>

      {/* Row 2: Topic Mastery Breakdown (Horizontal Bars) & Day-of-Week Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Topic Mastery (2 Cols) */}
        <div className="bg-white dark:bg-zinc-900 p-5 sm:p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs lg:col-span-2">
          <div className="mb-4">
            <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-500" />
              Algorithmic Topic Mastery
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Problems solved vs total logged by category
            </p>
          </div>

          <div className="space-y-3.5">
            {topicStats.length === 0 ? (
              <p className="text-xs text-zinc-400 py-6 text-center">No topics recorded yet.</p>
            ) : (
              topicStats.map((t) => (
                <div key={t.topic} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-medium">
                    <span className="text-zinc-800 dark:text-zinc-200">{t.topic}</span>
                    <span className="font-mono text-zinc-500">
                      {t.solved} / {t.total} ({t.percentage}%)
                    </span>
                  </div>
                  <div className="w-full bg-zinc-100 dark:bg-zinc-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${t.percentage}%` }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Day of Week Frequency (1 Col) */}
        <div className="bg-white dark:bg-zinc-900 p-5 sm:p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-500" />
              Day of Week Activity
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Activity distribution by weekday
            </p>
          </div>

          <div className="h-56 my-3">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dayOfWeekData} margin={{ top: 10, right: 0, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" opacity={0.3} />
                <XAxis dataKey="day" stroke="#71717a" fontSize={10} />
                <YAxis stroke="#71717a" fontSize={10} />
                <Tooltip
                  formatter={(val: any) => [`${val} practice actions`, 'Count']}
                  contentStyle={{
                    backgroundColor: '#18181b',
                    borderColor: '#27272a',
                    borderRadius: '12px',
                    color: '#f4f4f5',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="count" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <p className="text-[11px] text-zinc-400 text-center pt-2 border-t border-zinc-100 dark:border-zinc-800">
            Maintaining a balanced weekend/weekday cadence helps lock in long-term retention.
          </p>
        </div>
      </div>
    </div>
  );
};
