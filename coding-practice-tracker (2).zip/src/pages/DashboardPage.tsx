import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { dashboardService } from '../services/dashboardService';
import { problemService } from '../services/problemService';
import { DashboardData, CodingProblem } from '../types';
import { Heatmap } from '../components/common/Heatmap';
import { DifficultyBadge, StatusBadge, PlatformBadge } from '../components/common/Badge';
import { ProblemDetailModal } from '../components/problems/ProblemDetailModal';
import { ProblemFormModal } from '../components/problems/ProblemFormModal';
import { useToast } from '../context/ToastContext';
import { useOutletContext } from 'react-router-dom';
import {
  Code2,
  Flame,
  Clock,
  Target,
  CheckCircle2,
  Plus,
  Calendar,
  Sparkles,
  RefreshCw,
  ExternalLink,
  ChevronRight,
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const toast = useToast();
  const { refreshKey, triggerRefresh } = useOutletContext<{
    refreshKey: number;
    triggerRefresh: () => void;
  }>();

  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedProblem, setSelectedProblem] = useState<CodingProblem | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingProblem, setEditingProblem] = useState<CodingProblem | null>(null);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const res = await dashboardService.getDashboard();
      setData(res);
    } catch (err) {
      console.error('Failed to fetch dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [refreshKey]);

  const handleToggleStatus = async (id: number) => {
    try {
      const updated = await problemService.toggleStatus(id);
      toast.success(
        `Marked as ${updated.status === 'SOLVED' ? 'Solved' : 'Unsolved'}!`,
        'Status Updated'
      );
      if (selectedProblem && selectedProblem.id === id) {
        setSelectedProblem(updated);
      }
      triggerRefresh();
    } catch (err: any) {
      toast.error('Failed to toggle status', 'Error');
    }
  };

  const handleEditSubmit = async (formData: any) => {
    if (!editingProblem) return;
    try {
      const updated = await problemService.updateProblem(editingProblem.id, formData);
      toast.success('Problem updated successfully!', 'Saved');
      setIsEditOpen(false);
      if (selectedProblem && selectedProblem.id === editingProblem.id) {
        setSelectedProblem(updated);
      }
      triggerRefresh();
    } catch (err: any) {
      toast.error('Failed to update problem', 'Error');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await problemService.deleteProblem(id);
      toast.success('Problem removed', 'Deleted');
      setIsDetailOpen(false);
      triggerRefresh();
    } catch (err: any) {
      toast.error('Failed to delete problem', 'Error');
    }
  };

  if (loading && !data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] gap-3">
        <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs text-zinc-400">Loading your practice metrics...</p>
      </div>
    );
  }

  const {
    totalProblems = 0,
    totalSolvedProblems = 0,
    completionRate = 0,
    totalPracticeHours = 0,
    currentStreak = 0,
    longestStreak = 0,
    practicedToday = false,
    difficultyStats = {
      easySolved: 0,
      easyTotal: 0,
      mediumSolved: 0,
      mediumTotal: 0,
      hardSolved: 0,
      hardTotal: 0,
    },
    progress = {
      problemsSolvedThisWeek: 0,
      hoursSpentThisWeek: 0,
      targetDailyProblems: 3,
      targetWeeklyHours: 10,
      weeklyGoalPercentage: 0,
    },
    recentActivities = [],
    activityHeatmap = [],
  } = data || {};

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Welcome & Goal Snapshot Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-zinc-900 p-5 sm:p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100">
              Welcome back, {user?.fullName || user?.username || 'Engineer'}!
            </h1>
            <Sparkles className="w-5 h-5 text-amber-500 hidden sm:inline" />
          </div>
          <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
            {practicedToday
              ? 'Great work! You have already practiced today. Keep pushing your boundaries!'
              : 'You have not logged any practice yet today. Solve a problem to keep your streak alive!'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchDashboardData}
            className="p-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-600 dark:text-zinc-400 transition-colors"
            title="Refresh Dashboard"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <div className="px-4 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800/80 text-indigo-700 dark:text-indigo-300 text-xs font-semibold flex items-center gap-2">
            <Target className="w-4 h-4 text-indigo-500" />
            <span>Target: {progress.targetDailyProblems} problems / day</span>
          </div>
        </div>
      </div>

      {/* 4 Main Key Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Solved */}
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Problems Solved
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-100 font-mono">
              {totalSolvedProblems}
            </span>
            <span className="text-xs text-zinc-400 font-mono">/ {totalProblems} total</span>
          </div>
          {/* Progress Bar */}
          <div className="mt-3">
            <div className="w-full bg-zinc-100 dark:bg-zinc-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${completionRate}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[11px] text-zinc-400 mt-1.5">
              <span>{completionRate}% Completed</span>
              <span>{totalProblems - totalSolvedProblems} remaining</span>
            </div>
          </div>
        </div>

        {/* Card 2: Current Streak */}
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Current Streak
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Flame className="w-4 h-4 fill-amber-400" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-amber-500 font-mono">
              {currentStreak}
            </span>
            <span className="text-xs text-zinc-400 font-medium">
              Day{currentStreak === 1 ? '' : 's'}
            </span>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px]">
            <span className="text-zinc-400">Best: {longestStreak} days</span>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                practicedToday
                  ? 'bg-emerald-500/10 text-emerald-500'
                  : 'bg-amber-500/10 text-amber-500'
              }`}
            >
              {practicedToday ? '✓ Active Today' : 'Pending Today'}
            </span>
          </div>
        </div>

        {/* Card 3: Total Practice Time */}
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Practice Time
            </span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-100 font-mono">
              {totalPracticeHours}
            </span>
            <span className="text-xs text-zinc-400 font-medium">Hours</span>
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px] text-zinc-400">
            <span>This Week: {progress.hoursSpentThisWeek}h</span>
            <span>Monthly: {progress.hoursSpentThisMonth || 0}h</span>
          </div>
        </div>

        {/* Card 4: Weekly Goal Progress */}
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Weekly Goal
            </span>
            <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-purple-600 dark:text-purple-400 font-mono">
              {progress.weeklyGoalPercentage}%
            </span>
            <span className="text-xs text-zinc-400 font-mono">
              ({progress.hoursSpentThisWeek}h / {progress.targetWeeklyHours}h)
            </span>
          </div>
          <div className="mt-3">
            <div className="w-full bg-zinc-100 dark:bg-zinc-800 h-1.5 rounded-full overflow-hidden">
              <div
                className="bg-purple-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, progress.weeklyGoalPercentage)}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[11px] text-zinc-400 mt-1.5">
              <span>{progress.problemsSolvedThisWeek} solved this week</span>
              <span>{Math.max(0, progress.targetWeeklyHours - progress.hoursSpentThisWeek).toFixed(1)}h left</span>
            </div>
          </div>
        </div>
      </div>

      {/* Difficulty Breakdown Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Easy */}
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-emerald-500/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              Easy Problems
            </span>
            <p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100 mt-1 font-mono">
              {difficultyStats.easySolved}{' '}
              <span className="text-xs text-zinc-400">/ {difficultyStats.easyTotal}</span>
            </p>
            <span className="text-xs text-zinc-400 mt-0.5 block">
              {difficultyStats.easyTotal > 0
                ? Math.round((difficultyStats.easySolved / difficultyStats.easyTotal) * 100)
                : 0}
              % Completed
            </span>
          </div>
          <div className="w-12 h-12 rounded-full bg-emerald-500/10 border-2 border-emerald-500 flex items-center justify-center text-emerald-600 font-bold text-xs">
            {difficultyStats.easyTotal > 0
              ? `${Math.round((difficultyStats.easySolved / difficultyStats.easyTotal) * 100)}%`
              : '0%'}
          </div>
        </div>

        {/* Medium */}
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-amber-500/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              Medium Problems
            </span>
            <p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100 mt-1 font-mono">
              {difficultyStats.mediumSolved}{' '}
              <span className="text-xs text-zinc-400">/ {difficultyStats.mediumTotal}</span>
            </p>
            <span className="text-xs text-zinc-400 mt-0.5 block">
              {difficultyStats.mediumTotal > 0
                ? Math.round((difficultyStats.mediumSolved / difficultyStats.mediumTotal) * 100)
                : 0}
              % Completed
            </span>
          </div>
          <div className="w-12 h-12 rounded-full bg-amber-500/10 border-2 border-amber-500 flex items-center justify-center text-amber-600 font-bold text-xs">
            {difficultyStats.mediumTotal > 0
              ? `${Math.round((difficultyStats.mediumSolved / difficultyStats.mediumTotal) * 100)}%`
              : '0%'}
          </div>
        </div>

        {/* Hard */}
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-rose-500/20 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-rose-600 dark:text-rose-400">
              Hard Problems
            </span>
            <p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100 mt-1 font-mono">
              {difficultyStats.hardSolved}{' '}
              <span className="text-xs text-zinc-400">/ {difficultyStats.hardTotal}</span>
            </p>
            <span className="text-xs text-zinc-400 mt-0.5 block">
              {difficultyStats.hardTotal > 0
                ? Math.round((difficultyStats.hardSolved / difficultyStats.hardTotal) * 100)
                : 0}
              % Completed
            </span>
          </div>
          <div className="w-12 h-12 rounded-full bg-rose-500/10 border-2 border-rose-500 flex items-center justify-center text-rose-600 font-bold text-xs">
            {difficultyStats.hardTotal > 0
              ? `${Math.round((difficultyStats.hardSolved / difficultyStats.hardTotal) * 100)}%`
              : '0%'}
          </div>
        </div>
      </div>

      {/* GitHub-Style 90-Day Activity Calendar Heatmap */}
      <div className="bg-white dark:bg-zinc-900 p-5 sm:p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-500" />
              Activity & Practice Heatmap
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Daily problem solving frequency and practice session history over the last 90 days
            </p>
          </div>
          <div className="hidden sm:flex items-center gap-1 text-xs font-mono text-amber-500 font-semibold">
            <Flame className="w-3.5 h-3.5 fill-amber-500" />
            <span>{currentStreak} Day Active Streak</span>
          </div>
        </div>

        <Heatmap data={activityHeatmap} />
      </div>

      {/* Recent Activity Feed */}
      <div className="bg-white dark:bg-zinc-900 p-5 sm:p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
              <Code2 className="w-4 h-4 text-indigo-500" />
              Recent Activity Feed
            </h2>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Latest coding problems solved and logged practice blocks
            </p>
          </div>
        </div>

        <div className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
          {recentActivities.length === 0 ? (
            <p className="text-xs text-zinc-400 py-6 text-center">No activity recorded yet.</p>
          ) : (
            recentActivities.map((act) => (
              <div
                key={act.id}
                className="py-3.5 flex items-center justify-between gap-4 hover:bg-zinc-50 dark:hover:bg-zinc-800/30 px-2 rounded-xl transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      act.type === 'PROBLEM_SOLVED'
                        ? 'bg-emerald-500/10 text-emerald-500'
                        : act.type === 'PRACTICE_SESSION'
                        ? 'bg-indigo-500/10 text-indigo-500'
                        : 'bg-zinc-500/10 text-zinc-500'
                    }`}
                  >
                    {act.type === 'PROBLEM_SOLVED' ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : act.type === 'PRACTICE_SESSION' ? (
                      <Clock className="w-4 h-4" />
                    ) : (
                      <Code2 className="w-4 h-4" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-semibold text-zinc-800 dark:text-zinc-200 truncate">
                      {act.title}
                    </h4>
                    <p className="text-xs text-zinc-400 truncate mt-0.5">{act.subtitle}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-[11px] text-zinc-400 font-mono">
                    {new Date(act.timestamp).toLocaleDateString(undefined, {
                      month: 'short',
                      day: 'numeric',
                    })}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Problem Modals */}
      <ProblemDetailModal
        problem={selectedProblem}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        onEdit={(p) => {
          setEditingProblem(p);
          setIsEditOpen(true);
        }}
        onDelete={handleDelete}
        onToggleStatus={handleToggleStatus}
      />

      <ProblemFormModal
        isOpen={isEditOpen}
        onClose={() => setIsEditOpen(false)}
        onSubmit={handleEditSubmit}
        initialData={editingProblem}
      />
    </div>
  );
};
