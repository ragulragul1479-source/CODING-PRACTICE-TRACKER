import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Code2,
  Flame,
  CheckCircle2,
  Calendar,
  BarChart3,
  ShieldCheck,
  Zap,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { isAuthenticated, demoLogin } = useAuth();
  const navigate = useNavigate();

  const handleDemoAccess = async () => {
    await demoLogin();
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Navigation */}
      <header className="border-b border-zinc-800/80 backdrop-blur-md sticky top-0 z-30 bg-zinc-950/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-base tracking-tight text-white">CodeTracker</span>
              <span className="text-[10px] ml-2 px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-mono">
                Spring + React
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <Link
                to="/dashboard"
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-xl transition-all shadow-sm"
              >
                Go to Dashboard
              </Link>
            ) : (
              <>
                <button
                  onClick={handleDemoAccess}
                  className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-zinc-300 hover:text-white bg-zinc-900 hover:bg-zinc-800 rounded-xl border border-zinc-800 transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Try Demo Account
                </button>

                <Link
                  to="/login"
                  className="px-3.5 py-2 text-xs font-medium text-zinc-300 hover:text-white transition-colors"
                >
                  Sign In
                </Link>

                <Link
                  to="/register"
                  className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 rounded-xl transition-all shadow-sm"
                >
                  Get Started
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-16 pb-20 px-4 sm:px-6 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-indigo-900/20 via-zinc-950 to-zinc-950 pointer-events-none" />

        <div className="max-w-4xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-medium animate-fadeIn">
            <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            Empowering engineers to master Data Structures & Algorithms
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight sm:leading-tight">
            Master LeetCode & DSA with <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400">
              Precision Tracking
            </span>
          </h1>

          <p className="text-base sm:text-lg text-zinc-400 max-w-2xl mx-auto leading-relaxed">
            Record every coding problem, monitor practice duration, maintain active streaks, and visualize your topic mastery with insightful analytics.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 pt-4">
            <button
              onClick={handleDemoAccess}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
            >
              <span>Explore Demo Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <Link
              to="/register"
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 active:bg-zinc-700 text-zinc-200 font-semibold text-sm border border-zinc-800 transition-all text-center"
            >
              Create Free Account
            </Link>
          </div>

          {/* Quick Credential Hint */}
          <p className="text-xs text-zinc-500 font-mono">
            Demo credentials: <span className="text-zinc-300">demouser</span> / <span className="text-zinc-300">Password123!</span>
          </p>
        </div>

        {/* Dashboard Preview Mock Container */}
        <div className="max-w-5xl mx-auto mt-14 rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4 sm:p-6 shadow-2xl backdrop-blur-sm relative">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-rose-500/80" />
              <div className="w-3 h-3 rounded-full bg-amber-500/80" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
              <span className="text-xs text-zinc-500 font-mono ml-2">Coding Practice Hub — Live Stats</span>
            </div>
            <span className="text-xs font-semibold text-amber-400 flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 fill-amber-400" /> 7-Day Streak
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800/80">
              <span className="text-xs text-zinc-400">Total Solved</span>
              <p className="text-2xl font-bold text-white mt-1">12 / 15</p>
              <span className="text-[11px] text-emerald-400 font-medium">80.0% completion</span>
            </div>

            <div className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800/80">
              <span className="text-xs text-zinc-400">Hours Practiced</span>
              <p className="text-2xl font-bold text-white mt-1">14.8 hrs</p>
              <span className="text-[11px] text-indigo-400 font-medium">12 active sessions</span>
            </div>

            <div className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800/80">
              <span className="text-xs text-zinc-400">Medium Problems</span>
              <p className="text-2xl font-bold text-amber-400 mt-1">6 Solved</p>
              <span className="text-[11px] text-zinc-400">Out of 7 added</span>
            </div>

            <div className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800/80">
              <span className="text-xs text-zinc-400">Weekly Goal</span>
              <p className="text-2xl font-bold text-emerald-400 mt-1">100%</p>
              <span className="text-[11px] text-zinc-400">12.0h / 12.0h</span>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="py-16 px-4 sm:px-6 bg-zinc-900/40 border-t border-zinc-800/60">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Designed for Daily Deliberate Practice
            </h2>
            <p className="text-sm text-zinc-400 mt-2">
              Everything you need to stay accountable, review key algorithms, and crush technical interviews.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-4">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Detailed Problem Tracking</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Log problems across LeetCode, Codeforces, HackerRank, and NeetCode. Store time spent, solution repos, and notes on algorithmic edge cases.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center mb-4">
                <Flame className="w-5 h-5" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Streak & Activity Heatmap</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Stay motivated with a GitHub-style 90-day activity calendar. Track daily problems solved, active streaks, and longest continuous chains.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mb-4">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Mastery Analytics</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Interactive charts illustrating difficulty distributions, topic coverage (Trees, Graphs, DP), practice trends, and time investments over time.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Tech Architecture Stack Banner */}
      <section className="py-12 px-4 sm:px-6 border-t border-zinc-800">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-6 text-xs text-zinc-400 font-mono">
          <div className="flex items-center gap-2 text-zinc-300 font-semibold">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>Built with Modern Production Architecture</span>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <span className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800">Java 21</span>
            <span className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800">Spring Boot 3</span>
            <span className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800">Spring Security (JWT)</span>
            <span className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800">PostgreSQL</span>
            <span className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800">React 18 + TS</span>
            <span className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800">Tailwind CSS</span>
            <span className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800">Recharts</span>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-zinc-900 py-6 text-center text-xs text-zinc-500">
        <p>© {new Date().getFullYear()} Coding Practice Tracker. Built for serious developers.</p>
      </footer>
    </div>
  );
};
