import React, { useEffect, useState } from 'react';
import { problemService } from '../services/problemService';
import { CodingProblem, Difficulty, ProblemStatus } from '../types';
import { ProblemFilters } from '../components/problems/ProblemFilters';
import { ProblemFormModal } from '../components/problems/ProblemFormModal';
import { ProblemDetailModal } from '../components/problems/ProblemDetailModal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { DifficultyBadge, StatusBadge, PlatformBadge } from '../components/common/Badge';
import { useToast } from '../context/ToastContext';
import { useOutletContext } from 'react-router-dom';
import confetti from 'canvas-confetti';
import {
  Plus,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Github,
  Clock,
  ChevronLeft,
  ChevronRight,
  Edit2,
  Trash2,
  Code2,
  FileText,
} from 'lucide-react';

export const ProblemsPage: React.FC = () => {
  const toast = useToast();
  const { refreshKey, triggerRefresh } = useOutletContext<{
    refreshKey: number;
    triggerRefresh: () => void;
  }>();

  // State
  const [problems, setProblems] = useState<CodingProblem[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [pageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(1);
  const [totalElements, setTotalElements] = useState(0);

  // Filters
  const [keyword, setKeyword] = useState('');
  const [status, setStatus] = useState<ProblemStatus | 'ALL'>('ALL');
  const [difficulty, setDifficulty] = useState<Difficulty | 'ALL'>('ALL');
  const [topic, setTopic] = useState('ALL');
  const [platform, setPlatform] = useState('ALL');
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingProblem, setEditingProblem] = useState<CodingProblem | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [detailProblem, setDetailProblem] = useState<CodingProblem | null>(null);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  // Topics & Platforms lists for filter dropdowns
  const [topicsList, setTopicsList] = useState<string[]>([]);
  const [platformsList, setPlatformsList] = useState<string[]>([]);

  const fetchProblems = async () => {
    try {
      setLoading(true);
      const res = await problemService.getProblems({
        keyword: keyword.trim() || undefined,
        status: status === 'ALL' ? undefined : status,
        difficulty: difficulty === 'ALL' ? undefined : difficulty,
        topic: topic === 'ALL' ? undefined : topic,
        platform: platform === 'ALL' ? undefined : platform,
        page,
        size: pageSize,
        sortBy,
        sortDirection,
      });

      setProblems(res.content);
      setTotalPages(res.totalPages);
      setTotalElements(res.totalElements);

      // Extract unique topics and platforms
      const allRes = await problemService.getProblems({ size: 200 });
      const uniqueTopics = Array.from(new Set(allRes.content.map((p) => p.topic))).filter(Boolean);
      const uniquePlatforms = Array.from(new Set(allRes.content.map((p) => p.platform))).filter(Boolean);
      setTopicsList(uniqueTopics);
      setPlatformsList(uniquePlatforms);
    } catch (err: any) {
      console.error(err);
      toast.error('Failed to load problems', 'Error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProblems();
  }, [keyword, status, difficulty, topic, platform, sortBy, sortDirection, page, refreshKey]);

  const handleToggleStatus = async (id: number) => {
    try {
      const updated = await problemService.toggleStatus(id);
      if (updated.status === 'SOLVED') {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.7 },
        });
        toast.success(`"${updated.title}" marked as Solved!`, 'Problem Solved 🎉');
      } else {
        toast.info(`"${updated.title}" marked as Unsolved.`, 'Status Updated');
      }

      if (detailProblem && detailProblem.id === id) {
        setDetailProblem(updated);
      }
      fetchProblems();
      triggerRefresh();
    } catch (err: any) {
      toast.error('Failed to update status', 'Error');
    }
  };

  const handleCreateProblem = async (formData: any) => {
    try {
      await problemService.createProblem(formData);
      toast.success('Problem added to your tracker!', 'Created');
      setIsAddModalOpen(false);
      fetchProblems();
      triggerRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create problem', 'Error');
    }
  };

  const handleEditProblem = async (formData: any) => {
    if (!editingProblem) return;
    try {
      const updated = await problemService.updateProblem(editingProblem.id, formData);
      toast.success('Problem updated successfully!', 'Saved');
      setIsEditModalOpen(false);
      if (detailProblem && detailProblem.id === editingProblem.id) {
        setDetailProblem(updated);
      }
      fetchProblems();
      triggerRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update problem', 'Error');
    }
  };

  const confirmDelete = async () => {
    if (!deletingId) return;
    try {
      await problemService.deleteProblem(deletingId);
      toast.success('Problem deleted', 'Deleted');
      setIsConfirmDeleteOpen(false);
      setDeletingId(null);
      setIsDetailModalOpen(false);
      fetchProblems();
      triggerRefresh();
    } catch (err: any) {
      toast.error('Failed to delete problem', 'Error');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100 flex items-center gap-2.5">
            <Code2 className="w-6 h-6 text-indigo-500" />
            Coding Problems
          </h1>
          <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
            Manage your algorithm questions, solution links, and key algorithmic concepts
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Add Problem</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <ProblemFilters
        keyword={keyword}
        onKeywordChange={(val) => {
          setKeyword(val);
          setPage(0);
        }}
        status={status}
        onStatusChange={(val) => {
          setStatus(val);
          setPage(0);
        }}
        difficulty={difficulty}
        onDifficultyChange={(val) => {
          setDifficulty(val);
          setPage(0);
        }}
        topic={topic}
        onTopicChange={(val) => {
          setTopic(val);
          setPage(0);
        }}
        platform={platform}
        onPlatformChange={(val) => {
          setPlatform(val);
          setPage(0);
        }}
        sortBy={sortBy}
        onSortByChange={setSortBy}
        sortDirection={sortDirection}
        onSortDirectionToggle={() =>
          setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'))
        }
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        topicsList={topicsList}
        platformsList={platformsList}
      />

      {/* Results Count Banner */}
      <div className="flex items-center justify-between text-xs text-zinc-500 px-1">
        <span>
          Showing <strong>{problems.length}</strong> of <strong>{totalElements}</strong> problems
        </span>
        {totalElements > 0 && (
          <span>
            Page {page + 1} of {totalPages || 1}
          </span>
        )}
      </div>

      {/* Problems Display */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <div className="w-7 h-7 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs text-zinc-400">Loading problems...</p>
        </div>
      ) : problems.length === 0 ? (
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-500 mx-auto flex items-center justify-center">
            <Code2 className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">No problems found</h3>
          <p className="text-xs text-zinc-400 max-w-sm mx-auto">
            {keyword || status !== 'ALL' || difficulty !== 'ALL' || topic !== 'ALL' || platform !== 'ALL'
              ? 'Try changing your search keywords or filter criteria.'
              : 'Start logging your coding practice by adding your first problem.'}
          </p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl transition-all shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Add Problem Now
          </button>
        </div>
      ) : viewMode === 'table' ? (
        /* TABLE VIEW */
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-zinc-50 dark:bg-zinc-800/60 border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="py-3 px-4 w-12 text-center">Status</th>
                  <th className="py-3 px-4">Problem Title</th>
                  <th className="py-3 px-4">Difficulty</th>
                  <th className="py-3 px-4">Topic</th>
                  <th className="py-3 px-4">Platform</th>
                  <th className="py-3 px-4">Time</th>
                  <th className="py-3 px-4">Links</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
                {problems.map((prob) => (
                  <tr
                    key={prob.id}
                    className="hover:bg-zinc-50/80 dark:hover:bg-zinc-800/40 transition-colors group cursor-pointer"
                    onClick={() => {
                      setDetailProblem(prob);
                      setIsDetailModalOpen(true);
                    }}
                  >
                    {/* Status Checkbox */}
                    <td
                      className="py-3 px-4 text-center"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleStatus(prob.id);
                      }}
                    >
                      <button
                        title={prob.status === 'SOLVED' ? 'Mark Unsolved' : 'Mark Solved'}
                        className="p-1 rounded-lg hover:bg-zinc-200 dark:hover:bg-zinc-700 transition-colors"
                      >
                        {prob.status === 'SOLVED' ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border-2 border-zinc-400 group-hover:border-indigo-500" />
                        )}
                      </button>
                    </td>

                    {/* Title */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-zinc-900 dark:text-zinc-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors flex items-center gap-1.5">
                        <span>{prob.title}</span>
                        {prob.notes && (
                          <span title="Has solution notes">
                            <FileText className="w-3 h-3 text-zinc-400" />
                          </span>
                        )}
                      </div>
                      {prob.solvedDate && (
                        <span className="text-[10px] text-zinc-400">
                          Solved: {new Date(prob.solvedDate).toLocaleDateString()}
                        </span>
                      )}
                    </td>

                    {/* Difficulty */}
                    <td className="py-3 px-4">
                      <DifficultyBadge difficulty={prob.difficulty} />
                    </td>

                    {/* Topic */}
                    <td className="py-3 px-4 text-zinc-600 dark:text-zinc-300 font-medium">
                      {prob.topic}
                    </td>

                    {/* Platform */}
                    <td className="py-3 px-4">
                      <PlatformBadge platform={prob.platform} />
                    </td>

                    {/* Time spent */}
                    <td className="py-3 px-4 text-zinc-500 font-mono">
                      {prob.timeSpentMinutes ? `${prob.timeSpentMinutes}m` : '-'}
                    </td>

                    {/* Links */}
                    <td
                      className="py-3 px-4"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex items-center gap-2">
                        {prob.problemUrl && (
                          <a
                            href={prob.problemUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-zinc-400 hover:text-indigo-500 p-1"
                            title="Open Problem Link"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}
                        {prob.solutionUrl && (
                          <a
                            href={prob.solutionUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-zinc-400 hover:text-indigo-500 p-1"
                            title="Open Solution Repo"
                          >
                            <Github className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                    </td>

                    {/* Actions */}
                    <td
                      className="py-3 px-4 text-right"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setEditingProblem(prob);
                            setIsEditModalOpen(true);
                          }}
                          className="p-1.5 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors"
                          title="Edit Problem"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            setDeletingId(prob.id);
                            setIsConfirmDeleteOpen(true);
                          }}
                          className="p-1.5 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                          title="Delete Problem"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* GRID VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {problems.map((prob) => (
            <div
              key={prob.id}
              onClick={() => {
                setDetailProblem(prob);
                setIsDetailModalOpen(true);
              }}
              className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 p-5 rounded-2xl shadow-xs hover:border-indigo-500/50 dark:hover:border-indigo-500/50 transition-all cursor-pointer flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-semibold text-sm text-zinc-900 dark:text-zinc-100 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
                    {prob.title}
                  </h3>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleToggleStatus(prob.id);
                    }}
                    title={prob.status === 'SOLVED' ? 'Mark Unsolved' : 'Mark Solved'}
                    className="shrink-0 p-1"
                  >
                    {prob.status === 'SOLVED' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border-2 border-zinc-400 hover:border-indigo-500" />
                    )}
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
                  <DifficultyBadge difficulty={prob.difficulty} />
                  <PlatformBadge platform={prob.platform} />
                  <span className="text-[11px] px-2 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400">
                    {prob.topic}
                  </span>
                </div>

                {prob.notes && (
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2 mt-3 bg-zinc-50 dark:bg-zinc-800/40 p-2.5 rounded-xl border border-zinc-100 dark:border-zinc-800/80">
                    {prob.notes}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-zinc-100 dark:border-zinc-800/80 text-xs text-zinc-400">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {prob.timeSpentMinutes ? `${prob.timeSpentMinutes} mins` : 'No time logged'}
                </span>

                <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => {
                      setEditingProblem(prob);
                      setIsEditModalOpen(true);
                    }}
                    className="p-1 hover:text-zinc-700 dark:hover:text-zinc-200"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      setDeletingId(prob.id);
                      setIsConfirmDeleteOpen(true);
                    }}
                    className="p-1 hover:text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <button
            disabled={page === 0}
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-medium bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors shadow-xs"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Previous
          </button>

          <span className="text-xs text-zinc-500 font-mono">
            Page {page + 1} of {totalPages}
          </span>

          <button
            disabled={page >= totalPages - 1}
            onClick={() => setPage((p) => p + 1)}
            className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-medium bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors shadow-xs"
          >
            Next
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Modals */}
      <ProblemFormModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSubmit={handleCreateProblem}
      />

      <ProblemFormModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSubmit={handleEditProblem}
        initialData={editingProblem}
      />

      <ProblemDetailModal
        problem={detailProblem}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        onEdit={(p) => {
          setEditingProblem(p);
          setIsEditModalOpen(true);
        }}
        onDelete={(id) => {
          setDeletingId(id);
          setIsConfirmDeleteOpen(true);
        }}
        onToggleStatus={handleToggleStatus}
      />

      <ConfirmDialog
        isOpen={isConfirmDeleteOpen}
        onClose={() => setIsConfirmDeleteOpen(false)}
        onConfirm={confirmDelete}
        title="Delete Coding Problem"
        message="Are you sure you want to remove this problem from your tracker? This action cannot be undone."
        confirmLabel="Delete Problem"
        isDestructive={true}
      />
    </div>
  );
};
