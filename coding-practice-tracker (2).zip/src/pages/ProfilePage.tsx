import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { authService } from '../services/authService';
import { useToast } from '../context/ToastContext';
import {
  User as UserIcon,
  Mail,
  Target,
  Clock,
  Calendar,
  Save,
  Shield,
  Sparkles,
} from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const { user, updateUser } = useAuth();
  const toast = useToast();

  const [fullName, setFullName] = useState(user?.fullName || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [targetDailyProblems, setTargetDailyProblems] = useState(user?.targetDailyProblems || 3);
  const [targetWeeklyHours, setTargetWeeklyHours] = useState(user?.targetWeeklyHours || 10);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const updated = await authService.updateProfile({
        fullName: fullName.trim() || undefined,
        bio: bio.trim() || undefined,
        targetDailyProblems: Number(targetDailyProblems) || 3,
        targetWeeklyHours: Number(targetWeeklyHours) || 10,
      });
      updateUser(updated);
      toast.success('Profile and practice goals saved!', 'Profile Updated');
    } catch (err: any) {
      toast.error(err.message || 'Failed to update profile', 'Error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100 flex items-center gap-2.5">
          <UserIcon className="w-6 h-6 text-indigo-500" />
          Profile & Practice Goals
        </h1>
        <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
          Customize your practice targets, developer bio, and personal account information
        </p>
      </div>

      {/* Profile Card Header */}
      <div className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex flex-col sm:flex-row items-center sm:items-start gap-5">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white text-3xl font-bold shadow-md shadow-indigo-500/20 shrink-0">
          {user?.fullName?.charAt(0) || user?.username?.charAt(0) || 'U'}
        </div>

        <div className="flex-1 text-center sm:text-left space-y-1">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <h2 className="text-lg font-bold text-zinc-900 dark:text-zinc-100">
              {user?.fullName || user?.username}
            </h2>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 w-fit mx-auto sm:mx-0">
              <Shield className="w-3 h-3" />
              {user?.role || 'ROLE_USER'}
            </span>
          </div>

          <p className="text-xs text-zinc-500 dark:text-zinc-400 font-mono">@{user?.username}</p>

          <p className="text-xs text-zinc-600 dark:text-zinc-300 pt-1 leading-relaxed">
            {user?.bio || 'Full-stack & algorithm enthusiast preparing for tech interviews.'}
          </p>

          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 pt-2 text-xs text-zinc-400">
            <span className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" />
              {user?.email}
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              Joined {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'Recently'}
            </span>
          </div>
        </div>
      </div>

      {/* Edit Form Card */}
      <div className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
        <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100 mb-4 pb-3 border-b border-zinc-100 dark:border-zinc-800">
          Edit Practice Goals & Bio
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
                Full Name
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Alex Chen"
                className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
                Username (Read-Only)
              </label>
              <input
                type="text"
                disabled
                value={user?.username || ''}
                className="w-full px-3.5 py-2.5 bg-zinc-100 dark:bg-zinc-800/40 border border-zinc-200 dark:border-zinc-800 rounded-xl text-sm text-zinc-400 cursor-not-allowed"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Bio & Interview Focus
            </label>
            <textarea
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="e.g. Preparing for Senior Software Engineer algorithms and distributed system design..."
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            />
          </div>

          {/* Goal Targets */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 space-y-2">
              <label className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">
                <Target className="w-4 h-4 text-indigo-500" />
                Target Daily Problems
              </label>
              <input
                type="number"
                min="1"
                max="50"
                value={targetDailyProblems}
                onChange={(e) => setTargetDailyProblems(Number(e.target.value))}
                className="w-full px-3.5 py-2 bg-white dark:bg-zinc-900 border border-indigo-200 dark:border-indigo-800 rounded-xl text-sm font-semibold focus:outline-none"
              />
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                Recommended: 2–5 problems per day to stay consistent without burnout.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-purple-50/50 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-900/50 space-y-2">
              <label className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-purple-700 dark:text-purple-300">
                <Clock className="w-4 h-4 text-purple-500" />
                Target Weekly Hours
              </label>
              <input
                type="number"
                min="1"
                max="100"
                step="0.5"
                value={targetWeeklyHours}
                onChange={(e) => setTargetWeeklyHours(Number(e.target.value))}
                className="w-full px-3.5 py-2 bg-white dark:bg-zinc-900 border border-purple-200 dark:border-purple-800 rounded-xl text-sm font-semibold focus:outline-none"
              />
              <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                Tracked against all practice sessions logged during the current week.
              </p>
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-zinc-100 dark:border-zinc-800">
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-sm transition-all"
            >
              {isSubmitting ? (
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              Save Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
