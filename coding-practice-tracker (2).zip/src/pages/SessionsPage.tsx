import React, { useEffect, useState } from 'react';
import { sessionService } from '../services/sessionService';
import { PracticeSession } from '../types';
import { SessionFormModal } from '../components/sessions/SessionFormModal';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { useToast } from '../context/ToastContext';
import { useOutletContext } from 'react-router-dom';
import {
  CalendarCheck,
  Plus,
  Clock,
  CheckCircle2,
  Calendar,
  Edit2,
  Trash2,
  BookOpen,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

export const SessionsPage: React.FC = () => {
  const toast = useToast();
  const { refreshKey, triggerRefresh } = useOutletContext<{
    refreshKey: number;
    triggerRefresh: () => void;
  }>();

  const [sessions, setSessions] = useState<PracticeSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [pageSize] = useState(10);
  const [totalPages, setTotalPages] = useState(1);
  const [totalElements, setTotalElements] = useState(0);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingSession, setEditingSession] = useState<PracticeSession | null>(null);
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const fetchSessions = async () => {
    try {
      setLoading(true);
      const res = await sessionService.getSessionsPaginated(page, pageSize);
      setSessions(res.content);
      setTotalPages(res.totalPages);
      setTotalElements(res.totalElements);
    } catch (err: any) {
      console.error(err);
      toast.error('Failed to load sessions', 'Error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
  }, [page, refreshKey]);

  const handleCreateSession = async (formData: any) => {
    try {
      await sessionService.createSession(formData);
      toast.success('Practice session recorded!', 'Session Logged');
      setIsAddModalOpen(false);
      fetchSessions();
      triggerRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to log session', 'Error');
    }
  };

  const handleEditSession = async (formData: any) => {
    if (!editingSession) return;
    try {
      await sessionService.updateSession(editingSession.id, formData);
      toast.success('Session updated successfully!', 'Saved');
      setIsEditModalOpen(false);
      fetchSessions();
      triggerRefresh();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update session', 'Error');
    }
  };

  const confirmDelete = async () => {
    if (!deletingId) return;
    try {
      await sessionService.deleteSession(deletingId);
      toast.success('Practice session removed', 'Deleted');
      setIsConfirmDeleteOpen(false);
      setDeletingId(null);
      fetchSessions();
      triggerRefresh();
    } catch (err: any) {
      toast.error('Failed to delete session', 'Error');
    }
  };

  const totalMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const totalSolvedInSessions = sessions.reduce((acc, s) => acc + s.problemsSolvedCount, 0);
  const avgDuration = sessions.length > 0 ? Math.round(totalMinutes / sessions.length) : 0;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100 flex items-center gap-2.5">
            <CalendarCheck className="w-6 h-6 text-indigo-500" />
            Practice Sessions
          </h1>
          <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
            Log time blocks, track algorithmic topics studied, and review session takeaways
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Log Session</span>
        </button>
      </div>

      {/* 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Total Logged Sessions
            </span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <CalendarCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-100 font-mono">
              {totalElements}
            </span>
            <span className="text-xs text-zinc-400">Sessions</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Session Practice Time
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
              {Math.round((totalMinutes / 60) * 10) / 10}
            </span>
            <span className="text-xs text-zinc-400 font-mono">Hours ({totalMinutes}m)</span>
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
              Avg Session Length
            </span>
            <div className="w-8 h-8 rounded-xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-purple-600 dark:text-purple-400 font-mono">
              {avgDuration}
            </span>
            <span className="text-xs text-zinc-400">Minutes</span>
          </div>
        </div>
      </div>

      {/* Sessions List Table */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <div className="w-7 h-7 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs text-zinc-400">Loading sessions...</p>
        </div>
      ) : sessions.length === 0 ? (
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-500 mx-auto flex items-center justify-center">
            <CalendarCheck className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-zinc-900 dark:text-zinc-100">No practice sessions logged yet</h3>
          <p className="text-xs text-zinc-400 max-w-sm mx-auto">
            Log your study blocks to record your daily focus, time spent, and problem solve count.
          </p>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl transition-all shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Log First Session
          </button>
        </div>
      ) : (
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-zinc-50 dark:bg-zinc-800/60 border-b border-zinc-200 dark:border-zinc-800 text-zinc-500 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Duration</th>
                  <th className="py-3 px-4">Solved</th>
                  <th className="py-3 px-4">Topic Focus</th>
                  <th className="py-3 px-4">Notes & Takeaways</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800/80">
                {sessions.map((sess) => (
                  <tr
                    key={sess.id}
                    className="hover:bg-zinc-50/80 dark:hover:bg-zinc-800/40 transition-colors"
                  >
                    <td className="py-3.5 px-4 font-semibold text-zinc-800 dark:text-zinc-200">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-zinc-400" />
                        <span>
                          {new Date(sess.sessionDate).toLocaleDateString(undefined, {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-mono font-medium text-zinc-700 dark:text-zinc-300">
                      <span className="px-2 py-0.5 rounded bg-zinc-100 dark:bg-zinc-800">
                        {sess.durationMinutes} mins ({(sess.durationMinutes / 60).toFixed(1)}h)
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold font-mono">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {sess.problemsSolvedCount} solved
                      </span>
                    </td>

                    <td className="py-3.5 px-4 font-medium text-zinc-800 dark:text-zinc-200">
                      {sess.topicFocus || 'General Practice'}
                    </td>

                    <td className="py-3.5 px-4 text-zinc-500 dark:text-zinc-400 max-w-xs truncate">
                      {sess.notes || '-'}
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => {
                            setEditingSession(sess);
                            setIsEditModalOpen(true);
                          }}
                          className="p-1.5 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors"
                          title="Edit Session"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            setDeletingId(sess.id);
                            setIsConfirmDeleteOpen(true);
                          }}
                          className="p-1.5 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors"
                          title="Delete Session"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <button
            disabled={page === 0}
            onClick={() => setPage((p) => Math.max(0, p - 1))}
            className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-medium bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors shadow-xs"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            Previous
          </button>

          <span className="text-xs text-zinc-500 font-mono">
            Page {page + 1} of {totalPages}
          </span>

          <button
            disabled={page >= totalPages - 1}
            onClick={() => setPage((p) => p + 1)}
            className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl text-xs font-medium bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-colors shadow-xs"
          >
            Next
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Modals */}
      <SessionFormModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSubmit={handleCreateSession}
      />

      <SessionFormModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSubmit={handleEditSession}
        initialData={editingSession}
      />

      <ConfirmDialog
        isOpen={isConfirmDeleteOpen}
        onClose={() => setIsConfirmDeleteOpen(false)}
        onConfirm={confirmDelete}
        title="Delete Practice Session"
        message="Are you sure you want to delete this logged practice session? Your streak and stats will be updated accordingly."
        confirmLabel="Delete Session"
        isDestructive={true}
      />
    </div>
  );
};
