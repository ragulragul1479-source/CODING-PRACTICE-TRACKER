import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useToast } from '../context/ToastContext';
import { authService } from '../services/authService';
import { problemService } from '../services/problemService';
import { sessionService } from '../services/sessionService';
import { resetLocalData, apiClient } from '../services/api';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import {
  Settings,
  Lock,
  Sun,
  Moon,
  Download,
  RotateCcw,
  Server,
  CheckCircle2,
  AlertCircle,
  Save,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { user } = useAuth();
  const { theme, setTheme } = useTheme();
  const toast = useToast();

  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPass, setIsChangingPass] = useState(false);

  // Backend Health check
  const [serverHealth, setServerHealth] = useState<'checking' | 'connected' | 'standalone'>('checking');

  // Confirmation dialogs
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);

  useEffect(() => {
    const checkBackend = async () => {
      try {
        const res = await apiClient.get('/health', { timeout: 3000 });
        if (res.data?.status === 'UP' || res.status === 200) {
          setServerHealth('connected');
        } else {
          setServerHealth('standalone');
        }
      } catch {
        setServerHealth('standalone');
      }
    };
    checkBackend();
  }, []);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match', 'Password Error');
      return;
    }
    if (newPassword.length < 6) {
      toast.error('New password must be at least 6 characters', 'Password Error');
      return;
    }

    setIsChangingPass(true);
    try {
      await authService.changePassword({ currentPassword, newPassword });
      toast.success('Your password was updated successfully!', 'Security Updated');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      toast.error(err.message || 'Failed to update password', 'Error');
    } finally {
      setIsChangingPass(false);
    }
  };

  const handleExportJSON = async () => {
    try {
      const pRes = await problemService.getProblems({ size: 1000 });
      const sRes = await sessionService.getAllSessions();
      const exportData = {
        exportedAt: new Date().toISOString(),
        user: {
          username: user?.username,
          email: user?.email,
          fullName: user?.fullName,
        },
        problems: pRes.content,
        sessions: sRes,
      };

      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `coding-tracker-export-${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('JSON export downloaded successfully!', 'Export Complete');
    } catch (err) {
      toast.error('Failed to export data', 'Error');
    }
  };

  const handleExportCSV = async () => {
    try {
      const pRes = await problemService.getProblems({ size: 1000 });
      const headers = [
        'ID',
        'Title',
        'Difficulty',
        'Topic',
        'Platform',
        'Status',
        'Solved Date',
        'Time Spent (mins)',
        'Problem URL',
        'Solution URL',
      ];
      const rows = pRes.content.map((p) => [
        p.id,
        `"${(p.title || '').replace(/"/g, '""')}"`,
        p.difficulty,
        `"${p.topic}"`,
        `"${p.platform}"`,
        p.status,
        p.solvedDate || '',
        p.timeSpentMinutes || 0,
        p.problemUrl || '',
        p.solutionUrl || '',
      ]);

      const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `coding-problems-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('CSV export downloaded successfully!', 'Export Complete');
    } catch (err) {
      toast.error('Failed to export CSV', 'Error');
    }
  };

  const handleResetData = () => {
    resetLocalData();
    toast.success('Demo data restored to default pristine state!', 'Reset Complete');
    setIsResetConfirmOpen(false);
    setTimeout(() => {
      window.location.reload();
    }, 500);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-100 flex items-center gap-2.5">
          <Settings className="w-6 h-6 text-indigo-500" />
          Application Settings
        </h1>
        <p className="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 mt-1">
          Manage system preferences, security credentials, data backup, and server connectivity
        </p>
      </div>

      {/* Backend Health Status Banner */}
      <div className="bg-white dark:bg-zinc-900 p-5 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-500 flex items-center justify-center">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">
              System Architecture Status
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
              Java 21 + Spring Boot 3 REST API & in-memory synchronized storage engine
            </p>
          </div>
        </div>

        <span
          className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${
            serverHealth === 'connected'
              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
              : 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          {serverHealth === 'connected' ? 'Spring Boot 3 API Connected' : 'High-Performance Engine Active'}
        </span>
      </div>

      {/* Appearance & Theme Setting */}
      <div className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100 pb-3 border-b border-zinc-100 dark:border-zinc-800">
          Appearance & Theme
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            type="button"
            onClick={() => setTheme('dark')}
            className={`p-4 rounded-xl border text-left flex items-start gap-3.5 transition-all ${
              theme === 'dark'
                ? 'bg-zinc-800/80 border-indigo-500 ring-2 ring-indigo-500/20'
                : 'bg-zinc-50 dark:bg-zinc-800/30 border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <div className="p-2 rounded-lg bg-zinc-900 text-amber-400">
              <Moon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">Dark Mode (Default)</p>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                Eye-friendly high-contrast dark aesthetic tailored for coding sessions
              </p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setTheme('light')}
            className={`p-4 rounded-xl border text-left flex items-start gap-3.5 transition-all ${
              theme === 'light'
                ? 'bg-indigo-50/60 border-indigo-500 ring-2 ring-indigo-500/20'
                : 'bg-zinc-50 dark:bg-zinc-800/30 border-zinc-200 dark:border-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-800'
            }`}
          >
            <div className="p-2 rounded-lg bg-white border border-zinc-200 text-amber-500">
              <Sun className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">Light Mode</p>
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
                Crisp and clean high-legibility light theme
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* Security & Password Form */}
      <div className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100 pb-3 border-b border-zinc-100 dark:border-zinc-800 flex items-center gap-2">
          <Lock className="w-4 h-4 text-indigo-500" />
          Security & Password
        </h3>

        <form onSubmit={handleChangePassword} className="space-y-4 max-w-lg">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
              Current Password
            </label>
            <input
              type="password"
              required
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
                New Password
              </label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-zinc-700 dark:text-zinc-300 mb-1.5">
                Confirm New Password
              </label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3.5 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isChangingPass}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-xs rounded-xl shadow-sm transition-all"
          >
            {isChangingPass && <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
            Update Password
          </button>
        </form>
      </div>

      {/* Data Management & Export */}
      <div className="bg-white dark:bg-zinc-900 p-6 rounded-2xl border border-zinc-200 dark:border-zinc-800 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-zinc-900 dark:text-zinc-100 pb-3 border-b border-zinc-100 dark:border-zinc-800">
          Data Management & Export
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-800 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300">
              Export Backup (JSON)
            </h4>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Download your full coding practice logs, sessions, notes, and targets in JSON format.
            </p>
            <button
              onClick={handleExportJSON}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-zinc-800 dark:text-zinc-200 bg-white dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 border border-zinc-200 dark:border-zinc-700 rounded-xl transition-all shadow-xs"
            >
              <Download className="w-3.5 h-3.5 text-indigo-500" />
              Download JSON
            </button>
          </div>

          <div className="p-4 rounded-xl bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/60 dark:border-zinc-800 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-700 dark:text-zinc-300">
              Export Spreadsheet (CSV)
            </h4>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Download a clean CSV spreadsheet with all problem titles, difficulties, platforms, and URLs.
            </p>
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-zinc-800 dark:text-zinc-200 bg-white dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 border border-zinc-200 dark:border-zinc-700 rounded-xl transition-all shadow-xs"
            >
              <Download className="w-3.5 h-3.5 text-emerald-500" />
              Download CSV
            </button>
          </div>
        </div>

        {/* Reset Demo Data */}
        <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">
              Reset Demo Data
            </h4>
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              Restore initial seed problems, practice sessions, and 7-day streak records.
            </p>
          </div>

          <button
            onClick={() => setIsResetConfirmOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-900 rounded-xl transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset to Default
          </button>
        </div>
      </div>

      <ConfirmDialog
        isOpen={isResetConfirmOpen}
        onClose={() => setIsResetConfirmOpen(false)}
        onConfirm={handleResetData}
        title="Reset Demo Data"
        message="This will re-initialize your coding problems and sessions with the sample dataset. Continue?"
        confirmLabel="Reset Data"
        isDestructive={true}
      />
    </div>
  );
};
