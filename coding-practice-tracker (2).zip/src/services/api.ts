import axios from 'axios';
import {
  ApiResponse,
  AuthResponse,
  CodingProblem,
  Difficulty,
  PageResponse,
  PracticeSession,
  ProblemStatus,
  User,
  DashboardData,
  AnalyticsData,
  StreakData,
} from '../types';
import { INITIAL_PROBLEMS, INITIAL_SESSIONS, INITIAL_USER } from './mockData';

// API Base URL (defaults to /api)
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Interceptor to attach JWT token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('cpt_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Safe JSON Parse helper to prevent "undefined is not valid JSON" errors
function safeJsonParse<T>(data: string | null, fallback: T): T {
  if (!data || data === 'undefined' || data === 'null' || typeof data !== 'string' || data.trim() === '') {
    return fallback;
  }
  try {
    const parsed = JSON.parse(data);
    return parsed !== undefined && parsed !== null ? parsed : fallback;
  } catch (err) {
    console.warn('safeJsonParse caught corrupted or invalid JSON in storage:', err);
    return fallback;
  }
}

// In-Browser State Storage (Fallback / Standalone Mode)
const STORAGE_KEYS = {
  TOKEN: 'cpt_token',
  USER: 'cpt_user',
  PROBLEMS: 'cpt_problems',
  SESSIONS: 'cpt_sessions',
};

// Initialize Storage with mock data if empty or corrupted
export const initLocalData = () => {
  const pData = localStorage.getItem(STORAGE_KEYS.PROBLEMS);
  if (!pData || pData === 'undefined' || pData === 'null') {
    localStorage.setItem(STORAGE_KEYS.PROBLEMS, JSON.stringify(INITIAL_PROBLEMS));
  }
  const sData = localStorage.getItem(STORAGE_KEYS.SESSIONS);
  if (!sData || sData === 'undefined' || sData === 'null') {
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(INITIAL_SESSIONS));
  }
  const uData = localStorage.getItem(STORAGE_KEYS.USER);
  if (!uData || uData === 'undefined' || uData === 'null') {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(INITIAL_USER));
  }
};

export const resetLocalData = () => {
  localStorage.setItem(STORAGE_KEYS.PROBLEMS, JSON.stringify(INITIAL_PROBLEMS));
  localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(INITIAL_SESSIONS));
  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(INITIAL_USER));
};

export const getStoredUser = (): User | null => {
  const data = localStorage.getItem(STORAGE_KEYS.USER);
  return safeJsonParse<User | null>(data, null);
};

export const setStoredUser = (user: User | null | undefined) => {
  if (!user) {
    localStorage.removeItem(STORAGE_KEYS.USER);
  } else {
    try {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    } catch (e) {
      console.error('Failed to setStoredUser:', e);
    }
  }
};

export const getStoredProblems = (): CodingProblem[] => {
  const data = localStorage.getItem(STORAGE_KEYS.PROBLEMS);
  const parsed = safeJsonParse<CodingProblem[]>(data, INITIAL_PROBLEMS);
  return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_PROBLEMS;
};

export const saveStoredProblems = (problems: CodingProblem[]) => {
  if (Array.isArray(problems)) {
    localStorage.setItem(STORAGE_KEYS.PROBLEMS, JSON.stringify(problems));
  }
};

export const getStoredSessions = (): PracticeSession[] => {
  const data = localStorage.getItem(STORAGE_KEYS.SESSIONS);
  const parsed = safeJsonParse<PracticeSession[]>(data, INITIAL_SESSIONS);
  return Array.isArray(parsed) ? parsed : INITIAL_SESSIONS;
};

export const saveStoredSessions = (sessions: PracticeSession[]) => {
  if (Array.isArray(sessions)) {
    localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(sessions));
  }
};

// Helper to compute streak in frontend storage
export const computeStreakData = (
  problems: CodingProblem[],
  sessions: PracticeSession[]
): StreakData => {
  const activeDatesSet = new Set<string>();

  problems.forEach((p) => {
    if (p.status === 'SOLVED' && p.solvedDate) {
      activeDatesSet.add(p.solvedDate);
    }
  });

  sessions.forEach((s) => {
    if (s.sessionDate) {
      activeDatesSet.add(s.sessionDate);
    }
  });

  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  const activeToday = activeDatesSet.has(today);

  let currentStreak = 0;
  let checkDate = new Date(activeToday ? today : yesterday);

  while (true) {
    const dateStr = checkDate.toISOString().split('T')[0];
    if (activeDatesSet.has(dateStr)) {
      currentStreak++;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      break;
    }
  }

  // Calculate longest streak
  const sortedDates = Array.from(activeDatesSet).sort();
  let longestStreak = 0;
  let tempStreak = 0;
  let prevDateObj: Date | null = null;

  sortedDates.forEach((dStr) => {
    const curDate = new Date(dStr);
    if (!prevDateObj) {
      tempStreak = 1;
    } else {
      const diffDays = Math.round((curDate.getTime() - prevDateObj.getTime()) / 86400000);
      if (diffDays === 1) {
        tempStreak++;
      } else if (diffDays > 1) {
        tempStreak = 1;
      }
    }
    if (tempStreak > longestStreak) {
      longestStreak = tempStreak;
    }
    prevDateObj = curDate;
  });

  // Build heatmap history for past 90 days
  const activityHistory = [];
  for (let i = 89; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];

    const dayProblems = problems.filter((p) => p.status === 'SOLVED' && p.solvedDate === dateStr).length;
    const daySessions = sessions.filter((s) => s.sessionDate === dateStr);
    const dayMinutes = daySessions.reduce((acc, s) => acc + s.durationMinutes, 0);
    const sessionSolved = daySessions.reduce((acc, s) => acc + s.problemsSolvedCount, 0);
    const totalSolved = dayProblems + sessionSolved;

    const totalEffort = totalSolved + Math.floor(dayMinutes / 30);
    let level = 0;
    if (totalEffort >= 4 || dayMinutes >= 120 || totalSolved >= 4) level = 4;
    else if (totalEffort >= 3 || dayMinutes >= 90 || totalSolved >= 3) level = 3;
    else if (totalEffort >= 2 || dayMinutes >= 45 || totalSolved >= 2) level = 2;
    else if (totalEffort >= 1 || dayMinutes > 0 || totalSolved >= 1) level = 1;

    activityHistory.push({
      date: dateStr,
      problemsSolved: totalSolved,
      minutesPracticed: dayMinutes,
      count: totalEffort,
      level,
    });
  }

  return {
    currentStreak,
    longestStreak,
    activeToday,
    lastActiveDate: sortedDates.length > 0 ? sortedDates[sortedDates.length - 1] : null,
    totalActiveDays: activeDatesSet.size,
    activeDates: Array.from(activeDatesSet),
    activityHistory,
  };
};

export const computeDashboardData = (user: User): DashboardData => {
  const problems = getStoredProblems();
  const sessions = getStoredSessions();

  const totalProblems = problems.length;
  const solvedProblems = problems.filter((p) => p.status === 'SOLVED').length;
  const unsolvedProblems = totalProblems - solvedProblems;
  const completionRate = totalProblems > 0 ? Math.round((solvedProblems / totalProblems) * 1000) / 10 : 0;

  const totalMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const totalPracticeHours = Math.round((totalMinutes / 60) * 10) / 10;

  const easySolved = problems.filter((p) => p.difficulty === 'EASY' && p.status === 'SOLVED').length;
  const easyTotal = problems.filter((p) => p.difficulty === 'EASY').length;
  const mediumSolved = problems.filter((p) => p.difficulty === 'MEDIUM' && p.status === 'SOLVED').length;
  const mediumTotal = problems.filter((p) => p.difficulty === 'MEDIUM').length;
  const hardSolved = problems.filter((p) => p.difficulty === 'HARD' && p.status === 'SOLVED').length;
  const hardTotal = problems.filter((p) => p.difficulty === 'HARD').length;

  const streakInfo = computeStreakData(problems, sessions);

  // Weekly & Monthly calculations
  const now = new Date();
  const dayOfWeek = (now.getDay() + 6) % 7; // Monday = 0
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - dayOfWeek);
  startOfWeek.setHours(0, 0, 0, 0);

  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const weekSessions = sessions.filter((s) => new Date(s.sessionDate) >= startOfWeek);
  const monthSessions = sessions.filter((s) => new Date(s.sessionDate) >= startOfMonth);

  const weekMinutes = weekSessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const monthMinutes = monthSessions.reduce((acc, s) => acc + s.durationMinutes, 0);

  const weekHours = Math.round((weekMinutes / 60) * 10) / 10;
  const monthHours = Math.round((monthMinutes / 60) * 10) / 10;

  const solvedThisWeek = problems.filter(
    (p) => p.status === 'SOLVED' && p.solvedDate && new Date(p.solvedDate) >= startOfWeek
  ).length;

  const solvedThisMonth = problems.filter(
    (p) => p.status === 'SOLVED' && p.solvedDate && new Date(p.solvedDate) >= startOfMonth
  ).length;

  const targetHours = user.targetWeeklyHours || 10;
  const weeklyGoalPercentage = Math.min(100, Math.round((weekHours / targetHours) * 1000) / 10);

  // Recent Activity
  const activities: any[] = [];
  problems.slice(0, 5).forEach((p) => {
    activities.push({
      id: `p-${p.id}`,
      type: p.status === 'SOLVED' ? 'PROBLEM_SOLVED' : 'PROBLEM_ADDED',
      title: p.title,
      subtitle: `${p.platform} • ${p.topic}`,
      difficultyOrTopic: p.difficulty,
      timestamp: p.updatedAt || p.createdAt,
    });
  });

  sessions.slice(0, 5).forEach((s) => {
    activities.push({
      id: `s-${s.id}`,
      type: 'PRACTICE_SESSION',
      title: `Practice Session: ${s.topicFocus || 'General Practice'}`,
      subtitle: `${s.durationMinutes} mins • ${s.problemsSolvedCount} solved`,
      difficultyOrTopic: s.sessionDate,
      timestamp: s.createdAt,
    });
  });

  activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return {
    totalProblems,
    totalSolvedProblems: solvedProblems,
    totalUnsolvedProblems: unsolvedProblems,
    completionRate,
    totalPracticeHours,
    currentStreak: streakInfo.currentStreak,
    longestStreak: streakInfo.longestStreak,
    practicedToday: streakInfo.activeToday,
    difficultyStats: {
      easySolved,
      easyTotal,
      mediumSolved,
      mediumTotal,
      hardSolved,
      hardTotal,
    },
    progress: {
      problemsSolvedThisWeek: solvedThisWeek,
      problemsSolvedThisMonth: solvedThisMonth,
      hoursSpentThisWeek: weekHours,
      hoursSpentThisMonth: monthHours,
      targetDailyProblems: user.targetDailyProblems || 3,
      targetWeeklyHours: targetHours,
      weeklyGoalPercentage,
    },
    recentActivities: activities.slice(0, 8),
    activityHeatmap: streakInfo.activityHistory,
  };
};

export const computeAnalyticsData = (): AnalyticsData => {
  const problems = getStoredProblems();
  const sessions = getStoredSessions();

  const totalProblems = problems.length;
  const totalSolved = problems.filter((p) => p.status === 'SOLVED').length;
  const totalMinutes = sessions.reduce((acc, s) => acc + s.durationMinutes, 0);
  const totalHours = Math.round((totalMinutes / 60) * 10) / 10;

  const easySolved = problems.filter((p) => p.difficulty === 'EASY' && p.status === 'SOLVED').length;
  const easyTotal = problems.filter((p) => p.difficulty === 'EASY').length;
  const mediumSolved = problems.filter((p) => p.difficulty === 'MEDIUM' && p.status === 'SOLVED').length;
  const mediumTotal = problems.filter((p) => p.difficulty === 'MEDIUM').length;
  const hardSolved = problems.filter((p) => p.difficulty === 'HARD' && p.status === 'SOLVED').length;
  const hardTotal = problems.filter((p) => p.difficulty === 'HARD').length;

  // Topics
  const topicMap: Record<string, { total: number; solved: number }> = {};
  problems.forEach((p) => {
    if (!topicMap[p.topic]) {
      topicMap[p.topic] = { total: 0, solved: 0 };
    }
    topicMap[p.topic].total++;
    if (p.status === 'SOLVED') {
      topicMap[p.topic].solved++;
    }
  });

  const topicStats = Object.keys(topicMap)
    .map((topic) => ({
      topic,
      total: topicMap[topic].total,
      solved: topicMap[topic].solved,
      percentage: Math.round((topicMap[topic].solved / topicMap[topic].total) * 1000) / 10,
    }))
    .sort((a, b) => b.total - a.total);

  // Platforms
  const platformMap: Record<string, number> = {};
  problems.forEach((p) => {
    platformMap[p.platform] = (platformMap[p.platform] || 0) + 1;
  });

  const platformStats = Object.keys(platformMap)
    .map((platform) => ({
      platform,
      count: platformMap[platform],
      percentage: totalProblems > 0 ? Math.round((platformMap[platform] / totalProblems) * 1000) / 10 : 0,
    }))
    .sort((a, b) => b.count - a.count);

  const streakInfo = computeStreakData(problems, sessions);

  // Monthly stats
  const monthlyStats = [];
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const now = new Date();

  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const y = d.getFullYear();
    const m = d.getMonth();
    const label = `${monthNames[m]} ${y}`;

    const monthProblems = problems.filter((p) => {
      if (p.status !== 'SOLVED' || !p.solvedDate) return false;
      const pd = new Date(p.solvedDate);
      return pd.getFullYear() === y && pd.getMonth() === m;
    });

    const monthSessions = sessions.filter((s) => {
      const sd = new Date(s.sessionDate);
      return sd.getFullYear() === y && sd.getMonth() === m;
    });

    const mMinutes = monthSessions.reduce((acc, s) => acc + s.durationMinutes, 0);

    const activeDaysSet = new Set<string>();
    monthProblems.forEach((p) => p.solvedDate && activeDaysSet.add(p.solvedDate));
    monthSessions.forEach((s) => activeDaysSet.add(s.sessionDate));

    monthlyStats.push({
      month: label,
      problemsSolved: monthProblems.length,
      hoursPracticed: Math.round((mMinutes / 60) * 10) / 10,
      activeDays: activeDaysSet.size,
    });
  }

  // Day of week
  const dayOfWeekMap: Record<string, number> = {
    Mon: 0,
    Tue: 0,
    Wed: 0,
    Thu: 0,
    Fri: 0,
    Sat: 0,
    Sun: 0,
  };
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  sessions.forEach((s) => {
    const day = dayNames[new Date(s.sessionDate).getDay()];
    if (day) dayOfWeekMap[day] = (dayOfWeekMap[day] || 0) + 1;
  });

  problems.forEach((p) => {
    if (p.status === 'SOLVED' && p.solvedDate) {
      const day = dayNames[new Date(p.solvedDate).getDay()];
      if (day) dayOfWeekMap[day] = (dayOfWeekMap[day] || 0) + 1;
    }
  });

  return {
    totalProblems,
    totalSolved,
    totalHours,
    difficultyStats: {
      easySolved,
      easyTotal,
      mediumSolved,
      mediumTotal,
      hardSolved,
      hardTotal,
    },
    topicStats,
    platformStats,
    solvedOverTime: streakInfo.activityHistory,
    monthlyStats,
    dayOfWeekDistribution: dayOfWeekMap,
  };
};
