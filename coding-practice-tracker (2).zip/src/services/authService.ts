import {
  apiClient,
  getStoredUser,
  setStoredUser,
  initLocalData,
} from './api';
import { AuthResponse, User } from '../types';

export const authService = {
  async register(data: { username: string; email: string; password: string; fullName?: string }): Promise<AuthResponse> {
    try {
      const response = await apiClient.post('/auth/register', data);
      const authData: AuthResponse = response.data?.data || response.data;
      if (!authData || !authData.token || !authData.user) {
        throw new Error('Invalid registration response');
      }
      localStorage.setItem('cpt_token', authData.token);
      setStoredUser(authData.user);
      return authData;
    } catch (error) {
      // Standalone fallback
      initLocalData();
      const newUser: User = {
        id: Date.now(),
        username: data.username,
        email: data.email,
        fullName: data.fullName || data.username,
        bio: 'Coding Practice enthusiast.',
        targetDailyProblems: 3,
        targetWeeklyHours: 10.0,
        role: 'ROLE_USER',
        createdAt: new Date().toISOString(),
      };
      const token = `mock-jwt-token-${Date.now()}`;
      localStorage.setItem('cpt_token', token);
      setStoredUser(newUser);
      return {
        token,
        tokenType: 'Bearer',
        expiresIn: 86400000,
        user: newUser,
      };
    }
  },

  async login(data: { usernameOrEmail: string; password: string }): Promise<AuthResponse> {
    try {
      const response = await apiClient.post('/auth/login', data);
      const authData: AuthResponse = response.data?.data || response.data;
      if (!authData || !authData.token || !authData.user) {
        throw new Error('Invalid login response');
      }
      localStorage.setItem('cpt_token', authData.token);
      setStoredUser(authData.user);
      return authData;
    } catch (error) {
      // Standalone fallback
      initLocalData();
      let user = getStoredUser();
      if (!user) {
        user = {
          id: 1,
          username: data.usernameOrEmail || 'demouser',
          email: 'demo@codingtracker.dev',
          fullName: 'Alex Chen',
          bio: 'Software Engineer practicing algorithms daily.',
          targetDailyProblems: 3,
          targetWeeklyHours: 12.0,
          role: 'ROLE_USER',
          createdAt: new Date().toISOString(),
        };
        setStoredUser(user);
      }
      const token = `mock-jwt-token-${Date.now()}`;
      localStorage.setItem('cpt_token', token);
      return {
        token,
        tokenType: 'Bearer',
        expiresIn: 86400000,
        user,
      };
    }
  },

  async logout(): Promise<void> {
    try {
      await apiClient.post('/auth/logout');
    } catch (err) {
      // ignore
    } finally {
      localStorage.removeItem('cpt_token');
    }
  },

  async getCurrentUser(): Promise<User> {
    try {
      const response = await apiClient.get('/auth/me');
      const user: User = response.data?.data || response.data;
      if (user && user.id) {
        setStoredUser(user);
        return user;
      }
      throw new Error('Invalid user profile');
    } catch (error) {
      initLocalData();
      const user = getStoredUser();
      if (user) return user;
      throw new Error('User not authenticated');
    }
  },

  async updateProfile(data: {
    fullName?: string;
    bio?: string;
    targetDailyProblems?: number;
    targetWeeklyHours?: number;
  }): Promise<User> {
    try {
      const response = await apiClient.put('/users/profile', data);
      const user: User = response.data?.data || response.data;
      if (user && user.id) {
        setStoredUser(user);
        return user;
      }
      throw new Error('Invalid update response');
    } catch (error) {
      const user = getStoredUser();
      if (!user) throw new Error('No user found');
      const updated: User = {
        ...user,
        ...data,
      };
      setStoredUser(updated);
      return updated;
    }
  },

  async changePassword(data: { currentPassword: string; newPassword: string }): Promise<void> {
    try {
      await apiClient.put('/users/password', data);
    } catch (error: any) {
      // If error from real server
      if (error.response?.data?.message) {
        throw new Error(error.response.data.message);
      }
      // In local mode, simulate success if password >= 6
      if (data.newPassword.length < 6) {
        throw new Error('New password must be at least 6 characters');
      }
    }
  },
};
