import {
  apiClient,
  computeDashboardData,
  computeAnalyticsData,
  computeStreakData,
  getStoredProblems,
  getStoredSessions,
  getStoredUser,
  initLocalData,
} from './api';
import { DashboardData, AnalyticsData, StreakData } from '../types';

export const dashboardService = {
  async getDashboard(): Promise<DashboardData> {
    try {
      const response = await apiClient.get('/dashboard');
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.totalProblems !== undefined) {
        return resData;
      }
      throw new Error('Fallback to local computation');
    } catch (error) {
      initLocalData();
      const user = getStoredUser() || {
        id: 1,
        username: 'demouser',
        email: 'demo@codingtracker.dev',
        fullName: 'Alex Chen',
        targetDailyProblems: 3,
        targetWeeklyHours: 12.0,
        role: 'ROLE_USER',
        createdAt: new Date().toISOString(),
      };
      return computeDashboardData(user);
    }
  },
};

export const analyticsService = {
  async getAnalytics(): Promise<AnalyticsData> {
    try {
      const response = await apiClient.get('/analytics');
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.topicStats !== undefined) {
        return resData;
      }
      throw new Error('Fallback to local computation');
    } catch (error) {
      initLocalData();
      return computeAnalyticsData();
    }
  },
};

export const streakService = {
  async getStreak(): Promise<StreakData> {
    try {
      const response = await apiClient.get('/streak');
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.currentStreak !== undefined) {
        return resData;
      }
      throw new Error('Fallback to local computation');
    } catch (error) {
      initLocalData();
      const problems = getStoredProblems();
      const sessions = getStoredSessions();
      return computeStreakData(problems, sessions);
    }
  },
};
