import {
  apiClient,
  getStoredProblems,
  saveStoredProblems,
  initLocalData,
} from './api';
import { CodingProblem, Difficulty, PageResponse, ProblemStatus } from '../types';

export const problemService = {
  async getProblems(params?: {
    status?: ProblemStatus;
    difficulty?: Difficulty;
    topic?: string;
    platform?: string;
    keyword?: string;
    page?: number;
    size?: number;
    sortBy?: string;
    sortDirection?: string;
  }): Promise<PageResponse<CodingProblem>> {
    try {
      const response = await apiClient.get('/problems', { params });
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && Array.isArray(resData.content)) {
        return resData;
      }
      throw new Error('Fallback to local problem storage');
    } catch (error) {
      initLocalData();
      let problems = getStoredProblems();

      // Apply filtering
      if (params?.status) {
        problems = problems.filter((p) => p.status === params.status);
      }
      if (params?.difficulty) {
        problems = problems.filter((p) => p.difficulty === params.difficulty);
      }
      if (params?.topic && params.topic !== 'ALL') {
        problems = problems.filter((p) => p.topic.toLowerCase() === params.topic?.toLowerCase());
      }
      if (params?.platform && params.platform !== 'ALL') {
        problems = problems.filter((p) => p.platform.toLowerCase() === params.platform?.toLowerCase());
      }
      if (params?.keyword) {
        const kw = params.keyword.toLowerCase();
        problems = problems.filter(
          (p) =>
            p.title.toLowerCase().includes(kw) ||
            p.topic.toLowerCase().includes(kw) ||
            p.platform.toLowerCase().includes(kw) ||
            (p.notes && p.notes.toLowerCase().includes(kw))
        );
      }

      // Apply sorting
      const sortBy = params?.sortBy || 'createdAt';
      const isDesc = params?.sortDirection !== 'asc';

      problems.sort((a: any, b: any) => {
        let valA = a[sortBy];
        let valB = b[sortBy];
        if (sortBy === 'difficulty') {
          const rank: Record<string, number> = { EASY: 1, MEDIUM: 2, HARD: 3 };
          valA = rank[a.difficulty] || 0;
          valB = rank[b.difficulty] || 0;
        }
        if (valA === valB) return 0;
        if (valA === undefined || valA === null) return 1;
        if (valB === undefined || valB === null) return -1;
        return isDesc ? (valA < valB ? 1 : -1) : (valA > valB ? 1 : -1);
      });

      // Pagination
      const page = params?.page || 0;
      const size = params?.size || 10;
      const totalElements = problems.length;
      const totalPages = Math.ceil(totalElements / size);
      const start = page * size;
      const content = problems.slice(start, start + size);

      return {
        content,
        pageNumber: page,
        pageSize: size,
        totalElements,
        totalPages,
        isFirst: page === 0,
        isLast: page >= totalPages - 1,
        hasNext: page < totalPages - 1,
        hasPrevious: page > 0,
      };
    }
  },

  async getProblemById(id: number): Promise<CodingProblem> {
    try {
      const response = await apiClient.get(`/problems/${id}`);
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.id) return resData;
      throw new Error('Problem not found');
    } catch (error) {
      const problems = getStoredProblems();
      const problem = problems.find((p) => p.id === id);
      if (!problem) throw new Error('Problem not found');
      return problem;
    }
  },

  async createProblem(data: Omit<CodingProblem, 'id' | 'createdAt' | 'updatedAt'>): Promise<CodingProblem> {
    try {
      const response = await apiClient.post('/problems', data);
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.id) {
        const problems = getStoredProblems();
        saveStoredProblems([resData, ...problems]);
        return resData;
      }
      throw new Error('Fallback to local problem storage');
    } catch (error) {
      const problems = getStoredProblems();
      const newProblem: CodingProblem = {
        ...data,
        id: Date.now(),
        solvedDate: data.status === 'SOLVED' ? (data.solvedDate || new Date().toISOString().split('T')[0]) : null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      saveStoredProblems([newProblem, ...problems]);
      return newProblem;
    }
  },

  async updateProblem(id: number, data: Partial<CodingProblem>): Promise<CodingProblem> {
    try {
      const response = await apiClient.put(`/problems/${id}`, data);
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.id) {
        const problems = getStoredProblems();
        const idx = problems.findIndex((p) => p.id === id);
        if (idx !== -1) {
          problems[idx] = resData;
          saveStoredProblems(problems);
        }
        return resData;
      }
      throw new Error('Fallback to local problem storage');
    } catch (error) {
      const problems = getStoredProblems();
      const index = problems.findIndex((p) => p.id === id);
      if (index === -1) throw new Error('Problem not found');

      const solvedDate = data.status === 'SOLVED' 
        ? (data.solvedDate || problems[index].solvedDate || new Date().toISOString().split('T')[0])
        : (data.status === 'UNSOLVED' ? null : problems[index].solvedDate);

      const updated: CodingProblem = {
        ...problems[index],
        ...data,
        solvedDate,
        updatedAt: new Date().toISOString(),
      };
      problems[index] = updated;
      saveStoredProblems(problems);
      return updated;
    }
  },

  async toggleStatus(id: number): Promise<CodingProblem> {
    try {
      const response = await apiClient.patch(`/problems/${id}/toggle`);
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.id) {
        const problems = getStoredProblems();
        const idx = problems.findIndex((p) => p.id === id);
        if (idx !== -1) {
          problems[idx] = resData;
          saveStoredProblems(problems);
        }
        return resData;
      }
      throw new Error('Fallback to local problem storage');
    } catch (error) {
      const problems = getStoredProblems();
      const index = problems.findIndex((p) => p.id === id);
      if (index === -1) throw new Error('Problem not found');

      const current = problems[index];
      const isNowSolved = current.status !== 'SOLVED';
      const updated: CodingProblem = {
        ...current,
        status: isNowSolved ? 'SOLVED' : 'UNSOLVED',
        solvedDate: isNowSolved ? new Date().toISOString().split('T')[0] : null,
        updatedAt: new Date().toISOString(),
      };
      problems[index] = updated;
      saveStoredProblems(problems);
      return updated;
    }
  },

  async deleteProblem(id: number): Promise<void> {
    try {
      await apiClient.delete(`/problems/${id}`);
    } catch (error) {
      const problems = getStoredProblems().filter((p) => p.id !== id);
      saveStoredProblems(problems);
    }
  },
};
