import {
  apiClient,
  getStoredSessions,
  saveStoredSessions,
  initLocalData,
} from './api';
import { PageResponse, PracticeSession } from '../types';

export const sessionService = {
  async getAllSessions(): Promise<PracticeSession[]> {
    try {
      const response = await apiClient.get('/sessions');
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (Array.isArray(resData)) return resData;
      throw new Error('Fallback to local storage');
    } catch (error) {
      initLocalData();
      const sessions = getStoredSessions();
      return sessions.sort((a, b) => new Date(b.sessionDate).getTime() - new Date(a.sessionDate).getTime());
    }
  },

  async getSessionsPaginated(page = 0, size = 10): Promise<PageResponse<PracticeSession>> {
    try {
      const response = await apiClient.get('/sessions/paginated', { params: { page, size } });
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && Array.isArray(resData.content)) {
        return resData;
      }
      throw new Error('Fallback to local storage');
    } catch (error) {
      initLocalData();
      const sessions = getStoredSessions().sort(
        (a, b) => new Date(b.sessionDate).getTime() - new Date(a.sessionDate).getTime()
      );
      const totalElements = sessions.length;
      const totalPages = Math.ceil(totalElements / size);
      const start = page * size;
      const content = sessions.slice(start, start + size);

      return {
        content,
        pageNumber: page,
        pageSize: size,
        totalElements,
        totalPages,
        isFirst: page === 0,
        isLast: page >= totalPages - 1,
        hasNext: page < totalPages - 1,
        hasPrevious: page > 0,
      };
    }
  },

  async createSession(data: Omit<PracticeSession, 'id' | 'createdAt' | 'updatedAt'>): Promise<PracticeSession> {
    try {
      const response = await apiClient.post('/sessions', data);
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.id) {
        const sessions = getStoredSessions();
        saveStoredSessions([resData, ...sessions]);
        return resData;
      }
      throw new Error('Fallback to local storage');
    } catch (error) {
      const sessions = getStoredSessions();
      const newSession: PracticeSession = {
        ...data,
        id: Date.now(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      saveStoredSessions([newSession, ...sessions]);
      return newSession;
    }
  },

  async updateSession(id: number, data: Partial<PracticeSession>): Promise<PracticeSession> {
    try {
      const response = await apiClient.put(`/sessions/${id}`, data);
      const resData = response.data?.data !== undefined ? response.data.data : response.data;
      if (resData && resData.id) {
        const sessions = getStoredSessions();
        const idx = sessions.findIndex((s) => s.id === id);
        if (idx !== -1) {
          sessions[idx] = resData;
          saveStoredSessions(sessions);
        }
        return resData;
      }
      throw new Error('Fallback to local storage');
    } catch (error) {
      const sessions = getStoredSessions();
      const index = sessions.findIndex((s) => s.id === id);
      if (index === -1) throw new Error('Session not found');

      const updated: PracticeSession = {
        ...sessions[index],
        ...data,
        updatedAt: new Date().toISOString(),
      };
      sessions[index] = updated;
      saveStoredSessions(sessions);
      return updated;
    }
  },

  async deleteSession(id: number): Promise<void> {
    try {
      await apiClient.delete(`/sessions/${id}`);
    } catch (error) {
      const sessions = getStoredSessions().filter((s) => s.id !== id);
      saveStoredSessions(sessions);
    }
  },
};
