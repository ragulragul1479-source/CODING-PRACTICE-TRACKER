export type Difficulty = 'EASY' | 'MEDIUM' | 'HARD';
export type ProblemStatus = 'SOLVED' | 'UNSOLVED';
export type Role = 'ROLE_USER' | 'ROLE_ADMIN';

export interface User {
  id: number;
  username: string;
  email: string;
  fullName: string;
  bio?: string;
  targetDailyProblems: number;
  targetWeeklyHours: number;
  role: Role;
  createdAt: string;
}

export interface AuthResponse {
  token: string;
  tokenType: string;
  expiresIn: number;
  user: User;
}

export interface CodingProblem {
  id: number;
  title: string;
  description?: string;
  difficulty: Difficulty;
  topic: string;
  platform: string;
  problemUrl?: string;
  solutionUrl?: string;
  notes?: string;
  status: ProblemStatus;
  solvedDate?: string | null; // YYYY-MM-DD
  timeSpentMinutes: number;
  createdAt: string;
  updatedAt?: string;
}

export interface PracticeSession {
  id: number;
  sessionDate: string; // YYYY-MM-DD
  durationMinutes: number;
  problemsSolvedCount: number;
  topicFocus?: string;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface DifficultyStats {
  easySolved: number;
  easyTotal: number;
  mediumSolved: number;
  mediumTotal: number;
  hardSolved: number;
  hardTotal: number;
}

export interface WeeklyMonthlyProgress {
  problemsSolvedThisWeek: number;
  problemsSolvedThisMonth: number;
  hoursSpentThisWeek: number;
  hoursSpentThisMonth: number;
  targetDailyProblems: number;
  targetWeeklyHours: number;
  weeklyGoalPercentage: number;
}

export interface RecentActivity {
  id: string;
  type: 'PROBLEM_SOLVED' | 'PROBLEM_ADDED' | 'PRACTICE_SESSION';
  title: string;
  subtitle: string;
  difficultyOrTopic: string;
  timestamp: string;
}

export interface DailyActivity {
  date: string; // YYYY-MM-DD
  problemsSolved: number;
  minutesPracticed: number;
  count: number;
  level: number; // 0, 1, 2, 3, 4
}

export interface DashboardData {
  totalProblems: number;
  totalSolvedProblems: number;
  totalUnsolvedProblems: number;
  completionRate: number;
  totalPracticeHours: number;
  currentStreak: number;
  longestStreak: number;
  practicedToday: boolean;
  difficultyStats: DifficultyStats;
  progress: WeeklyMonthlyProgress;
  recentActivities: RecentActivity[];
  activityHeatmap: DailyActivity[];
}

export interface TopicStat {
  topic: string;
  total: number;
  solved: number;
  percentage: number;
}

export interface PlatformStat {
  platform: string;
  count: number;
  percentage: number;
}

export interface MonthlyStat {
  month: string;
  problemsSolved: number;
  hoursPracticed: number;
  activeDays: number;
}

export interface AnalyticsData {
  totalProblems: number;
  totalSolved: number;
  totalHours: number;
  difficultyStats: DifficultyStats;
  topicStats: TopicStat[];
  platformStats: PlatformStat[];
  solvedOverTime: DailyActivity[];
  monthlyStats: MonthlyStat[];
  dayOfWeekDistribution: Record<string, number>;
}

export interface StreakData {
  currentStreak: number;
  longestStreak: number;
  activeToday: boolean;
  lastActiveDate: string | null;
  totalActiveDays: number;
  activeDates: string[];
  activityHistory: DailyActivity[];
}

export interface PageResponse<T> {
  content: T[];
  pageNumber: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  isFirst: boolean;
  isLast: boolean;
  hasNext: boolean;
  hasPrevious: boolean;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp: string;
}
